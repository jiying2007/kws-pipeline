/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
/* Modified 2026-11-07: distinct R1 2601-output port. Original source pinned in PORT_SOURCES.json. */
#ifdef KWS_B_PROFILE
#include "b_profile.h"
#endif
/* SPDX-License-Identifier: Apache-2.0
 * Modified from the isolated A20 native FP32 model. Original WeKws FSMN:
 * Copyright 2022 Yueyue Nyy; 2023 Jing Du. See NOTICE.md for fixed source IDs.
 * Full2599 output, verified byte loader, bounded trace, explicit cache contract.
 * FP32 reductions are retained; no claim of equality with Torch is made. */
#include "r1dfsmn.h"
#include "sha256.h"
#include <fenv.h>
#include <float.h>
#include <math.h>
#include <string.h>

#define R1DFSMN_MAGIC UINT32_C(0x5232444e)
_Static_assert(sizeof(float) == 4 && FLT_RADIX == 2 && FLT_MANT_DIG == 24,
               "requires IEEE binary32");
_Static_assert(FLT_EVAL_METHOD == 0, "requires binary32 evaluation without excess precision");
_Static_assert(R1DFSMN_HEAD_BIAS_OFFSET + R1DFSMN_OUTPUTS == R1DFSMN_FLOATS,
               "last bias must end at payload boundary");
_Static_assert(R1DFSMN_HEAD_WEIGHT_OFFSET + 140u * R1DFSMN_OUTPUTS == R1DFSMN_HEAD_BIAS_OFFSET,
               "full head weight/bias offsets disagree");

int r1dfsmn_environment_ok(void) {
    const uint16_t one = 1;
    volatile double tiny = DBL_MIN;
    volatile double half = 0.5f;
    volatile double sub = tiny * half;
    volatile double recovered = sub + sub;
    return *(const unsigned char *)&one == 1 && fegetround() == FE_TONEAREST
           && sub > 0.0f && recovered == DBL_MIN;
}

static int overlaps(const void *a, size_t na, const void *b, size_t nb) {
    uintptr_t x = (uintptr_t)a, y = (uintptr_t)b;
    if (na == 0 || nb == 0) return 0;
    if (x > UINTPTR_MAX - na || y > UINTPTR_MAX - nb) return 1;
    return x < y + nb && y < x + na;
}

static int valid(const r1dfsmn_model *m) {
    return m && m->magic == R1DFSMN_MAGIC && m->weights;
}

r1dfsmn_status r1dfsmn_load(r1dfsmn_model *m, float *w, size_t nw,
        const unsigned char *payload, size_t bytes, unsigned order, const char hash[65]) {
    if (!m || !w || !payload || !hash) return R1DFSMN_ARGUMENT;
    if (nw != R1DFSMN_FLOATS || bytes != R1DFSMN_PAYLOAD_BYTES) return R1DFSMN_SIZE;
    if (order != R1DFSMN_PAYLOAD_LITTLE_ENDIAN || !r1dfsmn_environment_ok())
        return R1DFSMN_ENVIRONMENT;
    if (overlaps(m, sizeof(*m), w, R1DFSMN_PAYLOAD_BYTES)
        || overlaps(m, sizeof(*m), payload, bytes)
        || overlaps(w, R1DFSMN_PAYLOAD_BYTES, payload, bytes)
        || overlaps(m, sizeof(*m), hash, 65)
        || overlaps(w, R1DFSMN_PAYLOAD_BYTES, hash, 65)) return R1DFSMN_OVERLAP;
    for (unsigned i = 0; i < 64; ++i)
        if (!((hash[i] >= '0' && hash[i] <= '9') || (hash[i] >= 'a' && hash[i] <= 'f')))
            return R1DFSMN_IDENTITY;
    if (hash[64] != '\0') return R1DFSMN_IDENTITY;
    char actual[65];
    r1d_sha256_memory_hex(payload, bytes, actual);
    if (memcmp(actual, hash, 65) != 0) return R1DFSMN_IDENTITY;
    for (size_t i = 0; i < R1DFSMN_FLOATS; ++i) {
        float value;
        memcpy(&value, payload + i * 4u, 4u);
        if (!isfinite(value)) return R1DFSMN_NONFINITE;
        if (i >= 400 && i < 800 && !(value > 0.0f)) return R1DFSMN_ARGUMENT;
    }
    /* Byte reads and memcpy avoid unaligned payload access / double aliasing. */
    for (size_t i = 0; i < R1DFSMN_FLOATS; ++i) memcpy(w + i, payload + i * 4u, 4u);
    m->weights = w;
    memset(m->cache, 0, sizeof(m->cache));
    m->magic = R1DFSMN_MAGIC;
    m->fault = 0;
    return R1DFSMN_OK;
}

r1dfsmn_status r1dfsmn_reset(r1dfsmn_model *m) {
    if (!valid(m)) return R1DFSMN_STATE;
    if (!r1dfsmn_environment_ok()) return R1DFSMN_ENVIRONMENT;
    memset(m->cache, 0, sizeof(m->cache));
    m->fault = 0;
    return R1DFSMN_OK;
}

r1dfsmn_status r1dfsmn_copy_cache(const r1dfsmn_model *m, double *out, size_t count) {
    if (!valid(m) || m->fault) return R1DFSMN_STATE;
    if (!out) return R1DFSMN_ARGUMENT;
    if (count != R1DFSMN_CACHE_FLOATS) return R1DFSMN_SIZE;
    if (overlaps(out, sizeof(m->cache), m, sizeof(*m))
        || overlaps(out, sizeof(m->cache), m->weights, R1DFSMN_PAYLOAD_BYTES))
        return R1DFSMN_OVERLAP;
    memcpy(out, m->cache, sizeof(m->cache));
    return R1DFSMN_OK;
}

/* Wider accumulation; precision mode defines activation boundaries. */
_Static_assert(sizeof(double)==8 && DBL_MANT_DIG==53, "IEEE binary64 required");
static void affine(const double *x, double *y, const float *w, const float *b, int ni, int no) {
    for(int o=0;o<no;o++) {
        double sum=0.0;
        for(int i=0;i<ni;i++)sum+=(double)x[i]*(double)w[o*ni+i];
        y[o]=(double)(sum+(b?(double)b[o]:0.0));
    }
}

static int finite_values(const double *x, size_t count) {
    for (size_t i = 0; i < count; ++i) if (!isfinite(x[i])) return 0;
    return 1;
}

static void relu(double *x, int count) {
    for (int i = 0; i < count; ++i) if (x[i] < 0) x[i] = 0;
}

static void trace_stage(double *t, unsigned stage, const double *x, size_t count) {
    if (t) memcpy(t + (stage == 20 ? R1DFSMN_TRACE_FINAL_OFFSET : stage * 250u),
                  x, count * sizeof(double));
}

static void memory(r1dfsmn_model *m, int layer, size_t offset, const double *p, double *out) {
    const float *w = m->weights;
    for (int c = 0; c < 128; ++c) {
        double left_sum = 0.0;
        for (int k = 0; k < 10; ++k)
            left_sum += (double)w[offset + 32000u + (size_t)c * 10u + (size_t)k]
                    * (double)m->cache[((size_t)c * 11u + (size_t)k) * 4u + (size_t)layer];
        double left = (double)left_sum;
        double right_sum = (double)w[offset + 33280u + (size_t)c * 2u]
                      * (double)m->cache[((size_t)c * 11u + 10u) * 4u + (size_t)layer]
                      + (double)w[offset + 33281u + (size_t)c * 2u] * (double)p[c];
        double right = (double)right_sum;
        out[c] = (m->cache[((size_t)c * 11u + 9u) * 4u + (size_t)layer] + left) + right;
        for (int k = 0; k < 10; ++k)
            m->cache[((size_t)c * 11u + (size_t)k) * 4u + (size_t)layer]
                = m->cache[((size_t)c * 11u + (size_t)k + 1u) * 4u + (size_t)layer];
        m->cache[((size_t)c * 11u + 10u) * 4u + (size_t)layer] = p[c];
    }
}

r1dfsmn_status r1dfsmn_step(r1dfsmn_model *m, const double *x, size_t nx,
        double *y, size_t ny, double *t, size_t nt) {
    if (!valid(m) || m->fault) return R1DFSMN_STATE;
    if (!x || !y || (!t && nt != 0)) return R1DFSMN_ARGUMENT;
    if (nx != R1DFSMN_INPUTS || ny != R1DFSMN_OUTPUTS
        || (t && nt < R1DFSMN_TRACE_FLOATS)) return R1DFSMN_SIZE;
    if (!r1dfsmn_environment_ok()) return R1DFSMN_ENVIRONMENT;
    size_t xb = R1DFSMN_INPUTS * sizeof(double), yb = R1DFSMN_OUTPUTS * sizeof(double);
    size_t tb = t ? R1DFSMN_TRACE_FLOATS * sizeof(double) : 0;
    if (overlaps(x, xb, m, sizeof(*m)) || overlaps(y, yb, m, sizeof(*m))
        || overlaps(t, tb, m, sizeof(*m)) || overlaps(x, xb, m->weights, R1DFSMN_PAYLOAD_BYTES)
        || overlaps(y, yb, m->weights, R1DFSMN_PAYLOAD_BYTES)
        || overlaps(t, tb, m->weights, R1DFSMN_PAYLOAD_BYTES)
        || overlaps(x, xb, y, yb) || overlaps(x, xb, t, tb) || overlaps(y, yb, t, tb))
        return R1DFSMN_OVERLAP;
    if (!finite_values(x, nx)) return R1DFSMN_NONFINITE;
    if (t) memset(t, 0, tb);
#ifdef KWS_B_PROFILE
    b_profile_stamp profile_stamp=b_profile_begin();
    unsigned profile_stage=B_PROFILE_BODY;
#endif
    const float *w = m->weights;
    double z[400], a[250], b[250], p[128], mem[128];
    for (unsigned i = 0; i < 400; ++i) z[i] = (x[i] - w[i]) * w[400u + i];
    if (!finite_values(z, 400)) goto fault;
    affine(z, a, w + 800, w + 56800, 400, 140);
    if (!finite_values(a, 140)) goto fault;
    trace_stage(t, 0, a, 140);
    affine(a, b, w + 56940, w + 91940, 140, 250);
    if (!finite_values(b, 250)) goto fault;
    trace_stage(t, 1, b, 250); relu(b, 250); trace_stage(t, 2, b, 250);
    for (int layer = 0; layer < 4; ++layer) {
        size_t offset = 92190u + (size_t)layer * 65786u;
        affine(b, p, w + offset, NULL, 250, 128);
        if (!finite_values(p, 128)) goto fault;
        trace_stage(t, 3u + (unsigned)layer * 4u, p, 128);
        memory(m, layer, offset, p, mem);
        if (!finite_values(mem, 128)) goto fault;
        trace_stage(t, 4u + (unsigned)layer * 4u, mem, 128);
        affine(mem, b, w + offset + 33536u, w + offset + 65536u, 128, 250);
        if (!finite_values(b, 250)) goto fault;
        trace_stage(t, 5u + (unsigned)layer * 4u, b, 250);
        relu(b, 250); trace_stage(t, 6u + (unsigned)layer * 4u, b, 250);
    }
    affine(b, a, w + 355334u, w + 390334u, 250, 140);
    if (!finite_values(a, 140)) goto fault;
    trace_stage(t, 19, a, 140);
#ifdef KWS_B_PROFILE
    b_profile_end(B_PROFILE_BODY,profile_stamp,1);
    profile_stage=B_PROFILE_HEAD;profile_stamp=b_profile_begin();
#endif
    affine(a, y, w + R1DFSMN_HEAD_WEIGHT_OFFSET, w + R1DFSMN_HEAD_BIAS_OFFSET,
           140, R1DFSMN_OUTPUTS);
    if (!finite_values(y, R1DFSMN_OUTPUTS)) goto fault;
    trace_stage(t, 20, y, R1DFSMN_OUTPUTS);
#ifdef KWS_B_PROFILE
    b_profile_end(B_PROFILE_HEAD,profile_stamp,1);
#endif
    return R1DFSMN_OK;
fault:
#ifdef KWS_B_PROFILE
    b_profile_end(profile_stage,profile_stamp,0);
#endif
    m->fault = 1;
    return R1DFSMN_NONFINITE;
}
