/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
/* Modified 2026-11-07: R1 no-padding EOF; preserve upstream body transport. */
/* New independent implementation of the frozen Python frame-step contract.
 * Source and provenance: NOTICE.md, source-binding.json. Apache-2.0. */
#include "r1d_pcm.h"
#include <math.h>
#include <string.h>
#define R1DCF_MAGIC UINT32_C(0x4b433634)
_Static_assert(sizeof(r1d_pcm) <= 16384, "bounded stream state");

static int fail(r1d_pcm *s, int error, int event, uint64_t index, int cb) {
    s->error=error; s->failed_event=event; s->failed_index=index;
    s->callback_error=cb; s->phase=R1DCF_PHASE_FAILED;
    return error;
}
static int push_sample(r1d_pcm *s, int16_t sample) {
    double row[80];
    int rc;
    uint64_t j;
    s->pcm[s->used++]=sample;
    s->padded_samples++;
    if (s->used < 400) return R1DCF_OK;
    j=s->fbank_frames;
    s->fbank_attempted++;
    for (unsigned k=0;k<80;k++) row[k]=NAN;
    rc=s->bank(s->bank_user,s->pcm,row);
    if (rc) return fail(s,R1DCF_BANK,R1DCF_EVENT_FBANK,j,rc);
    for (unsigned k=0;k<80;k++)
        if (!isfinite(row[k])) return fail(s,R1DCF_NONFINITE,R1DCF_EVENT_FBANK,j,0);
    s->fbank_frames++;
    rc=s->emit(s->emit_user,R1DCF_EVENT_FBANK,j,j,s->padded_samples,
               s->phase==R1DCF_PHASE_EOF,row);
    if (rc) return fail(s,R1DCF_SINK,R1DCF_EVENT_FBANK,j,rc);
    s->fbank_accepted++;
    memcpy(s->history[j%5],row,sizeof(row));
    if (j>=2 && (j-2)%3==0) {
        uint64_t center=j-2, m=center/3;
        /* For center 0: frame indices [0,0,0,1,2]. Later: center-2..center+2.
         * Ring contains exactly the newest five rows, no growing buffer. */
        for (unsigned k=0;k<5;k++) {
            uint64_t index=(center+k>=2)?center+k-2:0;
            memcpy(s->context+k*80,s->history[index%5],80*sizeof(double));
        }
        s->context_attempted++;
        rc=s->emit(s->emit_user,R1DCF_EVENT_CONTEXT,m,center,s->padded_samples,
                   s->phase==R1DCF_PHASE_EOF,s->context);
        if (rc) return fail(s,R1DCF_SINK,R1DCF_EVENT_CONTEXT,m,rc);
        s->context_accepted++;
    }
    memmove(s->pcm,s->pcm+160,240*sizeof(int16_t));
    s->used=240;
    return R1DCF_OK;
}
int r1d_pcm_init(r1d_pcm *s, r1d_fbank_bank_fn bank, void *bank_user,
                 r1d_fbank_emit_fn emit, void *emit_user) {
    if (!s || !bank || !emit) return R1DCF_ARGUMENT;
    memset(s,0,sizeof(*s));
    s->magic=R1DCF_MAGIC; s->bank=bank; s->bank_user=bank_user;
    s->emit=emit; s->emit_user=emit_user;
    return R1DCF_OK;
}
int r1d_pcm_feed(r1d_pcm *s, const uint8_t *data, size_t bytes, size_t *consumed) {
    int rc=R1DCF_OK;
    if (!consumed) return R1DCF_ARGUMENT;
    *consumed=0;
    if (!s || (!data && bytes)) return R1DCF_ARGUMENT;
    if (s->magic!=R1DCF_MAGIC || s->busy) return R1DCF_STATE;
    if (s->error) return s->error;
    if (s->phase!=R1DCF_PHASE_OPEN) return R1DCF_STATE;
    /* Reserve tail headroom; this also bounds all frame/index arithmetic. */
    if (bytes > UINT64_MAX-UINT64_C(9600)-s->input_bytes)
        return fail(s,R1DCF_OVERFLOW,0,0,0);
    s->busy=1;
    for (size_t i=0;i<bytes;i++) {
        uint8_t byte=data[i];
        s->input_bytes++; *consumed=i+1;
        if (!s->have_low) {s->low=byte; s->have_low=1;}
        else {
            uint32_t word=(uint32_t)s->low|((uint32_t)byte<<8);
            /* Avoid implementation-defined uint16_t -> int16_t overflow. */
            int32_t signed_word=(word<32768u)?(int32_t)word:(int32_t)word-65536;
            s->have_low=0; s->real_samples++;
            rc=push_sample(s,(int16_t)signed_word);
            if (rc) break;
        }
    }
    s->busy=0;
    return rc;
}
int r1d_pcm_finish(r1d_pcm *s) {
    int rc=R1DCF_OK;
    if (!s) return R1DCF_ARGUMENT;
    if (s->magic!=R1DCF_MAGIC || s->busy) return R1DCF_STATE;
    if (s->error) return s->error;
    if (s->phase!=R1DCF_PHASE_OPEN || s->eof_attempted) return R1DCF_STATE;
    s->eof_attempted=1;
    if (s->have_low) return fail(s,R1DCF_ODD_EOF,0,0,0);
    s->busy=1; s->phase=R1DCF_PHASE_EOF;
    /* R1 reference is unpadded: no new fbank, network or event rows at EOF. */
    if (!rc) {s->eof_completed=1; s->phase=R1DCF_PHASE_CLOSED;}
    s->busy=0;
    return rc;
}
