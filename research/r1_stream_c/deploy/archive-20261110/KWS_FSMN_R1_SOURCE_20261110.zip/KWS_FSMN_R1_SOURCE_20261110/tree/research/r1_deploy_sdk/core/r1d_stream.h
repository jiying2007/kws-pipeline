/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
/* SPDX-License-Identifier: Apache-2.0
 * R1 research PCM stream. Fixed exported model identity, no hidden EOF audio.
 * Single threaded. Callback must not re-enter, destroy or mutate this handle.
 * Input buffers must remain valid throughout synchronous feed. */
#ifndef R1D_STREAM_H
#define R1D_STREAM_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define R1D_OUTPUTS 2601u
/* feature/logit pointers are valid only within the callback. source_end is
 * the exact exclusive input dependency end, NOT a keyword end annotation.
 * delivery_end includes transport batching. No synthetic rows are emitted. */
typedef int (*r1d_sink)(void *,uint64_t,uint64_t,uint64_t,const double *,const double *);
typedef struct r1d_stream r1d_stream;
r1d_stream *r1d_create(const unsigned char *model,size_t model_bytes,
    const unsigned char *tables,size_t table_bytes,r1d_sink sink,void *user);
int r1d_feed(r1d_stream *s,const unsigned char *data,size_t bytes,size_t *consumed);
int r1d_finish(r1d_stream *s);
int r1d_reset(r1d_stream *s);
void r1d_destroy(r1d_stream *s);
size_t r1d_state_bytes(void);
size_t r1d_weight_bytes(void);
uint64_t r1d_frames(const r1d_stream *s);
/* Network-only validation path; fixed400D features. Not an audio model bypass.
 * Must not mix with audio feed on the same handle; reset between modes. */
int r1d_feature(r1d_stream *s,const double *feature,double *logits);
#ifdef __cplusplus
}
#endif
#endif
