#!/usr/bin/env python3
"""Owner-local exact-host byte replay. No Torch, NumPy, network or training.

This checks the same-host numerical hashes plus complete keyword events.
It is not the separate tolerance-based ARM numerical qualification tool.
"""
from __future__ import annotations
import argparse,ctypes as C,hashlib,json,sys,time
from pathlib import Path
import binding

def require(ok,msg):
    if not ok: raise ValueError(msg)
def sha(data):return hashlib.sha256(data).hexdigest()
def run(args):
    require(not args.output.exists(),'fresh output path required')
    manifest=json.loads((args.capsule/'inputs/INPUT_MANIFEST.json').read_text())
    rows=manifest['records'];require(len(rows)==134 and len({r['source_id'] for r in rows})==134,'closed 134-record identity')
    for r in rows:
        p=args.capsule/'inputs/pcm'/('%03d.pcm'%r['index']);raw=p.read_bytes()
        require(len(raw)==r['pcm_bytes'] and sha(raw)==r['pcm_sha256'],'original PCM byte identity')
    selected=None if args.indices is None else {int(i) for i in args.indices.split(',')}
    require(selected is None or selected and selected<={r['index'] for r in rows},'explicit valid index subset')
    args.output.mkdir(parents=True)
    l=binding.load(args.library);model=(args.weights/'model.f32le').read_bytes();tables=(args.weights/'frontend.f32le').read_bytes()
    require(sha(model)==l.fsmn_sdk_model_sha256().decode() and sha(tables)==l.fsmn_sdk_table_sha256().decode(),'fixed model and frontend hashes')
    count=0;frames=0;start=time.monotonic();results=[]
    ledger=(args.output/'execution.jsonl').open('x')
    try:
        for r in rows:
            i=r['index']
            if selected is not None and i not in selected:continue
            reference=json.loads((args.capsule/'evidence/pcm-validation/records'/('%03d.json'%i)).read_text())
            require(reference['source_id']==r['source_id'] and reference['pcm_sha256']==r['pcm_sha256'],'expected source binding')
            fbytes=bytearray();zbytes=bytearray();events=[];argmax=[];clocks=[];errors=[]
            @binding.EVENT
            def on_event(_,ptr):
                e=ptr.contents;events.append({key:int(getattr(e,key)) for key,_ in binding.Event._fields_});return 0
            @binding.FRAME
            def on_frame(_,frame,dep,delivery,f,z):
                try:
                    fbytes.extend(C.string_at(f,400*8));zbytes.extend(C.string_at(z,2601*8));argmax.append(max(range(2601),key=lambda j:z[j]));clocks.append((int(frame),int(dep),int(delivery)));return 0
                except Exception as exc:errors.append(str(exc));return 1
            ledger.write(json.dumps({'index':i,'status':'started'})+'\n');ledger.flush()
            h=l.fsmn_sdk_create(model,len(model),tables,len(tables),0,on_event,on_frame,None);require(h,'model create')
            raw=(args.capsule/'inputs/pcm'/('%03d.pcm'%i)).read_bytes();at=0
            try:
                while at<len(raw):
                    block=raw[at:at+640];used=C.c_size_t()
                    rc=l.fsmn_sdk_feed(h,block,len(block),C.byref(used));require(rc==0 and used.value==len(block),'feed failed: '+str(errors));at+=used.value
                require(l.fsmn_sdk_finish(h)==0,'finish')
                require(len(clocks)==reference['frames']==l.fsmn_sdk_frame_count(h),'frame counts')
            finally:require(l.fsmn_sdk_destroy(h)==0,'destroy')
            require(sha(fbytes+zbytes)==reference['comparisons']['gcc-640']['numeric_sha256'],'exact-host numerical bytes differ')
            require(argmax==reference['frame_argmax'] and events==reference['events']['gcc-640'],'argmax/events differ')
            require(all(frame==n and dep==720+480*n and dep<=delivery<=r['samples'] for n,(frame,dep,delivery) in enumerate(clocks)),'clocks')
            rec={'index':i,'source_id':r['source_id'],'frames':len(clocks),'events':len(events),'exact_host_bytes':True,'status':'complete'}
            ledger.write(json.dumps(rec)+'\n');ledger.flush();results.append(rec);count+=1;frames+=len(clocks)
        result={'schema':'owner-exact-host-replay-v1','pass':True,'all_input_pcm_verified':134,'executed_records':count,'executed_model_frames':frames,'full_134_replay':count==134,'exact_host_numeric_hashes':True,'seconds':time.monotonic()-start,'new_training':0,'acoustic_qualification':False,'physical_device':False,'rows':results}
        (args.output/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');return {k:v for k,v in result.items() if k!='rows'}
    except BaseException as exc:
        (args.output/'FAILED.json').write_text(json.dumps({'message':str(exc),'completed_records':count,'completed_frames':frames},indent=2)+'\n');raise
    finally:ledger.close()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--capsule',type=Path,required=True);p.add_argument('--library',type=Path,required=True);p.add_argument('--weights',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--indices',help='explicit subset for integration test; default replays all 134')
    a=p.parse_args()
    try:print(json.dumps(run(a),sort_keys=True))
    except (ValueError,OSError,KeyError) as e:p.exit(2,str(e)+'\n')
if __name__=='__main__':main()
