# Linux ARMv7-A hard-float; select the REAL SSC305 SDK compiler for board builds.
# Generic GNU ABI is not proof of compatibility with the device's libc/loader.
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR arm)
set(CMAKE_C_COMPILER arm-linux-gnueabihf-gcc CACHE STRING "ARM hard-float C compiler")
set(CMAKE_C_FLAGS_INIT "-mcpu=cortex-a32 -mfpu=neon-vfpv4 -mfloat-abi=hard")
