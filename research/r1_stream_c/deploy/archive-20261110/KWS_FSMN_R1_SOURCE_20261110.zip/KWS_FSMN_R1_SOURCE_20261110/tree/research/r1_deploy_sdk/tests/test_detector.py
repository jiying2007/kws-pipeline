"""Standard-library decoder regressions; fabricated token streams, not audio."""
from __future__ import annotations
import ctypes as C, importlib.util, os, random, unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('binding',P/'tools/binding.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
WORDS=((1027,1401,1462,2093),(1462,2093,1462,2093));K1=list(WORDS[0]);K2=list(WORDS[1])
def python_events(ids):
    previous=0;tokens=[];frames=[];allowed=[0,0];blank=0;events=[]
    for i,x in enumerate(ids):
        if x==0:
            previous=0;blank+=1
            if blank>=50:tokens=[];frames=[]
            continue
        blank=0
        if x==previous:continue
        previous=x;tokens=(tokens+[x])[-4:];frames=(frames+[i])[-4:]
        if len(tokens)==4 and frames[-1]-frames[0]<=150:
            for k,w in enumerate(WORDS):
                if tuple(tokens)==w and i>=allowed[k]:
                    events.append((i,k+1));allowed[k]=i+50
    return events
class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.l=b.load(Path(os.environ['FSMN_LIBRARY']))
    def run_ids(self,ids):
        d=b.Detector();self.l.fsmn_detector_init(C.byref(d));out=[]
        for i,x in enumerate(ids):
            k=self.l.fsmn_detector_step(C.byref(d),i,x);self.assertGreaterEqual(k,0)
            if k:out.append((i,k))
        return out
    def test_k1_complete(self):self.assertEqual(self.run_ids(K1),[(3,1)])
    def test_k2_complete(self):self.assertEqual(self.run_ids(K2),[(3,2)])
    def test_partial_not_positive(self):self.assertEqual(self.run_ids(K2[:2]),[])
    def test_nonempty_not_positive(self):self.assertEqual(self.run_ids([1027]),[])
    def test_wrong_order(self):self.assertEqual(self.run_ids([1027,1462,1401,2093]),[])
    def test_no_filtering_competitor(self):self.assertEqual(self.run_ids(K1[:2]+[200]+K1[2:]),[])
    def test_ctc_repetitions_collapsed(self):self.assertEqual(self.run_ids([x for x in K1 for _ in range(3)]),[(9,1)])
    def test_blank_separates_same_token(self):self.assertEqual(self.run_ids([1027,0,1027,1401,1462,2093]),[(5,1)])
    def test_all_blank(self):self.assertEqual(self.run_ids([0]*200),[])
    def test_pause_49_retained(self):self.assertEqual(self.run_ids(K1[:2]+[0]*49+K1[2:]),[(52,1)])
    def test_pause_50_reset(self):self.assertEqual(self.run_ids(K1[:2]+[0]*50+K1[2:]),[])
    def test_span_150_allowed(self):
        s=[K1[0]]*50+[K1[1]]*50+[K1[2]]*50+[K1[3]];self.assertEqual(self.run_ids(s),[(150,1)])
    def test_span_151_rejected(self):
        s=[K1[0]]*51+[K1[1]]*50+[K1[2]]*50+[K1[3]];self.assertEqual(self.run_ids(s),[])
    def test_cooldown(self):self.assertEqual(self.run_ids(K1+K1),[(3,1)])
    def test_cooldown_boundary(self):self.assertEqual(self.run_ids(K1+[0]*46+K1),[(3,1),(53,1)])
    def test_per_keyword_cooldown(self):self.assertEqual(self.run_ids(K1+[77]+K2),[(3,1),(8,2)])
    def test_overlapping_complete_keywords(self):
        # The K1 suffix and the next two tokens complete K2 at frame 5.
        # Its second overlapping match at frame 7 is suppressed by K2 cooldown.
        self.assertEqual(self.run_ids(K1+K2),[(3,1),(5,2)])
    def test_unknown_token_rejected_without_mutation(self):
        d=b.Detector();self.l.fsmn_detector_init(C.byref(d));old=bytes(d)
        self.assertEqual(self.l.fsmn_detector_step(C.byref(d),0,2601),-1);self.assertEqual(bytes(d),old)
    def test_frame_gap_rejected_without_mutation(self):
        d=b.Detector();self.l.fsmn_detector_init(C.byref(d));old=bytes(d)
        self.assertEqual(self.l.fsmn_detector_step(C.byref(d),1,1027),-1);self.assertEqual(bytes(d),old)
    def test_overflow_rejected(self):
        d=b.Detector();self.l.fsmn_detector_init(C.byref(d));d.next_frame=2**64-1;old=bytes(d)
        self.assertEqual(self.l.fsmn_detector_step(C.byref(d),2**64-1,1027),-1);self.assertEqual(bytes(d),old)
    def test_reset_prevents_prefix_bridge(self):
        d=b.Detector();self.l.fsmn_detector_init(C.byref(d))
        for i,x in enumerate(K1[:2]):self.assertEqual(self.l.fsmn_detector_step(C.byref(d),i,x),0)
        self.l.fsmn_detector_init(C.byref(d))
        for i,x in enumerate(K1[2:]):self.assertEqual(self.l.fsmn_detector_step(C.byref(d),i,x),0)
    def test_reference_random_streams(self):
        rng=random.Random(20261110);alphabet=[0,1027,1401,1462,2093,77,2599,2600]
        for _ in range(200):
            ids=[rng.choice(alphabet) for __ in range(240)]
            self.assertEqual(self.run_ids(ids),python_events(ids))
if __name__=='__main__':unittest.main(verbosity=2)
