/* SPDX-License-Identifier: Apache-2.0
 * Bounded complete-keyword greedy CTC proposals; NOT calibrated decisions. */
#ifndef FSMN_DETECTOR_H
#define FSMN_DETECTOR_H
#include <stdint.h>
#define FSMN_VOCABULARY_SIZE 2601u
#define FSMN_KEYWORD_SPAN_FRAMES 150u
#define FSMN_BLANK_RESET_FRAMES 50u
#define FSMN_REFRACTORY_FRAMES 50u
typedef struct {
    uint64_t next_frame, token_frames[4], next_allowed[2];
    uint32_t tokens[4], used, previous, blank_run;
} fsmn_detector;
void fsmn_detector_init(fsmn_detector *d);
/* Returns 0/1/2 for no proposal/K1/K2, or -1 without mutation on bad input.
 * Every frame, including blank and repeated tokens, must be supplied. */
int fsmn_detector_step(fsmn_detector *d, uint64_t frame, uint32_t token);
#endif
