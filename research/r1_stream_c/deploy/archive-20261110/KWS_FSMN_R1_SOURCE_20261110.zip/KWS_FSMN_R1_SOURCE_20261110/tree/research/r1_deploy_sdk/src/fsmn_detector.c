/* SPDX-License-Identifier: Apache-2.0 */
#include "fsmn_detector.h"
#include <string.h>
#include <stddef.h>
void fsmn_detector_init(fsmn_detector *d) { if (d) memset(d,0,sizeof(*d)); }
int fsmn_detector_step(fsmn_detector *d,uint64_t frame,uint32_t token) {
    static const uint32_t words[2][4]={{1027,1401,1462,2093},{1462,2093,1462,2093}};
    if (!d || token>=FSMN_VOCABULARY_SIZE || frame!=d->next_frame ||
        frame>UINT64_MAX-FSMN_REFRACTORY_FRAMES || d->used>4) return -1;
    d->next_frame++;
    if (token==0) {
        d->previous=0;
        if (d->blank_run<FSMN_BLANK_RESET_FRAMES) d->blank_run++;
        if (d->blank_run==FSMN_BLANK_RESET_FRAMES) d->used=0;
        return 0;
    }
    d->blank_run=0;
    if (token==d->previous) return 0;
    d->previous=token;
    if (d->used==4) {
        memmove(d->tokens,d->tokens+1,3*sizeof(d->tokens[0]));
        memmove(d->token_frames,d->token_frames+1,3*sizeof(d->token_frames[0]));
        d->used=3;
    }
    d->tokens[d->used]=token;d->token_frames[d->used]=frame;d->used++;
    if (d->used<4 || frame-d->token_frames[0]>FSMN_KEYWORD_SPAN_FRAMES) return 0;
    for (unsigned k=0;k<2;k++) {
        if (!memcmp(d->tokens,words[k],sizeof(d->tokens)) && frame>=d->next_allowed[k]) {
            d->next_allowed[k]=frame+FSMN_REFRACTORY_FRAMES;
            return (int)k+1;
        }
    }
    return 0;
}
