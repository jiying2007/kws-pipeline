/* SPDX-License-Identifier: Apache-2.0
 * Independent installed-SDK consumer. File I/O is outside the SDK data plane.
 * Real application callbacks should hand off the small event without blocking. */
#include <fsmn_sdk.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
static uint64_t proposals;
static int on_event(void *user,const fsmn_event *e) {
    (void)user;if(!e||e->abi!=FSMN_SDK_ABI)return 1;proposals++;return 0;
}
static unsigned char *asset(const char *name,size_t n) {
    FILE *f=fopen(name,"rb");if(!f)return NULL;
    unsigned char *p=malloc(n);if(!p){fclose(f);return NULL;}
    int ok=fread(p,1,n,f)==n&&fgetc(f)==EOF&&!ferror(f);if(fclose(f))ok=0;
    if(!ok){free(p);return NULL;}return p;
}
int main(int argc,char **argv) {
    if(argc!=4){fprintf(stderr,"Usage: %s model.f32le frontend.f32le input.pcm\n",argv[0]);return 2;}
    unsigned char *w=asset(argv[1],FSMN_MODEL_BYTES),*t=asset(argv[2],FSMN_TABLE_BYTES);
    fsmn_sdk *sdk=fsmn_sdk_create(w,w?FSMN_MODEL_BYTES:0,t,t?FSMN_TABLE_BYTES:0,0,on_event,NULL,NULL);free(w);free(t);
    if(!sdk)return 2;
    FILE *f=fopen(argv[3],"rb");if(!f){fsmn_sdk_destroy(sdk);return 2;}
    unsigned char pcm[640];int result=0;size_t n;
    while((n=fread(pcm,1,sizeof(pcm),f))!=0){size_t consumed=0;int rc=fsmn_sdk_feed(sdk,pcm,n,&consumed);if(rc!=FSMN_OK||consumed!=n){result=2;break;}}
    if(ferror(f))result=2;
    if(fclose(f))result=2;
    if(!result&&fsmn_sdk_finish(sdk)!=FSMN_OK)result=2;
    /* On actual capture loss call fsmn_sdk_notify_gap(sdk,next_absolute_sample).
     * Do not fill lost audio with guessed samples or retain keyword prefixes. */
    printf("{\"status\":\"%s\",\"frames\":%" PRIu64 ",\"proposals\":%" PRIu64 "}\n",result?"failed":"complete",fsmn_sdk_frame_count(sdk),proposals);
    if(fsmn_sdk_destroy(sdk))result=2;
    return result;
}
