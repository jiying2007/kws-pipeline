/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
/* SPDX-License-Identifier: Apache-2.0
 * Modified integration 2026-11-07. Reuses the pinned historical arithmetic,
 * but binds a distinct2601 R1 payload and unpadded reference EOF semantics. */
#include "r1d_stream.h"
#include "r1d_pcm.h"
#include "reference64_fbank.h"
#include "r1dfsmn.h"
#include "model_identity.h"
#include "sha256.h"
#include <stdlib.h>
#include <string.h>
#include <fenv.h>
#include <limits.h>
#define R1D_MAGIC UINT32_C(0x52324436)
struct r1d_stream {
    uint32_t magic;
    int busy,mode;
    r1dfsmn_model net;
    r1d_fbank_fbank bank;
    r1d_fbank_tables tables;
    r1d_pcm pcm;
    r1d_sink sink;
    void *user;
    uint64_t delivery_end,frames;
    float *weights;
    double table_data[R1D_TABLE_FLOATS];
    double logits[R1D_OUTPUTS];
};
size_t r1d_state_bytes(void){return sizeof(r1d_stream);}
size_t r1d_weight_bytes(void){return R1DFSMN_PAYLOAD_BYTES;}
uint64_t r1d_frames(const r1d_stream *s){return s&&s->magic==R1D_MAGIC?s->frames:0;}
static int bank(void *user,const int16_t *pcm,double *row){
    return r1d_fbank_fbank_frame(&((r1d_stream *)user)->bank,pcm,row,NULL);
}
static int emit(void *user,int event,uint64_t index,uint64_t center,
                uint64_t source_end,int eof,const double *feature){
    r1d_stream *s=(r1d_stream *)user;(void)center;
    if(eof)return R1DCF_STATE;
    if(event==R1DCF_EVENT_FBANK)return 0;
    if(event!=R1DCF_EVENT_CONTEXT || index!=s->frames)return R1DCF_STATE;
    int rc=r1dfsmn_step(&s->net,feature,400,s->logits,R1D_OUTPUTS,NULL,0);
    if(rc)return rc;
    s->frames++;
    return s->sink(s->user,index,source_end,s->delivery_end,feature,s->logits);
}
r1d_stream *r1d_create(const unsigned char *payload,size_t bytes,
        const unsigned char *tables,size_t table_bytes,r1d_sink sink,void *user){
    if(!payload || bytes!=R1DFSMN_PAYLOAD_BYTES || !tables ||
       table_bytes!=R1D_TABLE_FLOATS*4u || !sink)return NULL;
    char hash[65];r1d_sha256_memory_hex(tables,table_bytes,hash);
    if(memcmp(hash,R1D_FRONTEND_SHA,65))return NULL;
    r1d_stream *s=(r1d_stream *)calloc(1,sizeof(*s));if(!s)return NULL;
    s->weights=(float *)malloc(R1DFSMN_PAYLOAD_BYTES);
    if(!s->weights){free(s);return NULL;}
    fenv_t env;
    if(feholdexcept(&env)){free(s->weights);free(s);return NULL;}
    int rc=r1dfsmn_load(&s->net,s->weights,R1DFSMN_FLOATS,payload,bytes,1,R1D_MODEL_SHA);
    for(unsigned i=0;i<R1D_TABLE_FLOATS;i++){float v;memcpy(&v,tables+4u*i,4u);s->table_data[i]=(double)v;}
    s->tables=(r1d_fbank_tables){R1DCF_TABLE_SCHEMA,400,80*257,s->table_data,s->table_data+400};
    if(!rc)rc=r1d_fbank_fbank_init(&s->bank,&s->tables);
    if(!rc)rc=r1d_pcm_init(&s->pcm,bank,s,emit,s);
    int restore=fesetenv(&env);
    if(rc || restore){free(s->weights);free(s);return NULL;}
    s->sink=sink;s->user=user;s->magic=R1D_MAGIC;return s;
}
int r1d_feed(r1d_stream *s,const unsigned char *data,size_t bytes,size_t *consumed){
    if(!consumed)return R1DCF_ARGUMENT;
    *consumed=0;
    if(!s || s->magic!=R1D_MAGIC || s->busy || s->mode==2)return R1DCF_STATE;
    if((!data && bytes) || bytes>UINT64_MAX-s->pcm.input_bytes)return R1DCF_ARGUMENT;
    if(!r1dfsmn_environment_ok())return R1DFSMN_ENVIRONMENT;
    fenv_t env;if(feholdexcept(&env))return R1DFSMN_ENVIRONMENT;
    s->busy=1;s->mode=1;s->delivery_end=(s->pcm.input_bytes+bytes)/2;
    int rc=r1d_pcm_feed(&s->pcm,data,bytes,consumed);
    s->busy=0;if(fesetenv(&env))return R1DFSMN_ENVIRONMENT;return rc;
}
int r1d_finish(r1d_stream *s){
    if(!s || s->magic!=R1D_MAGIC || s->busy || s->mode==2)return R1DCF_STATE;
    s->busy=1;int rc=r1d_pcm_finish(&s->pcm);s->busy=0;return rc;
}
int r1d_reset(r1d_stream *s){
    if(!s || s->magic!=R1D_MAGIC || s->busy)return R1DCF_STATE;
    int rc=r1dfsmn_reset(&s->net);if(rc)return rc;
    rc=r1d_pcm_init(&s->pcm,bank,s,emit,s);
    if(!rc){s->mode=0;s->frames=0;s->delivery_end=0;}
    return rc;
}
void r1d_destroy(r1d_stream *s){
    if(!s || s->magic!=R1D_MAGIC || s->busy)return;
    s->magic=0;free(s->weights);free(s);
}
int r1d_feature(r1d_stream *s,const double *feature,double *logits){
    if(!s || s->magic!=R1D_MAGIC || s->busy || s->mode==1)return R1DCF_STATE;
    fenv_t env;if(feholdexcept(&env))return R1DFSMN_ENVIRONMENT;
    s->busy=1;s->mode=2;
    int rc=r1dfsmn_step(&s->net,feature,400,logits,R1D_OUTPUTS,NULL,0);
    if(!rc)s->frames++;
    s->busy=0;if(fesetenv(&env))return R1DFSMN_ENVIRONMENT;return rc;
}
