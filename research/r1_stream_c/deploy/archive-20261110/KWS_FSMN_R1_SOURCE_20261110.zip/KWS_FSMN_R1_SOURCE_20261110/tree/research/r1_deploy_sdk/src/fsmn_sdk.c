/* SPDX-License-Identifier: Apache-2.0 */
#include "fsmn_sdk.h"
#include "fsmn_detector.h"
#include "r1d_stream.h"
#include "model_identity.h"
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#define SDK_MAGIC UINT32_C(0x46534d31)
struct fsmn_sdk {
    uint32_t magic;
    int busy,phase,callback_failed;
    uint64_t origin,bytes,segment,events;
    r1d_stream *core;
    fsmn_detector detector;
    fsmn_event_fn event_fn;
    fsmn_frame_fn frame_fn;
    void *user;
};
static int valid(const fsmn_sdk *s) { return s && s->magic==SDK_MAGIC; }
static int emit(void *user,uint64_t frame,uint64_t dependency,uint64_t delivery,
                const double *feature,const double *logits) {
    fsmn_sdk *s=(fsmn_sdk *)user;
    if (dependency>delivery || dependency>UINT64_MAX-s->origin || delivery>UINT64_MAX-s->origin)
        return FSMN_RANGE_ERROR;
    unsigned best=0;
    for (unsigned i=0;i<FSMN_LOGIT_COUNT;i++) {
        if (!isfinite(logits[i])) return FSMN_BACKEND_ERROR;
        if (logits[i]>logits[best]) best=i;
    }
    if (s->frame_fn && s->frame_fn(s->user,frame,s->origin+dependency,s->origin+delivery,feature,logits)) {
        s->callback_failed=1;return FSMN_CALLBACK_ERROR;
    }
    int keyword=fsmn_detector_step(&s->detector,frame,best);
    if (keyword<0) return FSMN_BACKEND_ERROR;
    if (keyword) {
        fsmn_event e={FSMN_SDK_ABI,(uint32_t)keyword,s->segment,frame,s->detector.token_frames[0],
                      s->origin+dependency,s->origin+delivery};
        s->events++;
        if (s->event_fn && s->event_fn(s->user,&e)) {
            s->callback_failed=1;return FSMN_CALLBACK_ERROR;
        }
    }
    return 0;
}
fsmn_sdk *fsmn_sdk_create(const unsigned char *model,size_t bytes,
        const unsigned char *tables,size_t table_bytes,uint64_t origin,
        fsmn_event_fn event_fn,fsmn_frame_fn frame_fn,void *user) {
    if (!model || bytes!=FSMN_MODEL_BYTES || !tables || table_bytes!=FSMN_TABLE_BYTES) return NULL;
    fsmn_sdk *s=(fsmn_sdk *)calloc(1,sizeof(*s));if (!s) return NULL;
    s->origin=origin;s->event_fn=event_fn;s->frame_fn=frame_fn;s->user=user;
    s->core=r1d_create(model,bytes,tables,table_bytes,emit,s);
    if (!s->core) { free(s);return NULL; }
    s->magic=SDK_MAGIC;fsmn_detector_init(&s->detector);return s;
}
int fsmn_sdk_feed(fsmn_sdk *s,const unsigned char *pcm,size_t bytes,size_t *consumed) {
    if (!consumed) return FSMN_BAD_ARGUMENT;
    *consumed=0;
    if (!valid(s) || s->busy || s->phase) return FSMN_BAD_STATE;
    if ((!pcm && bytes) || bytes>FSMN_MAX_INPUT_BYTES) return FSMN_BAD_ARGUMENT;
    if (bytes>UINT64_MAX-s->bytes-UINT64_C(9600) || (s->bytes+bytes)/2>UINT64_MAX-s->origin)
        return FSMN_RANGE_ERROR;
    s->busy=1;
    int rc=r1d_feed(s->core,pcm,bytes,consumed);
    s->bytes+=*consumed;s->busy=0;
    if (rc) { s->phase=2;return s->callback_failed?FSMN_CALLBACK_ERROR:FSMN_BACKEND_ERROR; }
    return FSMN_OK;
}
int fsmn_sdk_finish(fsmn_sdk *s) {
    if (!valid(s) || s->busy || s->phase) return FSMN_BAD_STATE;
    s->busy=1;int rc=r1d_finish(s->core);s->busy=0;s->phase=rc?2:1;
    return rc?FSMN_BACKEND_ERROR:FSMN_OK;
}
int fsmn_sdk_reset(fsmn_sdk *s,uint64_t origin) {
    if (!valid(s) || s->busy) return FSMN_BAD_STATE;
    if (s->segment==UINT64_MAX) return FSMN_RANGE_ERROR;
    int rc=r1d_reset(s->core);if (rc) { s->phase=2;return FSMN_BACKEND_ERROR; }
    s->origin=origin;s->bytes=0;s->events=0;s->phase=0;s->callback_failed=0;s->segment++;
    fsmn_detector_init(&s->detector);return FSMN_OK;
}
int fsmn_sdk_notify_gap(fsmn_sdk *s,uint64_t origin) {
    if (!valid(s) || s->busy) return FSMN_BAD_STATE;
    uint64_t end=s->bytes/2+s->bytes%2;
    if (end>UINT64_MAX-s->origin || origin<s->origin+end) return FSMN_RANGE_ERROR;
    return fsmn_sdk_reset(s,origin);
}
int fsmn_sdk_destroy(fsmn_sdk *s) {
    if (!valid(s) || s->busy) return FSMN_BAD_STATE;
    r1d_destroy(s->core);s->magic=0;free(s);return FSMN_OK;
}
uint64_t fsmn_sdk_frame_count(const fsmn_sdk *s) { return valid(s)?r1d_frames(s->core):0; }
uint64_t fsmn_sdk_event_count(const fsmn_sdk *s) { return valid(s)?s->events:0; }
uint64_t fsmn_sdk_consumed_bytes(const fsmn_sdk *s) { return valid(s)?s->bytes:0; }
size_t fsmn_sdk_state_bytes(void) { return sizeof(fsmn_sdk)+r1d_state_bytes(); }
size_t fsmn_sdk_weight_bytes(void) { return r1d_weight_bytes(); }
const char *fsmn_sdk_model_sha256(void) { return R1D_MODEL_SHA; }
const char *fsmn_sdk_table_sha256(void) { return R1D_FRONTEND_SHA; }
const char *fsmn_sdk_policy_id(void) { return "r1-greedy-complete-bounded-v1"; }
