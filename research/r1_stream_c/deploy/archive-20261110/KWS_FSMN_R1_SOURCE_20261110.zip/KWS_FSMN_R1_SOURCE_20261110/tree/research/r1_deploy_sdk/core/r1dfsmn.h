/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
/* Modified 2026-11-07: distinct R1 2601-output port. Original source pinned in PORT_SOURCES.json. */
/* SPDX-License-Identifier: Apache-2.0
 * Modified research port of WeKws FSMN, Yueyue Nyy (2022), Jing Du (2023).
 * See NOTICE.md. Not an audio frontend, decoder, or qualified board runtime. */
#ifndef R1DFSMN_H
#define R1DFSMN_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

#define R1DFSMN_FLOATS 757215u
#define R1DFSMN_PAYLOAD_BYTES (R1DFSMN_FLOATS * 4u)
#define R1DFSMN_INPUTS 400u
#define R1DFSMN_OUTPUTS 2601u
#define R1DFSMN_CACHE_FLOATS 5632u
#define R1DFSMN_TRACE_FLOATS 7601u
#define R1DFSMN_TRACE_FINAL_OFFSET 5000u
#define R1DFSMN_HEAD_WEIGHT_OFFSET 390474u
#define R1DFSMN_HEAD_BIAS_OFFSET 754614u
#define R1DFSMN_PAYLOAD_LITTLE_ENDIAN 1u

typedef enum {
    R1DFSMN_OK = 0, R1DFSMN_ARGUMENT = 1, R1DFSMN_SIZE = 2,
    R1DFSMN_IDENTITY = 3, R1DFSMN_NONFINITE = 4, R1DFSMN_STATE = 5,
    R1DFSMN_ENVIRONMENT = 6, R1DFSMN_OVERLAP = 7
} r1dfsmn_status;

typedef struct {
    const float *weights; /* caller-owned, immutable throughout model lifetime */
    double cache[R1DFSMN_CACHE_FLOATS]; /* [1][128][11][4], layer contiguous */
    uint32_t magic;
    int fault;
} r1dfsmn_model;

/* Caller must provide the stated accessible capacities. No allocation or I/O.
 * Headerless payload is little-endian FP32; endian selection is explicit.
 * expected_sha256 must be a readable 65-byte NUL-terminated lowercase hex
 * identity from a trusted export manifest, not computed from untrusted input.
 * Host is IEEE FP32 little-endian, RNE, gradual-underflow; never changes FP mode.
 * Floating-point exception traps MUST be masked by the caller. The portable
 * environment check does not verify trap masks; an unmasked trap can SIGFPE
 * before a NONFINITE return, including during sNaN validation or overflow.
 * Build with the fixed no-contraction/no-fast-math flags in build_synthetic.py;
 * environment_ok cannot detect compiler reassociation or fused instructions.
 * On loader failure model and decoded_weights are unchanged. Buffers disjoint.
 * The payload can be released after success; decoded_weights must remain alive. */
r1dfsmn_status r1dfsmn_load(r1dfsmn_model *model,
    float *decoded_weights, size_t weight_floats,
    const unsigned char *payload, size_t payload_bytes, unsigned payload_byte_order,
    const char expected_sha256[65]);

r1dfsmn_status r1dfsmn_reset(r1dfsmn_model *model);
r1dfsmn_status r1dfsmn_copy_cache(const r1dfsmn_model *model,
    double *output, size_t output_floats);

/* One pre-spliced 400D row, including CMVN internally, to 2599 raw logits.
 * input/output sizes must match exactly. Optional trace requires >=7599 floats:
 * stages 0..19 have stride250 (unused slots zero); final2599 begins at5000.
 * All buffers must be disjoint from state, weights and each other.
 * Invalid arguments leave state/output/trace unchanged. Arithmetic failure
 * faults the stream; cache/trace/output are invalid and must be discarded until
 * reset. No softmax, class reduction, quantization or implicit state reset.
 * Single-threaded and non-reentrant. */
r1dfsmn_status r1dfsmn_step(r1dfsmn_model *model,
    const double *input, size_t input_floats, double *output, size_t output_floats,
    double *trace, size_t trace_floats);

/* Checks little-endian/RNE/gradual-underflow, not exception-trap mask state. */
int r1dfsmn_environment_ok(void);
#ifdef __cplusplus
}
#endif
#endif
