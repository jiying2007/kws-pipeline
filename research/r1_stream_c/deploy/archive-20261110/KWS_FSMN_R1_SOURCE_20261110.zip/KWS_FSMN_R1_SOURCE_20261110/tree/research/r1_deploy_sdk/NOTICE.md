# R1 strong-FSMN research SDK: scope and attribution

This package wraps the exact R1-DEV-FSMN-20261107 trained checkpoint using the
separate Binary64 reference implementation already retained in kws-pipeline
#769/#770 at main 7b157c227101999d7a21462a1c17bc7f5248723e. New adapter,
bounded complete-keyword proposal detector, CLI, tests and build glue were
implemented for the user's technical research on 2026-11-10.

No original model/checkpoint, weights, labels, splits or original numerical
criteria have been altered. The historical FP32 C-versus-Torch/MKL gate remains
FAIL. Passing the distinct existing Binary64 reference contract does not turn
that earlier failure into a pass.

`core/NOTICE.md`, `core/LICENSE` and `core/LICENSE.torchaudio` are retained
historical attribution records. Descriptions there of the older 2599-class
adapter and padded EOF refer to those historical ancestors, not this API.
THIS SDK has 2601 outputs and does not append synthetic EOF PCM or frames.
Its generated Binary64 constants and transforms are separately pinned in the
source-recovery evidence. The original float32 trained weights remain unchanged.

The source license is Apache-2.0 with the retained torchaudio attribution.
The source license does not automatically confer a new license on checkpoints,
training/reference audio, individual voices, or derived data. The owner-only
research weight notice is retained unchanged in weights/NOTICE.owner-research.md.
Do not publish the private validation inputs or numerical outputs as part of a
source PR. Public source delivery contains no model weights or raw recordings.

The event detector emits uncalibrated, exact-complete-token research proposals.
It is not an independently validated or commercially qualified wake detector.
No physical SSC305, independent human FAR/FRR, calibrated latency, or INT8
performance is asserted by this software package.
