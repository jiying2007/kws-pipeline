/* SPDX-License-Identifier: Apache-2.0
 * Link-wrap audit of allocator calls from the linked SDK, using actual PCM.
 * Does not claim interception of allocator internals in arbitrary shared libs. */
#include "fsmn_sdk.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
void *__real_malloc(size_t);void *__real_calloc(size_t,size_t);
void *__real_realloc(void *,size_t);void __real_free(void *);
static int tracking;static unsigned long allocations,frees;static uint64_t events;
void *__wrap_malloc(size_t n) {if(tracking)allocations++;return __real_malloc(n);}
void *__wrap_calloc(size_t n,size_t z) {if(tracking)allocations++;return __real_calloc(n,z);}
void *__wrap_realloc(void *p,size_t n) {if(tracking)allocations++;return __real_realloc(p,n);}
void __wrap_free(void *p) {if(tracking)frees++;__real_free(p);}
static unsigned char *read_file(const char *name,size_t *n) {
    FILE *f=fopen(name,"rb");long end;if(!f)return NULL;
    if(fseek(f,0,SEEK_END)||(end=ftell(f))<0||end>16*1024*1024||fseek(f,0,SEEK_SET)){fclose(f);return NULL;}
    *n=(size_t)end;unsigned char *b=malloc(*n?*n:1);if(!b){fclose(f);return NULL;}
    if(fread(b,1,*n,f)!=*n||ferror(f)){free(b);fclose(f);return NULL;}
    if(fclose(f)){free(b);return NULL;}return b;
}
static int proposal(void *user,const fsmn_event *e) {
    (void)e;events++;return user?1:0;
}
int main(int argc,char **argv) {
    if(argc!=4&&argc!=5)return 2;
    size_t nw,nt,np;unsigned char *w=read_file(argv[1],&nw),*t=read_file(argv[2],&nt),*p=read_file(argv[3],&np);
    if(!w||!t||!p||(np&1u))return 2;
    int fail_event=argc==5&&strcmp(argv[4],"--fail-event")==0;
    fsmn_sdk *s=fsmn_sdk_create(w,nw,t,nt,0,proposal,NULL,fail_event?(void*)&fail_event:NULL);
    if(!s)return 2;
    int rc=0;size_t at=0;tracking=1;
    while(at<np&&!rc){size_t n=np-at;if(n>640)n=640;size_t used=0;rc=fsmn_sdk_feed(s,p+at,n,&used);at+=used;}
    uint64_t frames=fsmn_sdk_frame_count(s);int terminal_ok=1;
    if(fail_event){size_t used=99;terminal_ok=events==1&&rc==FSMN_CALLBACK_ERROR&&fsmn_sdk_feed(s,NULL,0,&used)==FSMN_BAD_STATE&&used==0;}
    else terminal_ok=rc==FSMN_OK&&at==np&&fsmn_sdk_finish(s)==FSMN_OK;
    int gap_ok=fsmn_sdk_notify_gap(s,np/2+100)==FSMN_OK;
    int reset_ok=fsmn_sdk_reset(s,0)==FSMN_OK&&fsmn_sdk_frame_count(s)==0&&fsmn_sdk_event_count(s)==0;
    tracking=0;
    int ok=terminal_ok&&gap_ok&&reset_ok&&allocations==0&&frees==0;
    printf("{\"pass\":%s,\"pcm_bytes_consumed\":%zu,\"frames\":%" PRIu64 ",\"events\":%" PRIu64 ",\"hotpath_allocation_calls\":%lu,\"hotpath_free_calls\":%lu,\"event_failure_mode\":%s,\"terminal_contract\":%s,\"gap_contract\":%s,\"reset_contract\":%s}\n",ok?"true":"false",at,frames,events,allocations,frees,fail_event?"true":"false",terminal_ok?"true":"false",gap_ok?"true":"false",reset_ok?"true":"false");
    if(fsmn_sdk_destroy(s))ok=0;
    free(p);free(t);free(w);return ok?0:1;
}
