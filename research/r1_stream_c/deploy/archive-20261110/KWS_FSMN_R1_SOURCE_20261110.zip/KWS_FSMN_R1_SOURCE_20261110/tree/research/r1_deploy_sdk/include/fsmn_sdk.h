/* SPDX-License-Identifier: Apache-2.0
 * R1-REFERENCE64 research SDK v1. Fixed weights; full 2601-class competition.
 * Single threaded, synchronous; do not re-enter/mutate/destroy from callbacks.
 * No allocation, lock, I/O or hidden worker is used in the feed path.
 * Create/destroy allocate/free state and a private decoded weight copy.
 * Inputs: signed16 little-endian, 16000 Hz mono PCM, after caller-owned AFE.
 * Research greedy proposals are NOT acoustically calibrated wake approvals. */
#ifndef FSMN_SDK_H
#define FSMN_SDK_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define FSMN_SDK_ABI 1u
#define FSMN_MAX_INPUT_BYTES 8192u
#define FSMN_MODEL_BYTES 3028860u
#define FSMN_TABLE_BYTES 83840u
#define FSMN_LOGIT_COUNT 2601u
#define FSMN_FEATURE_COUNT 400u
typedef struct fsmn_sdk fsmn_sdk;
typedef enum {
    FSMN_OK=0, FSMN_BAD_ARGUMENT=-1, FSMN_BAD_STATE=-2,
    FSMN_BACKEND_ERROR=-3, FSMN_CALLBACK_ERROR=-4, FSMN_RANGE_ERROR=-5
} fsmn_status;
typedef struct {
    uint32_t abi,keyword_id;
    uint64_t segment,model_frame,first_token_frame;
    uint64_t dependency_end_sample,delivery_end_sample;
} fsmn_event;
/* A nonzero callback return stops this segment; reset is required afterward. */
typedef int (*fsmn_event_fn)(void *user,const fsmn_event *event);
/* Optional diagnostic observer, NULL in deployment. Arrays are borrowed only
 * during the callback. source/dependency time is NOT acoustic keyword end. */
typedef int (*fsmn_frame_fn)(void *user,uint64_t frame,uint64_t dependency_end,
    uint64_t delivery_end,const double *features,const double *logits);
fsmn_sdk *fsmn_sdk_create(const unsigned char *model,size_t model_bytes,
    const unsigned char *tables,size_t table_bytes,uint64_t origin_sample,
    fsmn_event_fn event_fn,fsmn_frame_fn frame_fn,void *user);
/* At most FSMN_MAX_INPUT_BYTES per call. Odd byte chunks are supported;
 * an unmatched byte at finish is an error. Validation failures consume zero.
 * Callback/backend failures can consume a prefix: inspect *consumed. */
int fsmn_sdk_feed(fsmn_sdk *s,const unsigned char *pcm,size_t bytes,size_t *consumed);
/* End without padding, flushing artificial frames, or inventing events. */
int fsmn_sdk_finish(fsmn_sdk *s);
/* Reset for a new independent recording, including neural/PCM/decoder state. */
int fsmn_sdk_reset(fsmn_sdk *s,uint64_t origin_sample);
/* Explicit timeline gap. next_origin must not precede the consumed timeline.
 * Resets all states; missing audio is never bridged or filled with silence. */
int fsmn_sdk_notify_gap(fsmn_sdk *s,uint64_t next_origin_sample);
int fsmn_sdk_destroy(fsmn_sdk *s);
uint64_t fsmn_sdk_frame_count(const fsmn_sdk *s);
/* Count generated proposals, including one whose callback returned an error. */
uint64_t fsmn_sdk_event_count(const fsmn_sdk *s);
uint64_t fsmn_sdk_consumed_bytes(const fsmn_sdk *s);
size_t fsmn_sdk_state_bytes(void);
size_t fsmn_sdk_weight_bytes(void);
const char *fsmn_sdk_model_sha256(void);
const char *fsmn_sdk_table_sha256(void);
const char *fsmn_sdk_policy_id(void);
#ifdef __cplusplus
}
#endif
#endif
