/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
#ifndef R1D_REFERENCE_FBANK_H
#define R1D_REFERENCE_FBANK_H
#include <stddef.h>
#include <stdint.h>
/* Fixed researched contract, no generic configurable frontend. Tables must be
 * exported from the frozen runtime; this package deliberately has NO fake or
 * donor-Hamming fallback. Descriptor is a shape/version gate, not a hash proof:
 * runner must verify export manifest and array hashes before calling init.
 * Caller must preserve table lifetime/immutability throughout all calls. */
#define R1DCF_TABLE_SCHEMA UINT32_C(1)
typedef struct {
    uint32_t schema;
    size_t povey_count, mel_count;
    const double *povey; /* 400 float32; Torch hann(periodic=False).pow(.85) */
    const double *mel;   /* dense row-major 80*257, exact zero Nyquist column */
} r1d_fbank_tables;
typedef struct {
    uint32_t magic;
    const r1d_fbank_tables *tables;
    double re[512], im[512];
} r1d_fbank_fbank;
typedef struct {
    double dc[400], preemphasis[400], windowed[512];
    double magnitude[257], power[257], mel[80], logfbank[80];
} r1d_fbank_trace;
enum { R1DCF_FBANK_OK=0, R1DCF_FBANK_ARGUMENT=1, R1DCF_FBANK_TABLE=2,
       R1DCF_FBANK_STATE=3, R1DCF_FBANK_NONFINITE=4 };
int r1d_fbank_fbank_init(r1d_fbank_fbank *s, const r1d_fbank_tables *tables);
/* Exact 400 raw PCM16 amplitudes -> 80 raw logfbank float32. No scaling/CMVN.
 * Optional trace is for later diagnostic stage comparisons. Caller must not
 * overlap state, pcm, output, trace or immutable tables; not reentrant. */
int r1d_fbank_fbank_frame(r1d_fbank_fbank *s, const int16_t pcm[400], double row[80],
                    r1d_fbank_trace *trace);
int r1d_fbank_fbank_callback(void *state, const int16_t pcm[400], double row[80]);
#endif
