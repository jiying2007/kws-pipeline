/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
#ifdef KWS_B_PROFILE
#include "b_profile.h"
#endif
/* Research candidate, NOT numerically validated. FFT adapted from the isolated
 * donor_fbank.c radix2 skeleton, Apache-2.0. Algorithm semantics audited against
 * pinned Torchaudio compliance/kaldi.py, BSD-2-Clause. See NOTICE.md. */
#include "reference64_fbank.h"
#include <float.h>
#include <math.h>
#include <string.h>
/* Fixed binary64 twiddles below. */
#define R1DCF_BANK_MAGIC UINT32_C(0x4b463634)
_Static_assert(sizeof(double)==8 && FLT_RADIX==2 && DBL_MANT_DIG==53,
               "IEEE float32 required");
_Static_assert(sizeof(r1d_fbank_fbank)<=9216, "bounded FFT workspace");
/* Binary64 scratch FFT; input/output type follows the selected mode. */
_Static_assert(sizeof(double)==8 && DBL_MANT_DIG==53, "IEEE binary64 required");
#include "vendor/fft_twiddles_f64.h"
static void fft512(r1d_fbank_fbank *s) {
    double re[512], im[512];
    for(unsigned i=0;i<512;i++){re[i]=s->re[i];im[i]=s->im[i];}
    unsigned j=0;
    for(unsigned i=1;i<512;i++) {
        unsigned bit=256;
        while((j&bit)!=0){j^=bit;bit>>=1;}
        j^=bit;
        if(i<j){double v=re[i];re[i]=re[j];re[j]=v;v=im[i];im[i]=im[j];im[j]=v;}
    }
    for(unsigned len=2;len<=512;len<<=1)
        for(unsigned i=0;i<512;i+=len)
            for(unsigned k=0;k<len/2;k++) {
                unsigned a=i+k,b=a+len/2,t=k*(512/len);
                double wr=r1d_fft_cos64[t],wi=r1d_fft_sin64[t];
                double vr=re[b]*wr-im[b]*wi,vi=re[b]*wi+im[b]*wr;
                double ur=re[a],ui=im[a];
                re[a]=ur+vr;im[a]=ui+vi;re[b]=ur-vr;im[b]=ui-vi;
            }
    for(unsigned i=0;i<512;i++){s->re[i]=(double)re[i];s->im[i]=(double)im[i];}
}
int r1d_fbank_fbank_init(r1d_fbank_fbank *s, const r1d_fbank_tables *t) {
    if (!s) return R1DCF_FBANK_ARGUMENT;
    memset(s,0,sizeof(*s));
    if (!t || t->schema!=R1DCF_TABLE_SCHEMA || t->povey_count!=400 ||
        t->mel_count!=80*257 || !t->povey || !t->mel) return R1DCF_FBANK_TABLE;
    for (unsigned i=0;i<400;i++)
        if (!isfinite(t->povey[i]) || t->povey[i]<0 || t->povey[i]>1)
            return R1DCF_FBANK_TABLE;
    if (t->povey[0]!=0 || t->povey[399]!=0) return R1DCF_FBANK_TABLE;
    for (unsigned m=0;m<80;m++) {
        int positive=0;
        for (unsigned k=0;k<257;k++) {
            double w=t->mel[m*257+k];
            if (!isfinite(w) || w<0 || w>1) return R1DCF_FBANK_TABLE;
            if (w>0) positive=1;
        }
        if (!positive || t->mel[m*257+256]!=0) return R1DCF_FBANK_TABLE;
    }
    s->tables=t; s->magic=R1DCF_BANK_MAGIC;
    return R1DCF_FBANK_OK;
}
#ifdef KWS_B_PROFILE
static int r1d_fbank_fbank_frame_profile_impl(r1d_fbank_fbank *s, const int16_t pcm[400], double out[80], r1d_fbank_trace *t)
#else
int r1d_fbank_fbank_frame(r1d_fbank_fbank *s, const int16_t pcm[400], double out[80], r1d_fbank_trace *t)
#endif
{
    int32_t sum=0;
    double row[80];
    if (!s || !pcm || !out) return R1DCF_FBANK_ARGUMENT;
    if (s->magic!=R1DCF_BANK_MAGIC) return R1DCF_FBANK_STATE;
    /* Raw integer amplitudes: all 400-sample partial sums fit exactly into
     * binary32 (abs <= 13,107,200). Mean division/backend still must be tested. */
    for (unsigned i=0;i<400;i++) sum+=pcm[i];
    double mean=(double)sum/400.0;
    for (unsigned i=0;i<400;i++) s->re[i]=(double)pcm[i]-mean;
    if(t) memcpy(t->dc,s->re,sizeof(t->dc));
    /* Descending order preserves original previous sample. Separate multiply
     * and subtract; future build must disable FMA contraction/fast-math. */
    for(unsigned i=399;i>0;i--) s->re[i]=s->re[i]-0.97*s->re[i-1];
    s->re[0]=s->re[0]-0.97*s->re[0];
    if(t) memcpy(t->preemphasis,s->re,sizeof(t->preemphasis));
    for(unsigned i=0;i<400;i++) s->re[i]*=s->tables->povey[i];
    memset(s->re+400,0,112*sizeof(double)); memset(s->im,0,sizeof(s->im));
    if(t) memcpy(t->windowed,s->re,sizeof(t->windowed));
    fft512(s);
    for(unsigned i=0;i<257;i++) {
        /* Mirror abs().pow(2) operation order, NOT donor re^2+im^2 shortcut.
         * hypotf and Torch complex abs remain a measured numerical boundary. */
        double magnitude=hypot(s->re[i],s->im[i]);
        s->re[i]=magnitude*magnitude;
        if(!isfinite(s->re[i])) return R1DCF_FBANK_NONFINITE;
        if(t) t->magnitude[i]=magnitude;
    }
    if(t) memcpy(t->power,s->re,sizeof(t->power));
    for(unsigned m=0;m<80;m++) {
        double energy=0.0f;
        /* Dense increasing-bin scalar sum is explicit, not claimed equivalent
         * to the frozen torch.mm backend's reduction grouping. */
        for(unsigned k=0;k<257;k++) energy+=s->re[k]*s->tables->mel[m*257+k];
        if (!isfinite(energy)) return R1DCF_FBANK_NONFINITE;
        if(t) t->mel[m]=energy;
        row[m]=log(fmax(energy,FLT_EPSILON));
        if(!isfinite(row[m])) return R1DCF_FBANK_NONFINITE;
    }
    if(t) memcpy(t->logfbank,row,sizeof(row));
    memcpy(out,row,sizeof(row));
    return R1DCF_FBANK_OK;
}
int r1d_fbank_fbank_callback(void *s, const int16_t pcm[400], double row[80]) {
    return r1d_fbank_fbank_frame((r1d_fbank_fbank *)s,pcm,row,NULL);
}

#ifdef KWS_B_PROFILE
int r1d_fbank_fbank_frame(r1d_fbank_fbank *s, const int16_t pcm[400], double out[80], r1d_fbank_trace *t) {
 b_profile_stamp stamp=b_profile_begin();
 int rc=r1d_fbank_fbank_frame_profile_impl(s,pcm,out,t);
 b_profile_end(B_PROFILE_FRONTEND,stamp,rc==R1DCF_FBANK_OK);
 return rc;
}
#endif
