# 强预训练 FSMN：R1 研究 SDK 0.1.0

本包把原 R1-DEV-FSMN-20261107 做成独立、可构建和可运行的 C SDK。
**没有重新训练，也没有替换权重。** 部署后不需要 Python、Torch、ASR、TTS、
网络或模型下载。当前采用已经单独验证过的 Binary64 参考实现，优先保住强模型
的实际识别输出；不是已优化的 FP32/INT8 内核。

## 本包完成什么

- 原始 16 kHz / 单声道 / signed16 little-endian PCM → 原前端 → 完整 2601 类 FSMN → 完整关键词研究事件。
- “你好小窝”ID 1；“小窝小窝”ID 2。单独“小窝”、不完整输出和普通非空输出不会被当作完整词命中。
- 固定模型/前端 SHA256 校验；任意字节分块；EOF 不补零；真实断流显式清空前缀及模型状态。
- GCC、Clang、安装后的独立 C 调用、WAV/PCM/stdin、内存检查及实际音频测试。
- `MODEL_CARD.json` 与 `notes/VALIDATION_SUMMARY.json` 给出机器可读身份与结果。

## 1. 本机从源构建

在此目录执行。运行环境只需要相应系统 C 运行库；构建需要 CMake、C11 编译器。

```sh
sha256sum -c SHA256SUMS
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF
cmake --build build --parallel 2
```

研究 SDK 包包括 `weights/model.f32le` 与 `weights/frontend.f32le`。
公开源码包故意不含权重；使用本人已持有的固定文件，禁止用任意替代权重绕过哈希校验。
`bin/linux-x86_64/fsmn_run` 是本次主机二进制，不是 ARM 程序；不能假定适配任意 Linux ABI。
优先在自己的目标开发环境从源构建。

## 2. 运行 WAV 或持续 PCM

WAV 必须是单声道、16 kHz、PCM16；本程序不会隐式重采样或改音量。

```sh
./build/fsmn_run --research weights/model.f32le weights/frontend.f32le --wav your_audio.wav
./build/fsmn_run --research weights/model.f32le weights/frontend.f32le --pcm your_audio.pcm
cat your_audio.pcm | ./build/fsmn_run --research weights/model.f32le weights/frontend.f32le --pcm -
```

标准输出是逐事件 JSONL，`keyword_id` 为 1 或 2。标准错误是本次运行汇总。
事件类型为 `research_greedy_proposal`，`calibrated=false`；这是实际完整词输出的
研究触发提议，不是经过独立声学标定的最终唤醒批准。

`dependency_end_sample` 是该模型帧依赖的输入末端；`delivery_end_sample` 包括输入分块
造成的交付时间。二者均不能冒充人工标注的唤醒词结束时间，所以声学触发延迟为 null。

## 3. 集成到 Linux 音频线程

```sh
cmake --install build --prefix "$PWD/install"
cc -std=c11 -O2 -Iinstall/include examples/file_consumer.c \
  install/lib/libfsmn_sdk_static.a -lm -o file_consumer
./file_consumer weights/model.f32le weights/frontend.f32le your_audio.pcm
```

应用启动时读取权重并调用 `fsmn_sdk_create`。捕获线程每次向 `fsmn_sdk_feed` 传入最多
8192 字节；640 字节对应 20 ms 的输入块，可减少接口交付等待。检查返回值以及 `consumed`。
正常 EOF 调用 `fsmn_sdk_finish`，最后 `fsmn_sdk_destroy`。

发生音频丢失/切换时调用 `fsmn_sdk_notify_gap(handle,next_absolute_sample)`；不允许时间倒退，
也不会用猜测的静音填补缺失。新独立录音使用 `fsmn_sdk_reset`。任一后端/回调错误后当前段终止，
必须显式重置。回调中不能重入、销毁或修改同一 handle；事件指针只在回调期间有效。
每个 handle 由一个线程拥有；不要依赖内部锁。示例只在调用者外层进行文件 I/O。

create/destroy 允许分配/释放；feed/finish/reset/gap 不在 SDK 内进行分配、锁、文件操作或创建线程。
本次链接拦截实测覆盖 8 条真实输入调用，热路径分配和释放调用均为 0；这不是对任意系统库
内部行为的普遍证明。SDK 状态 249392 字节，解码后的 FP32 权重 3028860 字节，合计 3278252 字节；
还须另算调用者输入缓冲、栈、运行库及系统开销，不能把它当作 SSC305 总 RSS。

## 4. 可执行检查

无权重的检测器测试只需要标准 Python，不会调用模型：

```sh
cmake -S . -B build-test -DBUILD_TESTING=ON
cmake --build build-test --parallel 2
ctest --test-dir build-test --output-on-failure
```

显式加入固定权重 API 测试（零 PCM 的接口检查，不是声学效果验收）：

```sh
cmake -S . -B build-test -DBUILD_TESTING=ON -DFSMN_TEST_WEIGHTS="$PWD/weights"
cmake --build build-test --parallel 2
ctest --test-dir build-test --output-on-failure
```

ASan/UBSan 主机检查：

```sh
cmake -S . -B build-asan -DCMAKE_C_COMPILER=clang -DFSMN_SANITIZE=ON -DBUILD_TESTING=OFF
cmake --build build-asan --parallel 2
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 \
  ./build-asan/fsmn_run --research weights/model.f32le weights/frontend.f32le --wav your_audio.wav
```

## 5. ARM / SSC305 接续

提供 `cmake/armv7-hardfloat.cmake` 作为通用 Cortex-A32/ARMv7 hard-float 构建入口。
必须核实实际 SSC305 SDK 的 ABI、libc、浮点约定和编译器；不能直接假定通用 hard-float 工具链
与实际固件兼容。本次环境没有该工具链和设备，因此 **新 SDK ARM 构建、SSC305 运行和性能均 NOT_RUN**。
本次另重放了既有 ARM Binary64 核心的 4 条 QEMU 用例；那不是新适配层的 ARM 构建或真机验收。
不要把 `bin/linux-x86_64` 上传到 ARM 后当作可运行程序。

## 6. 已验证与未验证

134 条原音、380.0800625 秒、12534 个唯一模型帧；新 SDK 的 2 编译器 × 2 分块 = 536 组
输出与既有 Binary64 参考逐位一致；全部 argmax 与完整 greedy 序列也保持原 Torch 保存输出。
4 条逐字节分块通过。原权重、模型 hash 和标签身份未改变，4 条未知行不进入效果分母。

34 条已曝光的合成机器弱标注开发数据：两个完整词均 10/10 命中、各 0/24 负例行误报，
新的有界事件提议也保持这些计数。不是独立测试，更不是“100% 商用品质”或连续负流 FAR。
本策略冻结了 150 帧完整词跨度、50 帧连续 blank 清前缀、每词 50 帧冷却；没有调阈值选最佳结果。
后续应在新数据上显式标定，而非倒用本批开发数据。

旧 FP32/Torch-MKL 兼容门仍 FAIL。本包的 Binary64 通过属于单独的原有数值合同，不能覆盖旧失败。
独立真人/口音、自然连续负流 FAR、最终 AFE、声学词尾延迟、INT8 与物理 SSC305 仍待实际测量。

## 7. 来源与公开范围

参见 `NOTICE.md` 和 `weights/NOTICE.owner-research.md`。源代码许可不自动扩大模型/数据/声音权利。
SDK 包是交付给项目拥有者的技术研究包；公开源码补丁不含权重、PCM、逐条标签或原始转录。
本次没有远端提交、PR 或合并。源码补丁仍需原仓库的保留清单登记、官方 CI 接入和受保护审核，
不能把本地 CTest 当作已经完成的全仓 CI。

## 8. 不依赖 Torch 的本地证据重放

另一个私有证据包保存原134条 PCM、原身份清单及本次逐行预期输出哈希。
解压证据包后，可用本 SDK 的标准库工具重放；这会实际再次推理，不会训练：

```sh
python3 -B tools/replay_owned_capsule.py \
  --capsule /path/to/KWS_FSMN_R1_EVIDENCE_20261110 \
  --library "$PWD/build/libfsmn_sdk.so" --weights "$PWD/weights" \
  --output /path/to/new-replay-directory
```

默认重放全部134条；`--indices` 只用于明确标识的子集接口验收，不会宣称全量通过。
此工具采用相同主机精确字节回归，不是跨架构容差比较器。若换了浮点实现/系统库，
不能通过改预期哈希制造通过，应另行做原数值合同的完整比较。
原 Torch 张量逐元素诊断还依赖恢复索引列出的原有数值包及锁定环境，未冒充已全部装进 SDK。
