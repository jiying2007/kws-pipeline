"""ctypes test binding. Deployment itself is pure C and does not import Python."""
from __future__ import annotations
import ctypes as C
from pathlib import Path
class Event(C.Structure):
    _fields_=[('abi',C.c_uint32),('keyword_id',C.c_uint32),('segment',C.c_uint64),('model_frame',C.c_uint64),('first_token_frame',C.c_uint64),('dependency_end_sample',C.c_uint64),('delivery_end_sample',C.c_uint64)]
class Detector(C.Structure):
    _fields_=[('next_frame',C.c_uint64),('token_frames',C.c_uint64*4),('next_allowed',C.c_uint64*2),('tokens',C.c_uint32*4),('used',C.c_uint32),('previous',C.c_uint32),('blank_run',C.c_uint32)]
EVENT=C.CFUNCTYPE(C.c_int,C.c_void_p,C.POINTER(Event))
FRAME=C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_uint64,C.c_uint64,C.c_uint64,C.POINTER(C.c_double),C.POINTER(C.c_double))
def load(path:Path):
    l=C.CDLL(str(Path(path).resolve()))
    l.fsmn_sdk_create.argtypes=[C.c_void_p,C.c_size_t,C.c_void_p,C.c_size_t,C.c_uint64,EVENT,FRAME,C.c_void_p];l.fsmn_sdk_create.restype=C.c_void_p
    l.fsmn_sdk_feed.argtypes=[C.c_void_p,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t)];l.fsmn_sdk_feed.restype=C.c_int
    for name in ['finish','destroy']:
        f=getattr(l,'fsmn_sdk_'+name);f.argtypes=[C.c_void_p];f.restype=C.c_int
    for name in ['reset','notify_gap']:
        f=getattr(l,'fsmn_sdk_'+name);f.argtypes=[C.c_void_p,C.c_uint64];f.restype=C.c_int
    for name in ['frame_count','event_count','consumed_bytes']:
        f=getattr(l,'fsmn_sdk_'+name);f.argtypes=[C.c_void_p];f.restype=C.c_uint64
    for name in ['state_bytes','weight_bytes']:
        f=getattr(l,'fsmn_sdk_'+name);f.argtypes=[];f.restype=C.c_size_t
    for name in ['model_sha256','table_sha256','policy_id']:
        f=getattr(l,'fsmn_sdk_'+name);f.argtypes=[];f.restype=C.c_char_p
    l.fsmn_detector_init.argtypes=[C.POINTER(Detector)];l.fsmn_detector_init.restype=None
    l.fsmn_detector_step.argtypes=[C.POINTER(Detector),C.c_uint64,C.c_uint32];l.fsmn_detector_step.restype=C.c_int
    return l
