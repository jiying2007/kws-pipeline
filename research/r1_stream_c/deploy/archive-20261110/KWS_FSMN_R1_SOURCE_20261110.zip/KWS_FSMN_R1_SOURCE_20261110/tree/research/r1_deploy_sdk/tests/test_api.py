"""Actual fixed-weight API tests on generated zero PCM; not speech quality."""
from __future__ import annotations
import ctypes as C,importlib.util,os,unittest,struct
from pathlib import Path
P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('binding',P/'tools/binding.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        weights=Path(os.environ.get('FSMN_TEST_WEIGHTS',str(P/'weights')))
        cls.l=b.load(Path(os.environ['FSMN_LIBRARY']));cls.w=(weights/'model.f32le').read_bytes();cls.t=(weights/'frontend.f32le').read_bytes()
    def setUp(self):
        self.events=[];self.frames=[];self.reentry=None;self.fail_frame=False
        def event(_,e):self.events.append(tuple(getattr(e.contents,k) for k,_ in b.Event._fields_));return 0
        def frame(_,i,a,z,f,l):
            self.frames.append((i,a,z,C.string_at(l,2601*8)))
            if self.reentry:
                n=C.c_size_t(99);self.reentry_results=(self.l.fsmn_sdk_feed(self.s,None,0,C.byref(n)),n.value,self.l.fsmn_sdk_reset(self.s,0),self.l.fsmn_sdk_destroy(self.s))
            return 1 if self.fail_frame else 0
        self.ec=b.EVENT(event);self.fc=b.FRAME(frame)
        self.s=self.l.fsmn_sdk_create(self.w,len(self.w),self.t,len(self.t),0,self.ec,self.fc,None);self.assertTrue(self.s)
    def tearDown(self):
        if self.s:self.assertEqual(self.l.fsmn_sdk_destroy(self.s),0)
    def feed(self,data):
        n=C.c_size_t(99);rc=self.l.fsmn_sdk_feed(self.s,data,len(data),C.byref(n));return rc,n.value
    def test_wrong_weight_identity(self):
        w=bytearray(self.w);w[80]^=1
        self.assertFalse(self.l.fsmn_sdk_create(bytes(w),len(w),self.t,len(self.t),0,self.ec,self.fc,None))
    def test_wrong_table_identity(self):
        t=bytearray(self.t);t[0]^=1
        self.assertFalse(self.l.fsmn_sdk_create(self.w,len(self.w),bytes(t),len(t),0,self.ec,self.fc,None))
    def test_wrong_lengths(self):self.assertFalse(self.l.fsmn_sdk_create(self.w,len(self.w)-1,self.t,len(self.t),0,self.ec,self.fc,None))
    def test_empty_stream(self):self.assertEqual(self.feed(b''),(0,0));self.assertEqual(self.l.fsmn_sdk_finish(self.s),0);self.assertEqual(self.frames,[])
    def test_oversize_no_mutation(self):self.assertEqual(self.feed(b'\0'*8193),(-1,0));self.assertEqual(self.l.fsmn_sdk_consumed_bytes(self.s),0)
    def test_null_data_no_mutation(self):
        n=C.c_size_t(99);self.assertEqual(self.l.fsmn_sdk_feed(self.s,None,2,C.byref(n)),-1);self.assertEqual(n.value,0)
    def test_no_eof_padding(self):
        self.assertEqual(self.feed(b'\0'*1438),(0,1438));self.assertEqual(self.l.fsmn_sdk_finish(self.s),0);self.assertEqual(self.frames,[])
    def test_first_dependency_exact(self):
        self.assertEqual(self.feed(b'\0'*1440),(0,1440));self.assertEqual(self.frames[0][:3],(0,720,720));self.assertEqual(self.l.fsmn_sdk_finish(self.s),0)
    def test_odd_chunks_supported(self):
        self.assertEqual(self.feed(b'\0'),(0,1));self.assertEqual(self.feed(b'\0'*1439),(0,1439));self.assertEqual(self.frames[0][:3],(0,720,720))
    def test_odd_eof_terminal(self):
        self.assertEqual(self.feed(b'\0'),(0,1));self.assertEqual(self.l.fsmn_sdk_finish(self.s),-3);self.assertEqual(self.feed(b'\0'),(-2,0))
    def test_closed_stream_rejects_feed_and_finish(self):
        self.assertEqual(self.l.fsmn_sdk_finish(self.s),0);self.assertEqual(self.feed(b'\0\0'),(-2,0));self.assertEqual(self.l.fsmn_sdk_finish(self.s),-2)
    def test_reset_numerically_reproducible(self):
        self.feed(b'\0'*4000);first=[x[3] for x in self.frames];self.assertEqual(self.l.fsmn_sdk_reset(self.s,0),0);self.frames=[]
        self.feed(b'\0'*4000);self.assertEqual(first,[x[3] for x in self.frames])
    def test_gap_new_origin_all_states_reset(self):
        self.feed(b'\0'*2000);self.assertEqual(self.l.fsmn_sdk_notify_gap(self.s,2000),0);self.frames=[];self.feed(b'\0'*1440)
        self.assertEqual(self.frames[0][:3],(0,2720,2720));self.assertEqual(self.l.fsmn_sdk_consumed_bytes(self.s),1440)
    def test_backward_gap_rejected_without_reset(self):
        self.feed(b'\0'*2000);n=self.l.fsmn_sdk_frame_count(self.s);self.assertEqual(self.l.fsmn_sdk_notify_gap(self.s,999),-5);self.assertEqual(self.l.fsmn_sdk_frame_count(self.s),n)
    def test_partial_sample_gap_checked(self):
        self.feed(b'\0');self.assertEqual(self.l.fsmn_sdk_notify_gap(self.s,0),-5);self.assertEqual(self.l.fsmn_sdk_notify_gap(self.s,1),0)
    def test_timestamp_overflow_no_consumption(self):
        self.assertEqual(self.l.fsmn_sdk_reset(self.s,2**64-1),0);self.assertEqual(self.feed(b'\0\0'),(-5,0))
    def test_callback_failure_terminal_with_prefix_consumption(self):
        self.fail_frame=True;rc,n=self.feed(b'\0'*4096);self.assertEqual(rc,-4);self.assertEqual(n,1440);self.assertEqual(self.feed(b'\0\0'),(-2,0))
    def test_reentry_rejected(self):
        self.reentry=True;self.feed(b'\0'*1440);self.assertEqual(self.reentry_results,(-2,0,-2,-2))
    def test_two_handles_independent(self):
        s2=self.l.fsmn_sdk_create(self.w,len(self.w),self.t,len(self.t),0,b.EVENT(),b.FRAME(),None);self.assertTrue(s2)
        try:
            self.feed(b'\0'*1440);self.assertEqual(self.l.fsmn_sdk_frame_count(s2),0)
            n=C.c_size_t();self.assertEqual(self.l.fsmn_sdk_feed(s2,b'\0'*1440,1440,C.byref(n)),0);self.assertEqual(self.l.fsmn_sdk_frame_count(s2),1)
        finally:self.assertEqual(self.l.fsmn_sdk_destroy(s2),0)
    def test_immutable_asset_pins(self):
        self.assertEqual(self.l.fsmn_sdk_model_sha256().decode(),'e9a3c3360bab0485b309eb2a3ef50869a8e917f50f28dbfd30673f57a88c86bb')
        self.assertEqual(self.l.fsmn_sdk_table_sha256().decode(),'49c42226c617fad81c5edb683a6332bdb82b52e37040f724eac23522a504db49')
if __name__=='__main__':unittest.main(verbosity=2)
