/* Opt-in R1 numeric research variant; legacy FP32 gate unchanged. */
/* Modified 2026-11-07: R1 no-padding EOF; preserve upstream body transport. */
#ifndef R1D_REFERENCE_PCM_H
#define R1D_REFERENCE_PCM_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Research-only canonical frame-step transport. No CMVN, network or decoder.
 * Caller owns state, callbacks and user storage. Single-threaded, no API calls
 * on the same state from callbacks (including init). No allocation. */
enum { R1DCF_OK=0, R1DCF_ARGUMENT=1, R1DCF_STATE=2, R1DCF_ODD_EOF=3,
       R1DCF_BANK=4, R1DCF_NONFINITE=5, R1DCF_SINK=6, R1DCF_OVERFLOW=7 };
enum { R1DCF_EVENT_FBANK=1, R1DCF_EVENT_CONTEXT=2 };
enum { R1DCF_PHASE_OPEN=0, R1DCF_PHASE_EOF=1, R1DCF_PHASE_CLOSED=2,
       R1DCF_PHASE_FAILED=3 };
typedef int (*r1d_fbank_bank_fn)(void *user, const int16_t pcm[400], double row[80]);
/* Row is 80 floats for FBANK or 400 floats for CONTEXT, valid only during call.
 * index: global fbank j or context m. center: j for FBANK or 3*m for CONTEXT.
 * end_sample: exclusive required padded-stream sample (400 + 160*j).
 * eof: this event was made available by the one true EOF tail.
 * Return 0 iff accepted; nonzero is sticky fatal failure (no retry/replay).
 * An acknowledged FBANK event always precedes its immediately-ready CONTEXT. */
typedef int (*r1d_fbank_emit_fn)(void *user, int event, uint64_t index,
                         uint64_t center, uint64_t end_sample, int eof,
                         const double *row);
typedef struct {
    uint32_t magic;
    int phase, busy, error, callback_error, failed_event;
    uint64_t failed_index;
    size_t used;
    unsigned have_low;
    uint8_t low;
    uint64_t input_bytes, real_samples, padded_samples;
    uint64_t fbank_attempted, fbank_frames, fbank_accepted;
    uint64_t context_attempted, context_accepted;
    unsigned eof_attempted, eof_completed, zero_samples;
    int16_t pcm[400];
    double history[5][80];
    double context[400];
    r1d_fbank_bank_fn bank;
    r1d_fbank_emit_fn emit;
    void *bank_user, *emit_user;
} r1d_pcm;
int r1d_pcm_init(r1d_pcm *s, r1d_fbank_bank_fn bank, void *bank_user,
                 r1d_fbank_emit_fn emit, void *emit_user);
/* Arbitrary little-endian byte chunks, including odd boundaries and zero size.
 * consumed is mandatory. On failure it identifies the consumed prefix; the
 * stream is poisoned after processing/callback failure, never silently skips.
 * Caller must not alias data/consumed with state or mutate it during a call. */
int r1d_pcm_feed(r1d_pcm *s, const uint8_t *data, size_t bytes, size_t *consumed);
/* Only at real recording EOF, once. Reject a pending odd byte BEFORE adding
 * zeros. Append zero samples, retain residual PCM for audit, never pad
 * right context, never flush at I/O or decoder-window boundaries. */
int r1d_pcm_finish(r1d_pcm *s);
#ifdef __cplusplus
}
#endif
#endif
