/* SPDX-License-Identifier: Apache-2.0
 * Standalone Linux research runner. No Python, Torch, model downloads or APIs. */
#define _POSIX_C_SOURCE 200809L
#include "fsmn_sdk.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>
#include <sys/resource.h>
#include <errno.h>
#include <limits.h>
static uint16_t u16(const unsigned char *p) { return (uint16_t)((unsigned)p[0]|((unsigned)p[1]<<8)); }
static uint32_t u32(const unsigned char *p) { return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static unsigned char *read_exact(const char *path,size_t n) {
    FILE *f=fopen(path,"rb");if (!f) return NULL;
    unsigned char *b=(unsigned char *)malloc(n);if (!b) {fclose(f);return NULL;}
    int bad=(fread(b,1,n,f)!=n || fgetc(f)!=EOF || ferror(f));
    if (fclose(f)) bad=1;
    if (bad) { free(b);return NULL; }return b;
}
/* Seekable RIFF/WAVE only. Strictly bounded chunks; reject duplicate fmt/data,
 * wrong channels/rate/type and inconsistent declared RIFF/file lengths. */
static int wav_data(FILE *f,uint64_t *remaining) {
    unsigned char h[16];long end;uint64_t pos=12,data_offset=0,data_size=0;int fmt=0,data=0;
    if (fseek(f,0,SEEK_END) || (end=ftell(f))<12 || fseek(f,0,SEEK_SET)) return -1;
    if (fread(h,1,12,f)!=12 || memcmp(h,"RIFF",4) || memcmp(h+8,"WAVE",4) ||
        (uint64_t)u32(h+4)+8!=(uint64_t)end) return -1;
    while (pos<(uint64_t)end) {
        if ((uint64_t)end-pos<8 || fread(h,1,8,f)!=8) return -1;
        uint32_t n=u32(h+4);pos+=8;
        uint64_t padded=(uint64_t)n+(n&1u);
        if (padded>(uint64_t)end-pos) return -1;
        if (!memcmp(h,"fmt ",4)) {
            if (fmt || (n!=16 && n!=18) || fread(h,1,16,f)!=16) return -1;
            if (u16(h)!=1 || u16(h+2)!=1 || u32(h+4)!=16000 ||
                u32(h+8)!=32000 || u16(h+12)!=2 || u16(h+14)!=16) return -1;
            if (n==18) { if (fread(h,1,2,f)!=2 || u16(h)!=0) return -1; }
            fmt=1;
        } else if (!memcmp(h,"data",4)) {
            if (data || !fmt || (n&1u)) return -1;
            data=1;data_offset=pos;data_size=n;
        }
        pos+=padded;
        if (pos>(uint64_t)LONG_MAX || fseek(f,(long)pos,SEEK_SET)) return -1;
    }
    if (!fmt || !data || data_offset>(uint64_t)LONG_MAX || fseek(f,(long)data_offset,SEEK_SET)) return -1;
    *remaining=data_size;return 0;
}
static double monotonic_seconds(void) {
    struct timespec t;if (clock_gettime(CLOCK_MONOTONIC,&t)) return -1.0;
    return (double)t.tv_sec+(double)t.tv_nsec*1e-9;
}
static int event(void *user,const fsmn_event *e) {
    (void)user;
    int n=printf("{\"type\":\"research_greedy_proposal\",\"policy\":\"r1-greedy-complete-bounded-v1\",\"keyword_id\":%u,\"segment\":%" PRIu64 ",\"model_frame\":%" PRIu64 ",\"first_token_frame\":%" PRIu64 ",\"dependency_end_sample\":%" PRIu64 ",\"delivery_end_sample\":%" PRIu64 ",\"calibrated\":false,\"word_end_latency_ms\":null}\n",
        e->keyword_id,e->segment,e->model_frame,e->first_token_frame,e->dependency_end_sample,e->delivery_end_sample);
    return n<0 || fflush(stdout)?1:0;
}
int main(int argc,char **argv) {
    size_t chunk=640;int wav;
    if ((argc!=6 && argc!=8) || strcmp(argv[1],"--research") ||
        (strcmp(argv[4],"--wav") && strcmp(argv[4],"--pcm"))) {
        fprintf(stderr,"Usage: %s --research MODEL.f32le FRONTEND.f32le (--wav FILE.wav | --pcm FILE.pcm-or--) [--chunk-bytes 1..8192]\nResearch proposals only; model weights fixed; mono16k PCM16; no EOF padding.\n",argv[0]);return 2;
    }
    if (argc==8) {
        char *tail=NULL;errno=0;unsigned long v=strtoul(argv[7],&tail,10);
        if (strcmp(argv[6],"--chunk-bytes") || errno || !tail || *tail || !*argv[7] || !v || v>FSMN_MAX_INPUT_BYTES) return 2;
        chunk=(size_t)v;
    }
    wav=!strcmp(argv[4],"--wav");
    if (wav && !strcmp(argv[5],"-")) {fprintf(stderr,"WAV input must be seekable; use --pcm - for raw stdin.\n");return 2;}
    FILE *input=!strcmp(argv[5],"-")?stdin:fopen(argv[5],"rb");if (!input) {perror("input");return 2;}
    uint64_t remain=UINT64_MAX;
    if (wav && wav_data(input,&remain)) {fprintf(stderr,"Rejected malformed/non-mono16kPCM16 WAV.\n");fclose(input);return 2;}
    unsigned char *w=read_exact(argv[2],FSMN_MODEL_BYTES),*t=read_exact(argv[3],FSMN_TABLE_BYTES);
    fsmn_sdk *s=fsmn_sdk_create(w,w?FSMN_MODEL_BYTES:0,t,t?FSMN_TABLE_BYTES:0,0,event,NULL,NULL);free(w);free(t);
    if (!s) {fprintf(stderr,"Rejected model/table identity or platform.\n");if (input!=stdin) fclose(input);return 2;}
    unsigned char buf[FSMN_MAX_INPUT_BYTES];uint64_t bytes=0;int rc=0;double start=monotonic_seconds();
    if (start<0) rc=1;
    while (!rc && remain) {
        size_t want=remain<chunk?(size_t)remain:chunk;
        size_t n=fread(buf,1,want,input);if (!n) {if (ferror(input) || wav) rc=1;break;}
        size_t consumed=0;rc=fsmn_sdk_feed(s,buf,n,&consumed);bytes+=consumed;
        if (consumed!=n) rc=rc?rc:1;
        if (wav) remain-=n;
    }
    if (ferror(input)) rc=1;
    if (input!=stdin && fclose(input)) rc=1;
    if (!rc) rc=fsmn_sdk_finish(s);
    double stop=monotonic_seconds(),elapsed=stop-start;if (stop<0 || elapsed<0) rc=1;
    struct rusage usage;int usage_ok=getrusage(RUSAGE_SELF,&usage)==0;
    fprintf(stderr,"{\"status\":\"%s\",\"pcm_bytes\":%" PRIu64 ",\"model_frames\":%" PRIu64 ",\"proposals\":%" PRIu64 ",\"compute_and_io_seconds\":%.9f,\"eof_padding_samples\":0,\"model_state_bytes\":%zu,\"decoded_weight_bytes\":%zu,\"max_rss_kib\":%ld,\"physical_ssc305\":false,\"calibrated_far\":null}\n",rc?"failed":"complete",bytes,fsmn_sdk_frame_count(s),fsmn_sdk_event_count(s),elapsed,fsmn_sdk_state_bytes(),fsmn_sdk_weight_bytes(),usage_ok?usage.ru_maxrss:-1L);
    if (fsmn_sdk_destroy(s)) rc=1;
    return rc?2:0;
}
