#!/usr/bin/env python3
"""Synthetic initializer regression; no real donor model or inference."""
import importlib.util, json, pathlib, sys, unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]
PLAN = json.loads((ROOT / 'plan-2026111001.json').read_text())
SOURCE = pathlib.Path(PLAN['recovered_root']) / 'source'
sys.path[:0] = [str(ROOT/'source'), str(SOURCE), str(SOURCE/'training'), str(SOURCE/'tools')]
import run_fsmn_seed as worker
import seeded_fsmn as new
import research_d1_models as old
import research_weak_train as runtime
torch, _ = runtime.torch_runtime()

class SeedContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.state = {old.FSMN_WEIGHT: torch.linspace(-0.1, 0.1, 2599*140).reshape(2599,140),
                     old.FSMN_BIAS: torch.linspace(-0.1, 0.1, 2599),
                     'unrelated.buffer': torch.tensor([1., 2.])}
    def test_old_seed_matches_retained_initializer(self):
        a, ar = old.extend_fsmn_state(self.state)
        b, br = new.extend_fsmn_state(self.state, seed=20261105)
        self.assertEqual(ar,br)
        self.assertTrue(all(torch.equal(a[k],b[k]) for k in a))
    def test_new_seeds_change_only_two_rows_and_reproduce(self):
        a, _ = new.extend_fsmn_state(self.state, seed=2026111001)
        b, _ = new.extend_fsmn_state(self.state, seed=2026111002)
        c, _ = new.extend_fsmn_state(self.state, seed=2026111001)
        for result in (a,b,c):
            self.assertTrue(torch.equal(result[old.FSMN_WEIGHT][:2599],self.state[old.FSMN_WEIGHT]))
            self.assertTrue(torch.equal(result[old.FSMN_BIAS][:2599],self.state[old.FSMN_BIAS]))
            self.assertTrue(torch.equal(result['unrelated.buffer'],self.state['unrelated.buffer']))
        self.assertFalse(torch.equal(a[old.FSMN_WEIGHT][2599:],b[old.FSMN_WEIGHT][2599:]))
        self.assertFalse(torch.equal(a[old.FSMN_BIAS][2599:],b[old.FSMN_BIAS][2599:]))
        self.assertTrue(all(torch.equal(a[k],c[k]) for k in a))
    def test_undeclared_seed_rejected(self):
        for seed in (2026111003,True,2026111001.0):
            with self.assertRaises(ValueError):new.extend_fsmn_state(self.state,seed=seed)
    def test_complete_input_and_plan_bindings(self):
        for seed in (2026111001,2026111002):
            p=json.loads((ROOT / f'plan-{seed}.json').read_text())
            worker.inputs(p)
    def test_seed_budget_or_source_tampering_rejected(self):
        for key,value in [('seed',20261105),('worker_sha256','0'*64),('new_source_hashes',{'seeded_fsmn.py':'0'*64})]:
            p=json.loads(json.dumps(PLAN));p[key]=value
            with self.assertRaises(ValueError):worker.inputs(p)
        p=json.loads(json.dumps(PLAN));p['budget']['steps']=2001
        with self.assertRaises(ValueError):worker.validate(p)

if __name__=='__main__':unittest.main(verbosity=2)
