#!/usr/bin/env python3
"""Read completed saved evidence only; do not construct or run any model."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text())


def rows(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def contains(sequence, target):
    return any(sequence[i:i+len(target)] == target
               for i in range(len(sequence)-len(target)+1))


def score(observations, roster, vocabulary, new_ids):
    require(set(observations) == {r['source_id'] for r in roster}, 'closed roster')
    result = {}
    for split in ('train', 'development', 'old-development', 'new-development'):
        result[split] = []
        for kid, text in enumerate(('你好小窝', '小窝小窝')):
            target = [vocabulary['token_to_id'][c] for c in text]
            c = {'keyword_id': kid+1, 'known_positive': 0, 'hits': 0,
                 'known_negative': 0, 'false_positive_rows': 0, 'unknown': 0}
            for row in roster:
                if split in ('train', 'development'):
                    if row['split'] != split:
                        continue
                elif row['split'] != 'development' or ((row['source_id'] in new_ids)
                        != split.startswith('new-')):
                    continue
                if not row['keyword_mask'][kid]:
                    c['unknown'] += 1
                    continue
                require(row['keyword_targets'][kid] == int(text in row['full_text']),
                        'observed full transcript label mismatch')
                predicted = contains(observations[row['source_id']], target)
                if row['keyword_targets'][kid] == 1:
                    c['known_positive'] += 1
                    c['hits'] += int(predicted)
                else:
                    c['known_negative'] += 1
                    c['false_positive_rows'] += int(predicted)
            result[split].append(c)
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--campaign', type=Path, required=True)
    ap.add_argument('--baseline-package', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    a = ap.parse_args()
    root, package = a.campaign.resolve(), a.baseline_package.resolve()
    campaign = read(root/'CAMPAIGN.json')
    terminal = read(root/'TERMINAL.json')
    require(terminal['status'] == 'completed', 'campaign not complete')
    first = read(campaign['plans'][0]['plan'])
    inputs = Path(first['recovered_root'])
    job, vocab = read(inputs/'request.json'), read(inputs/'vocabulary.json')
    baseline_index = read(package/'evidence/final-numeric-index.json')
    new_ids = {r['source_id'] for r in job['all_new_rows']}
    baseline_sequences = {k:v['greedy_token_ids'] for k,v in baseline_index.items()}
    baseline_counts = score(baseline_sequences, job['evaluation_rows'], vocab, new_ids)
    card = read(package/'MODEL.json')
    baseline = {'seed': 20261105, 'new_training': False,
                'checkpoint_sha256': card['checkpoint_sha256'],
                'float_state_sha256': card['float_state_sha256'],
                'counts': baseline_counts}
    observed, passed = [], []
    for entry in campaign['plans']:
        seed = entry['seed']; d = root/('seed-'+str(seed)); run = d/'run'
        p, s = read(entry['plan']), read(run/'summary.json')
        t, audit = read(d/'terminal.json'), read(d/'saved-output-audit.json')
        require(sha(entry['plan']) == entry['plan_sha256'] == s['plan_sha256']
                == audit['plan_sha256'], 'plan linkage')
        require(t['returncode'] == 0 and not t['timed_out'], 'supervised exit')
        require(read(run/'status.json')['status'] == 'completed'
                and audit['status'] == 'verified', 'terminal audit')
        require(sha(run/'MANIFEST.json') == audit['manifest_sha256'], 'audited manifest')
        require(sha(run/'final.pt') == s['checkpoint_sha256']
                == audit['checkpoint_sha256'], 'checkpoint linkage')
        obs = rows(run/'observations.jsonl')
        require(len(obs) == 134, 'final denominator')
        sequences = {r['source_id']:r['greedy_token_ids'] for r in obs}
        require(len(sequences) == 134, 'duplicate final observations')
        counts = score(sequences, job['evaluation_rows'], vocab, new_ids)
        feature_equal = all(r['feature_sha256'] == baseline_index[r['source_id']]['feature_sha256']
                            for r in obs)
        require(feature_equal, 'feature change')
        original_rule = s['paired']['development_rule_pass']
        no_regression = all(c['hits'] == b['hits']
                            and c['false_positive_rows'] == b['false_positive_rows']
                            for split in ('old-development','new-development')
                            for c,b in zip(counts[split], baseline_counts[split]))
        passed.append(original_rule and no_regression)
        observed.append({
            'seed': seed, 'new_training': True, 'checkpoint_sha256': s['checkpoint_sha256'],
            'float_state_sha256': s['float_state_sha256'],
            'initial_float_state_sha256': s['initial_float_state_sha256'],
            'plan_sha256': entry['plan_sha256'],
            'counts': counts, 'development': s['conditions']['development'],
            'original_development_rule_pass': original_rule,
            'original_r1_counts_preserved_per_cohort': no_regression,
            'all_134_feature_hashes_match_original': feature_equal,
            'greedy_sequences_matching_original': sum(sequences[k] == baseline_sequences[k] for k in sequences),
            'optimizer_updates': audit['optimizer_steps_verified'],
            'training_forwards': audit['training_forwards_verified'],
            'final_forwards': audit['final_numeric_conditions_verified'],
            'final_unique_frames': audit['final_numeric_frames_verified'],
            'worker_wall_seconds': s['wall_seconds'], 'supervisor_wall_seconds': t['wall_seconds'],
            'audit_sha256': sha(d/'saved-output-audit.json'),
            'closed_files_verified': audit['closed_files_verified'],
            'frozen_tensors_unchanged': s['frozen_tensors_unchanged']})
    require(len({x['float_state_sha256'] for x in [baseline]+observed}) == 3,
            'not three distinct trained states')
    result = {
        'schema': 'kws-r1-initialization-seed-confirmation-result-v1',
        'status': 'PASS_LIMITED_INITIALIZATION_CONFIRMATION' if all(passed) else 'FAIL_CONFIRMATION_RETAIN_ORIGINAL_R1',
        'scope': 'Only the two appended output rows (沃 and 灯) change initialization; unchanged fixed training order and pretrained donor. These are the same exposed synthetic weak-label recordings, not independent acoustic tests.',
        'baseline': baseline, 'new_seeds': observed,
        'retained_primary_model': 'R1-DEV-FSMN-20261107',
        'retained_primary_checkpoint_sha256': card['checkpoint_sha256'],
        'best_seed_selection': False, 'threshold_or_learning_rate_sweep': False,
        'new_optimizer_updates': sum(x['optimizer_updates'] for x in observed),
        'new_training_forwards': sum(x['training_forwards'] for x in observed),
        'new_final_forwards': sum(x['final_forwards'] for x in observed),
        'unique_recordings': 134, 'train_rows': 96, 'exposed_development_rows': 34,
        'unknown_zero_loss_rows': 4, 'new_tts_calls': 0, 'new_asr_calls': 0,
        'original_baseline_forwards': 0,
        'independent_human_frr': 'NOT_RUN', 'continuous_natural_far': 'NOT_RUN',
        'word_end_latency': 'NOT_RUN', 'physical_ssc305': 'NOT_RUN',
        'original_fp32_torch_gate': 'FAIL_UNCHANGED',
        'campaign_sha256': sha(root/'CAMPAIGN.json'),
        'source_hashes': {p.name:sha(p) for p in sorted((root/'source').glob('*.py'))},
        'finished_at': datetime.now(timezone.utc).isoformat()}
    with a.output.open('x',encoding='utf-8') as f:
        json.dump(result,f,sort_keys=True,indent=2,ensure_ascii=False);f.write('\n')
    print(json.dumps({'status':result['status'],'new_updates':result['new_optimizer_updates'],
                      'new_training_forwards':result['new_training_forwards'],
                      'new_final_forwards':result['new_final_forwards'],
                      'primary_changed':False},sort_keys=True))


if __name__ == '__main__':
    main()
