#!/usr/bin/env python3
"""Fixed native FSMN tail/head adaptation of retained balanced64 weak data.

Different native frontend and pretraining from C1: system comparison, not a
single-variable architecture ablation. No ASR, TTS, old checkpoint inference,
heldout tuning, event-time fabrication, or automatic model promotion.
"""
from __future__ import annotations
import argparse,collections,fcntl,hashlib,json,os,pathlib,resource,signal,sys,time
from datetime import datetime,timezone
SCHEMA='kws-v3-fsmn-init-seed-confirmation-v1'
PREFIXES=('backbone.out_linear2.','backbone.fsmn.3.','backbone.out_linear1.')

def require(ok,reason):
 if not ok:raise ValueError(reason)
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def utc():return datetime.now(timezone.utc).isoformat()

def validate(p):
 require(all(type(v) is int for v in p['budget'].values()),'integer budget required')
 require(p['schema']==SCHEMA and p['experiment_id']=='v3-fsmn-init-seed-20261110-'+str(p['seed']),'identity')
 require(p['budget']=={'steps':2000,'draws':8000,'batch':4,'final_forwards':134,'model_constructions':1,'worker_seconds':1200,'hard_seconds':1260,'intra_threads':1,'interop_threads':1},'budget')
 require(p['optimizer']=={'name':'AdamW','lr':0.0001,'weight_decay':0.01,'gradient_clip':5.0},'optimizer')
 require(p['trainable_prefixes']==list(PREFIXES) and type(p['seed']) is int and p['seed'] in (2026111001,2026111002),'fixed trainable prefixes and declared new seeds')
 require(p['frontend']=={'native':True,'mel_bins':80,'input_width':400,'frame_ms':25,'hop_ms':10,'frame_skip':3,'left_context':2,'right_context':2,'dither':0.0,'added_silence_ms':0,'known_silence_loss':False},'native frontend')
 require(p['source_recipe_sha256']=='75b5743222f96dde75fca0191159cb74a4a53d55531e625d4a4d255b46f2b0cd','source recipe')
 require(p['pretrained_sha256']=='d3d89b5dde08c2926d46a97eab6f7179a87b1946ccebd16c02e77042ea8389fe','official init')
 require(p['selection']=='per-keyword/per-old-new-cohort no regression and at least one gain, no added weak-negative FP; development only','decision')
 require(p['new_calls']=={'tts':0,'asr':0,'old_c1_forwards':0},'no replay')

def inputs(p):
 validate(p);require(sha(__file__)==p['worker_sha256'],'worker pin')
 base=pathlib.Path(p['recovered_root']);source=base/'source'
 for name,digest in p['new_source_hashes'].items():require(sha(pathlib.Path(__file__).parent/name)==digest,'seed adapter changed '+name)
 for name,digest in p['source_hashes'].items():require(sha(source/name)==digest,'source changed '+name)
 for name,digest in p['input_hashes'].items():require(sha(base/name)==digest,'input changed '+name)
 job=read(base/'request.json');mapping=read(base/'asset-readback.json');vocab=read(base/'vocabulary.json')
 require(len(job['train'])==96 and len(job['development'])==34 and len(job['evaluation_rows'])==134,'complete roster')
 require(job['evaluation_rows'][:96]==job['train'],'fixed order')
 require(all(r['ctc_mask'] is True and r['split']=='train' and r['source_role']=='train-candidate' for r in job['train']),'training roles')
 for name in ('speaker_id','source_family_id','pcm_sha256','original_pcm_sha256','parent_source_sha256','reference_pcm_sha256'):
  groups=[{r.get(name) for r in rows if r.get(name)} for rows in (job['train'],job['development'])]
  require(not groups[0]&groups[1],'source split leak')
 for r in job['evaluation_rows']:
  if r['ctc_mask']:
   require(r['full_text'] and r['target_ids']==[vocab['token_to_id'][c] for c in r['full_text']] and r['ctc_weight'] in (.5,1.0),'observed full text only')
  else:require(r['target_ids'] is None and r['ctc_weight']==0,'unknown zero loss')
  pin=mapping['resolved_audio'][r['source_id']];require(sha(pin['path'])==r['file_sha256'],'audio pin')
  frames=(1+(r['samples']-400)//160)//3
  if r['ctc_mask']:require(frames>=len(r['target_ids'])+sum(a==b for a,b in zip(r['target_ids'],r['target_ids'][1:])),'native geometry infeasible')
 require(sha(p['control_observations']['path'])==p['control_observations']['sha256'],'control observation pin')
 return base,source,job,mapping,vocab

def comparison(old,observed,rows,new_ids):
 old={r['source_id']:r for r in old if r['offset_ms']==0};by_id={r['source_id']:r for r in observed}
 require(set(old)==set(by_id)=={r['source_id'] for r in rows},'complete comparison roster')
 result={};passes=[];gains=[]
 for origin in ('old','new'):
  pairs=[]
  for row in rows:
   if row['split']!='development' or (row['source_id'] in new_ids)!=(origin=='new'):continue
   a,b=old[row['source_id']],by_id[row['source_id']]
   require(a['label_binding_sha256']==b['label_binding_sha256'],'label binding drift')
   pairs.append((a,b))
  words=[]
  for kid in range(2):
   positive=[];negative=[];unknown=0
   for a,b in pairs:
    aa,bb=a['keywords'][kid],b['keywords'][kid]
    require(aa['known']==bb['known'] and aa['reference']==bb['reference'],'keyword state drift')
    if not aa['known']:unknown+=1
    elif aa['reference']==1:positive.append((aa,bb))
    else:negative.append((aa,bb))
   c=sum(a['complete_sequence_present'] for a,b in positive);n=sum(b['complete_sequence_present'] for a,b in positive)
   cf=sum(a['complete_sequence_present'] for a,b in negative);nf=sum(b['complete_sequence_present'] for a,b in negative)
   words.append({'keyword_id':kid+1,'positive_rows':len(positive),'control_hits':c,'candidate_hits':n,'negative_rows':len(negative),
                 'control_false_positive_rows':cf,'candidate_false_positive_rows':nf,'unknown_rows':unknown,
                 'gained_hits':sum(not a['complete_sequence_present'] and b['complete_sequence_present'] for a,b in positive),
                 'lost_hits':sum(a['complete_sequence_present'] and not b['complete_sequence_present'] for a,b in positive)})
   passes.append(n>=c and nf<=cf);gains.append(n>c)
  result[origin+'-development']=words
 return {'cohorts':result,'development_rule_pass':all(passes) and any(gains),'independent_winner':False,
         'natural_far_available':False,'event_frr_available':False,'latency_available':False,
         'comparison_scope':'native-pretrained-FSMN vs saved C1 on identical weak development rows; different native frontend, initialized model, training augmentation and objective terms'}

def run(plan_file,expected,out):
 require(sha(plan_file)==expected,'external plan pin');p=read(plan_file);base,source,job,mapping,vocab=inputs(p)
 require(sys.version_info[:3]==(3,12,16),'runtime')
 lockpath=pathlib.Path(p['lock_path']);lockpath.parent.mkdir(parents=True,exist_ok=True)
 with lockpath.open('a+b') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  out=pathlib.Path(out);out.mkdir(mode=0o700,exist_ok=False)
  sys.path[:0]=[str(pathlib.Path(__file__).parent),str(source),str(source/'training'),str(source/'tools')]
  import research_c1_source_augmentation as engine
  import research_fsmn_weak as official
  tr=engine.training;ev=engine.evaluation
  tr.save_json(out/'intent.json',{'schema':SCHEMA,'pid':os.getpid(),'started_at':utc(),'plan_sha256':expected,'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'automatic_retry':False})
  status={'status':'running','model_constructions':0,'optimizer_steps':0,'training_forwards_started':0,'training_forwards_completed':0,'evaluation_forwards_started':0,'evaluation_forwards_completed':0}
  tr.save_json(out/'status.json',status);started=time.monotonic()
  def expired(a,b):raise TimeoutError('fixed FSMN worker deadline')
  signal.signal(signal.SIGALRM,expired);signal.setitimer(signal.ITIMER_REAL,1200)
  try:
   require(sha(p['runtime_manifest'])==p['runtime_manifest_sha256'],'runtime lock pin')
   runtime=tr.research_runtime.load_manifest(pathlib.Path(p['runtime_manifest']));tr.research_runtime.check_interpreter(runtime);tr.research_runtime.check_packages(runtime,'core')
   torch,reference=tr.torch_runtime();torch.manual_seed(p['seed'])
   from training_state import state_identity,atomic_save_checkpoint,load_checkpoint_snapshot
   sources=pathlib.Path(p['official_sources']);official.verify_sources(sources)
   require(sha(sources/'avg_30.pt')==p['pretrained_sha256'],'pretrained bytes')
   _,_,processor=official.load_upstream(sources,torch)
   rows=job['evaluation_rows'];bank=[];evidence=[]
   for row in rows:
    relative_audio=pathlib.Path(mapping['resolved_audio'][row['source_id']]['path']).relative_to(base).as_posix()
    r={**row,'audio':relative_audio,'audio_path':relative_audio,
       'expected_output_frames':{'fsmn':(1+(row['samples']-400)//160)//3},'ctc_minimum_frames':row['ctc_minimum_frames'] or 0}
    pcm=ev.read_pcm(base,r)
    feature=ev.native_features(pcm,r,'fsmn-head-ctc2601',torch,processor)
    bank.append(feature);evidence.append({'source_id':row['source_id'],'split':row['split'],'pcm_sha256':row['pcm_sha256'],
      'feature_sha256':tr.tensor_sha(feature),'shape':list(feature.shape),'label_binding_sha256':engine.fit.row_identity(row)})
   tr.save_json(out/'feature-bindings.json',evidence)
   from seeded_fsmn import build_extended_fsmn
   model,_,description=build_extended_fsmn(sources,vocab,seed=p['seed']);status['model_constructions']=1
   selected=[]
   for name,param in model.named_parameters():
    param.requires_grad_(name.startswith(PREFIXES))
    if param.requires_grad:selected.append((name,param))
   require(selected and all(any(name.startswith(prefix) for name,_ in selected) for prefix in PREFIXES),'tail and head must be present')
   initial=state_identity(model.state_dict());frozen={n:tr.tensor_sha(t) for n,t in model.state_dict().items() if n not in {n for n,_ in selected}}
   atomic_save_checkpoint({'schema':SCHEMA,'architecture':description,'state_dict':model.state_dict(),'float_state_identity':initial,'official_checkpoint_sha256':p['pretrained_sha256'],'plan_sha256':expected},out/'initial.pt')
   optimizer=torch.optim.AdamW([v for n,v in selected],lr=.0001,weight_decay=.01)
   model.train()
   for step in range(2000):
    optimizer.zero_grad(set_to_none=True);losses=[];draws=[]
    for i in range(step*4,step*4+4):
     index=i%96;row=job['train'][index];require(row['source_id']==rows[index]['source_id'],'train/eval join')
     call={'ordinal':i,'source_id':row['source_id'],'label_binding_sha256':engine.fit.row_identity(row),'feature_sha256':evidence[index]['feature_sha256']}
     tr.append_json(out/'forward-calls.jsonl',{**call,'phase':'started'});status['training_forwards_started']+=1
     logits=model(bank[index].unsqueeze(0));status['training_forwards_completed']+=1
     require(tuple(logits.shape)==(len(bank[index]),1,2601) and bool(logits.isfinite().all()),'forward shape/finiteness')
     tr.append_json(out/'forward-calls.jsonl',{**call,'phase':'completed'})
     loss,raw=tr.fulltext_ctc(logits,row['target_ids'],row['ctc_weight'],True,normalizer=1.0)
     losses.append(loss);draws.append({**call,'weight':row['ctc_weight'],'raw_length_normalized_ctc':raw.item(),'weighted_contribution':loss.detach().item()/4})
    batch=torch.stack(losses).mean();require(bool(batch.isfinite()),'loss finite');batch.backward()
    require(all(v.grad is not None and bool(v.grad.isfinite().all()) for n,v in selected),'finite selected gradients')
    require(all(v.grad is None for n,v in model.named_parameters() if not v.requires_grad),'frozen gradient')
    norm=torch.nn.utils.clip_grad_norm_([v for n,v in selected],5.0);require(bool(norm.isfinite()),'finite gradient norm')
    tr.append_json(out/'optimizer-calls.jsonl',{'step':step+1,'phase':'started','completed_forwards':status['training_forwards_completed']})
    optimizer.step();status['optimizer_steps']+=1
    tr.append_json(out/'optimizer-calls.jsonl',{'step':step+1,'phase':'completed','completed_forwards':status['training_forwards_completed']})
    tr.append_json(out/'consumption.jsonl',{'step':step+1,'loss':batch.item(),'gradient_norm':norm.item(),'draws':draws})
    if (step+1)%100==0:
     heartbeat={'at':utc(),'steps':step+1,'training_forwards':status['training_forwards_completed'],'wall_seconds':time.monotonic()-started}
     tr.save_json(out/'heartbeat.json',heartbeat);print(json.dumps(heartbeat),flush=True)
   require(all(tr.tensor_sha(model.state_dict()[n])==h for n,h in frozen.items()),'frozen pretrained tensors changed')
   final=state_identity(model.state_dict());require(initial!=final,'no parameters changed')
   payload={'schema':SCHEMA,'candidate':'fsmn-tail-ctc2601','state_dict':model.state_dict(),'optimizer_state':optimizer.state_dict(),
      'float_state_identity':final,'initial_float_state_identity':initial,'architecture':description,'trainable_parameters':[n for n,v in selected],
      'optimizer_steps':2000,'training_forwards':8000,'source_recipe_sha256':p['source_recipe_sha256'],'official_checkpoint_sha256':p['pretrained_sha256'],
      'vocabulary_sha256':job['vocabulary_sha256'],'source_hashes':p['source_hashes'],'plan_sha256':expected,'worker_sha256':p['worker_sha256'],
      'rng_state':torch.get_rng_state(),'resume_supported':False,'independent_test':False,'human_gold':False}
   atomic_save_checkpoint(payload,out/'final.pt');saved,checkpoint_sha=load_checkpoint_snapshot(out/'final.pt')
   require(state_identity(saved['state_dict'])==final,'checkpoint readback')
   require(all(float(s['step'])==2000 and bool(s['exp_avg'].isfinite().all()) and bool(s['exp_avg_sq'].isfinite().all()) for s in saved['optimizer_state']['state'].values()),'optimizer readback')
   model.load_state_dict(saved['state_dict'],strict=True);model.eval();observed=[]
   with torch.inference_mode():
    for index,row in enumerate(rows):
     tr.append_json(out/'evaluation-calls.jsonl',{'ordinal':index,'source_id':row['source_id'],'phase':'started'});status['evaluation_forwards_started']+=1
     logits=model(bank[index].unsqueeze(0));status['evaluation_forwards_completed']+=1
     artifact=ev.save_numeric(out/'numeric'/f'{index:03}.pt',row['source_id'],bank[index],logits)
     ids=ev.collapse_ctc(logits[:,0].argmax(-1).tolist())
     obs={'source_id':row['source_id'],'source_family_id':row['source_family_id'],'split':row['split'],'offset_ms':0,
          'label_binding_sha256':engine.fit.row_identity(row),'feature_sha256':tr.tensor_sha(bank[index]),'pcm_sha256':row['pcm_sha256'],
          'logits_sha256':tr.tensor_sha(logits),'numeric_artifact':{'path':f'numeric/{index:03}.pt',**artifact},'ctc_weight':row['ctc_weight'],
          'greedy_token_ids':ids,'keywords':engine.diagnostic.keyword_observations(ids,row,vocab),
          'evaluation_status':'evaluated' if row['ctc_mask'] else 'not-evaluable'}
     if row['ctc_mask']:obs.update(ev.score_logits(logits,row))
     else:obs['reason']='unknown_full_text'
     tr.append_json(out/'observations.jsonl',obs);observed.append(obs)
     tr.append_json(out/'evaluation-calls.jsonl',{'ordinal':index,'source_id':row['source_id'],'phase':'completed'})
   require(status['training_forwards_completed']==8000 and status['optimizer_steps']==2000 and status['evaluation_forwards_completed']==134,'terminal counts')
   require(state_identity(model.state_dict())==final,'inference changed state')
   baseline=[json.loads(x) for x in pathlib.Path(p['control_observations']['path']).read_text().splitlines()]
   paired=comparison(baseline,observed,rows,{r['source_id'] for r in job['all_new_rows']})
   result={'schema':SCHEMA,'status':'completed','experiment_id':p['experiment_id'],'actual':status,'checkpoint_sha256':checkpoint_sha,
           'float_state_sha256':final['sha256'],'initial_float_state_sha256':initial['sha256'],'trainable_names':[n for n,v in selected],
           'trainable_elements':sum(v.numel() for n,v in selected),'parameter_elements':sum(v.numel() for v in model.parameters()),'frozen_tensors_unchanged':True,
           'plan_sha256':expected,'paired':paired,'conditions':{split:ev.summarize([r for r in observed if r['split']==split]) for split in ('train','development')},
           'wall_seconds':time.monotonic()-started,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
           'runtime':{'python':sys.version.split()[0],'torch':torch.__version__,'threads':torch.get_num_threads()},
           'new_tts':0,'new_asr':0,'old_c1_forwards':0,'independent_winner':False,'ssc305_measured':False,'finished_at':utc()}
   tr.save_json(out/'summary.json',result);status['status']='completed';tr.save_json(out/'status.json',status)
   tr.save_json(out/'MANIFEST.json',{f.relative_to(out).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(out.rglob('*')) if f.is_file()})
   print(json.dumps({k:v for k,v in result.items() if k not in ('conditions','trainable_names')}),flush=True)
  except BaseException as e:
   status.update(status='failed',failure_type=type(e).__name__,reason=str(e),wall_seconds=time.monotonic()-started,finished_at=utc())
   tr.save_json(out/'status.json',status);raise
  finally:signal.setitimer(signal.ITIMER_REAL,0)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--plan',required=True);parser.add_argument('--plan-sha256',required=True);parser.add_argument('--output',required=True)
 a=parser.parse_args();run(a.plan,a.plan_sha256,a.output)
