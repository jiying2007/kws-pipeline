#!/usr/bin/env python3
"""Run exactly two predeclared fresh seeds serially; never retry or replace output."""
import datetime, hashlib, json, os, pathlib, signal, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(path,obj):
    with path.open('x') as f:
        json.dump(obj,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    if sys.version_info[:3]!=(3,12,16):raise RuntimeError('canonical Python required')
    c=json.loads((ROOT/'CAMPAIGN.json').read_text());w=ROOT/'source/run_fsmn_seed.py'
    if sha(w)!=c['worker_sha256']:raise ValueError('worker drift')
    if [p['seed'] for p in c['plans']]!=[2026111001,2026111002]:raise ValueError('plan roster drift')
    for p in c['plans']:
        if sha(p['plan'])!=p['plan_sha256']:raise ValueError('plan drift')
    save(ROOT/'EXECUTION_INTENT.json',{'campaign_sha256':sha(ROOT/'CAMPAIGN.json'),'started_at':utc(),'pid':os.getpid(),'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'automatic_retry':False})
    terminals=[]
    for p in c['plans']:
        work=ROOT/('seed-'+str(p['seed']));work.mkdir(mode=0o700)
        command=[sys.executable,'-I','-B',str(w),'--plan',p['plan'],'--plan-sha256',p['plan_sha256'],'--output',str(work/'run')]
        save(work/'intent.json',{'command':command,'started_at':utc(),'hard_seconds':1260,'automatic_retry':False})
        start=time.monotonic()
        with (work/'stdout.log').open('xb') as stdout,(work/'stderr.log').open('xb') as stderr:
            child=subprocess.Popen(command,stdout=stdout,stderr=stderr,cwd=ROOT,env=os.environ.copy(),start_new_session=True)
            save(work/'worker.json',{'pid':child.pid,'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
            try:rc=child.wait(timeout=1260);timed=False
            except subprocess.TimeoutExpired:
                timed=True;os.killpg(child.pid,signal.SIGTERM)
                try:rc=child.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);rc=child.wait(timeout=10)
        terminal={'seed':p['seed'],'plan_sha256':p['plan_sha256'],'returncode':rc,'timed_out':timed,'wall_seconds':time.monotonic()-start,'finished_at':utc()}
        save(work/'terminal.json',terminal);terminals.append(terminal);print(json.dumps(terminal),flush=True)
        if rc or timed:
            save(ROOT/'TERMINAL.json',{'status':'stopped_no_retry','seeds':terminals,'finished_at':utc()});return 1
    save(ROOT/'TERMINAL.json',{'status':'completed','seeds':terminals,'finished_at':utc()});return 0
if __name__=='__main__':raise SystemExit(main())
