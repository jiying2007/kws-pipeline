#!/usr/bin/env python3
"""Restore owner-held R1 inputs and prepare a fresh two-seed confirmation.

No model is constructed or executed by this script. Run supervise.py only for
an explicitly authorized new confirmation/reproduction, never to recover an
already-completed result. Historical source and evidence remain unchanged.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

CARD_SHA = '2079fce70bcd27d2991ce558807b3ef9707309051e6915946fc01821f8350936'
SEEDS = (2026111001, 2026111002)


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, sort_keys=True, indent=2)
        f.write('\n')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package', type=Path, required=True)
    ap.add_argument('--capsule', type=Path, required=True)
    ap.add_argument('--work', type=Path, required=True)
    ap.add_argument('--lock', type=Path, required=True)
    a = ap.parse_args()
    if sys.version_info[:3] != (3, 12, 16):
        raise ValueError('canonical CPython 3.12.16 required')
    package, capsule, work = a.package.resolve(), a.capsule.resolve(), a.work.absolute()
    if work.exists() or any(p.is_symlink() for p in (work, *work.parents)):
        raise ValueError('fresh real work directory required')
    if sha(package / 'MODEL.json') != CARD_SHA:
        raise ValueError('exact owner-held R1 model card required')
    card = json.loads((package / 'MODEL.json').read_text())
    for name, pin in card['files'].items():
        p = package / name
        if p.stat().st_size != pin['bytes'] or sha(p) != pin['sha256']:
            raise ValueError('original R1 package drift: ' + name)
    work.mkdir(mode=0o700)
    source = work / 'source'
    source.mkdir()
    for name in ('run_fsmn_seed.py', 'seeded_fsmn.py', 'supervise.py',
                 'test_seed_initializer.py', 'prepare_confirmation.py'):
        shutil.copyfile(Path(__file__).parent / name, source / name)
    restore = work / 'restored'
    subprocess.run([sys.executable, '-I', '-B', str(package / 'reproduce_fsmn.py'),
                    '--package', str(package), '--capsule', str(capsule),
                    '--work', str(restore), '--lock', str(a.lock.absolute())],
                   check=True, timeout=120)
    base = json.loads((restore / 'plan.json').read_text())
    for key in ('reproduction', 'prior_attempt', 'attempt'):
        base.pop(key, None)
    parent = package / 'source/original/training/research_d1_models.py'
    base.update(
        schema='kws-v3-fsmn-init-seed-confirmation-v1',
        worker_sha256=sha(source / 'run_fsmn_seed.py'),
        new_source_hashes={'seeded_fsmn.py': sha(source / 'seeded_fsmn.py')},
        preregistered_at=datetime.now(timezone.utc).isoformat(),
        hypothesis='Measure sensitivity to the two appended classifier-row initialization seeds, retaining pretrained donor, complete original training schedule, native frontend, optimizer and exposed weak development cohort.',
        confirmation={
            'baseline_seed': 20261105, 'new_seeds': list(SEEDS),
            'baseline_checkpoint_sha256': card['checkpoint_sha256'],
            'source_adapter_parent_sha256': sha(parent),
            'worker_parent_sha256': sha(package / 'training/source/run_fsmn.py'),
            'only_scientific_change': 'two appended classifier weight/bias rows use declared seed; no shuffling/dropout or augmentation introduced',
            'baseline_replayed': False, 'automatic_retry': False,
            'candidate_selection': 'keep original R1; report all seeds and per-cohort complete-word counts; never select best new seed',
            'confirmation_pass': 'both new seeds pass unchanged per-keyword/per-old-new-cohort comparison against retained C1 and match original R1 development 10/10 per keyword with no additional known-weak-negative rows',
            'generalization_authority': False, 'independent_test': False})
    plans = []
    for seed in SEEDS:
        p = json.loads(json.dumps(base))
        p['seed'] = seed
        p['experiment_id'] = 'v3-fsmn-init-seed-20261110-' + str(seed)
        path = work / ('plan-' + str(seed) + '.json')
        save(path, p)
        plans.append({'seed': seed, 'plan': str(path), 'plan_sha256': sha(path)})
    campaign = {
        'schema': 'kws-r1-bounded-init-confirmation-campaign-v1', 'plans': plans,
        'new_models_max': 2, 'optimizer_updates_max': 4000,
        'training_forwards_max': 16000, 'final_forwards_max': 268,
        'new_tts': 0, 'new_asr': 0, 'simultaneous_model_jobs_max': 1,
        'automatic_retries': False, 'baseline_forwards': 0,
        'real_hardware_runs': 0,
        'worker_sha256': sha(source / 'run_fsmn_seed.py'),
        'adapter_sha256': sha(source / 'seeded_fsmn.py'),
        'created_at': base['preregistered_at']}
    save(work / 'CAMPAIGN.json', campaign)
    print(json.dumps({'status': 'prepared_not_executed', 'work': str(work),
                      'campaign_sha256': sha(work / 'CAMPAIGN.json'),
                      'new_models': 0, 'new_model_forwards': 0}))


if __name__ == '__main__':
    main()
