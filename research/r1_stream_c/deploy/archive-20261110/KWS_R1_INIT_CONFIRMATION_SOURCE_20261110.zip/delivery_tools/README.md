# Portable saved-result audit

`audit_saved_confirmation.py` reads the already completed seed-confirmation
outputs at a new filesystem location. It never constructs a model, evaluates a
new forward pass, updates an optimizer, regenerates audio, or calls an ASR.
It loads the saved tensors with `weights_only=True` to verify their identities,
reconstruct greedy token sequences, and check the recorded training ledger.

## Source and changes

The original source is `audit_saved_experiment.py` from the retained
`KWS_R1_DEV_FSMN_20261107` package, SHA-256:

`db060209b56a3478d2a0fae36ee6f7a8bed42b0961e29ed5e3701d50a2183aa4`

The source originated from `jiying2007/kws-pipeline`. The original package's
`LICENSE-Apache-2.0-source.txt` and `NOTICE.md` are retained unchanged beside
this tool; the notice is named `UPSTREAM_NOTICE.md`. Individual dependency
source identities remain those recorded in each unchanged experiment plan.

This derivative adds one required CLI argument, `--input-root`. It uses that
directory for `request.json`, `vocabulary.json`, and `source/`, instead of the
historical absolute `recovered_root` string inside the plan. It authenticates
both relocated JSON files against the original plan's SHA-256 values before
reading their contents, and authenticates all 34 dependency source files.
The numerical checks, training ledger checks, original plan-to-output hash,
closed run manifest, and checkpoint checks remain the original algorithm.
The new report also records its parent source identity and relocated input
hashes. Original plans, workers, summaries, manifests and previous audits are
not rewritten.

## Required files

The delivered campaign contains `audit-inputs/` with the exact two JSON inputs
and the 34 source files listed in the plans. The 36 files total 6,147,067 bytes;
`audit-inputs/MANIFEST.json` records their sizes and hashes. Namespace package
imports work without adding or changing any `__init__.py` file.

Keep the campaign's original `plan-<seed>.json` and the complete
`seed-<seed>/run/` directory, including all numeric tensors and its original
`MANIFEST.json`. The audit does not require the historical absolute working
directories, original raw audio files, original control observations, or donor
model files. It does require the retained canonical core runtime: CPython
3.12.16, Torch 2.13.0+cpu and the dependencies fixed in
`audit-inputs/source/configs/runtime/research-runtime.json`.

The request retains machine-weak full transcripts and original path provenance.
Keep `audit-inputs/` within the same private research delivery scope. Its
presence is not permission to publish transcripts or underlying voice data.
Source license terms do not expand model or data rights.

## Run from any location

Set these paths to the extracted campaign and retained runtime. Use a new output
filename for each audit; existing reports are intentionally never overwritten.

```bash
KWS_AUDIT_PACKAGE=/path/to/r1_seed_confirmation_20261110
KWS_AUDIT_RUNTIME=/path/to/v3-core-transfer/runtime

env LD_LIBRARY_PATH="$KWS_AUDIT_RUNTIME/lib" \
  "$KWS_AUDIT_RUNTIME/bin/python3.12" -I -B \
  "$KWS_AUDIT_PACKAGE/delivery_tools/audit_saved_confirmation.py" \
  --run "$KWS_AUDIT_PACKAGE/seed-2026111001/run" \
  --plan "$KWS_AUDIT_PACKAGE/plan-2026111001.json" \
  --input-root "$KWS_AUDIT_PACKAGE/audit-inputs" \
  --output "$KWS_AUDIT_PACKAGE/delivery_tools/my-portable-audit-2026111001.json"
```

Use `2026111002` in the three seed-specific paths to audit the second run.
Do not edit the plan to change its old absolute paths: the original plan bytes
are themselves evidence and must still match the completed run.

## Verified delivery checks

`portable-audit-2026111001.json` and `portable-audit-2026111002.json` record actual
audits using `audit-inputs/`, not the historical input root. Both verify each
run's 146 files, 2,000 recorded optimizer updates, 8,000 recorded training
forwards and 134 saved final conditions. These are audits of past execution,
with zero new model constructions, forwards or optimizer updates.

The results retain the original weak-label and development-only limits. They
do not resolve the original FP32/Torch numerical gate or establish independent
human FRR, continuous natural FAR, word-end latency, or physical SSC305 results.
