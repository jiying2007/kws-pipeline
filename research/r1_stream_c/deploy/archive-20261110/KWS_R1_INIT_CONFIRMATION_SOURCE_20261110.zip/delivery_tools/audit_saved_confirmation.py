#!/usr/bin/env python3
"""Portable read-only saved-output audit; never instantiate a model.

Derived from R1 audit_saved_experiment.py, SHA-256
db060209b56a3478d2a0fae36ee6f7a8bed42b0961e29ed5e3701d50a2183aa4.
Only input location and its explicit hash validation are extended. See README.md
and the retained source license and notice beside this file.
"""
from __future__ import annotations
import argparse,collections,hashlib,json,pathlib,sys,time
from datetime import datetime,timezone

def check(ok,msg):
    if not ok: raise ValueError(msg)
def digest(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(path):return json.loads(pathlib.Path(path).read_text())
def rows(path):
    return [json.loads(line) for line in pathlib.Path(path).read_text().splitlines() if line.strip()]
def collapse(ids):
    answer=[];last=None
    for x in ids:
        if x!=last and x!=0:answer.append(x)
        last=x
    return answer
def has_sequence(ids,seq):return any(ids[i:i+len(seq)]==seq for i in range(len(ids)-len(seq)+1))
def paired_calls(items,ordinal_key,expected):
    check(len(items)==2*expected,'call ledger length')
    result=[]
    for i in range(expected):
        a,b=items[2*i:2*i+2]
        check(a['phase']=='started' and b['phase']=='completed','terminal call phases')
        check(a[ordinal_key]==b[ordinal_key]==i+(1 if ordinal_key in ('step','optimizer_step') else 0),'monotonic ordinal')
        check({k:v for k,v in a.items() if k!='phase'}=={k:v for k,v in b.items() if k!='phase'},'start/completion identity')
        result.append(b)
    return result

def run(root,plan_file,output,input_root):
    start=time.monotonic();root=pathlib.Path(root);plan=load(plan_file);input_root=pathlib.Path(input_root);source=input_root/'source'
    for name in ('request.json','vocabulary.json'):
        check(digest(input_root/name)==plan['input_hashes'][name],'relocated input changed: '+name)
    check(sys.version_info[:3]==(3,12,16),'canonical interpreter')
    for name,h in plan['source_hashes'].items():check(digest(source/name)==h,'source changed: '+name)
    sys.path[:0]=[str(source),str(source/'training'),str(source/'tools')]
    import research_weak_train as contracts
    torch,_=contracts.torch_runtime()
    from training_state import state_identity
    manifest=load(root/'MANIFEST.json');summary=load(root/'summary.json');status=load(root/'status.json')
    check(summary['status']==status['status']=='completed','not completed')
    actual={f.relative_to(root).as_posix() for f in root.rglob('*') if f.is_file() and f.name!='MANIFEST.json'}
    check(actual==set(manifest),'closed artifact roster')
    total=0
    for name,pin in manifest.items():
        path=root/name
        check(not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts,'unsafe member')
        check(not path.is_symlink() and path.stat().st_size==pin['bytes'] and digest(path)==pin['sha256'],'artifact mismatch: '+name)
        total+=pin['bytes']
    check(digest(plan_file)==summary['plan_sha256'],'plan/output linkage')
    job=load(input_root/'request.json');vocab=load(input_root/'vocabulary.json')
    roster={r['source_id']:r for r in job['evaluation_rows']};train={r['source_id']:r for r in job['train']};new={r['source_id'] for r in job['all_new_rows']}
    check(len(roster)==134 and len(train)==96,'source roster')
    fw=rows(root/'forward-calls.jsonl');fw=[r for r in fw if r.get('kind','training')=='training']
    draws=paired_calls(fw,'ordinal',8000)
    check(all(r['source_id'] in train and train[r['source_id']]['ctc_mask'] is True for r in draws),'unadmitted draw')
    check([r['source_id'] for r in draws]==[job['train'][i%96]['source_id'] for i in range(8000)],'frozen row order')
    opt=rows(root/'optimizer-calls.jsonl');key='step' if 'step' in opt[0] else 'optimizer_step'
    updates=paired_calls(opt,key,2000)
    for i,r in enumerate(updates,1):check(r.get('completed_forwards',r.get('completed_training_forwards'))==i*4,'optimizer exposure boundary')
    checkpoint=torch.load(root/'final.pt',map_location='cpu',weights_only=True)
    initial=torch.load(root/'initial.pt',map_location='cpu',weights_only=True)
    final_state=checkpoint['state_dict'];initial_state=initial['state_dict']
    check(state_identity(final_state)['sha256']==summary['float_state_sha256'],'final float state')
    check(state_identity(initial_state)['sha256']==summary['initial_float_state_sha256'],'initial float state')
    check(digest(root/'final.pt')==summary['checkpoint_sha256'],'checkpoint bytes')
    changed=[n for n in final_state if not torch.equal(final_state[n],initial_state[n])]
    check(changed,'no learned changes')
    if 'trainable_names' in summary:
        allowed=set(summary['trainable_names']);check(set(changed)<=allowed,'frozen tensor modified')
    observations=rows(root/'observations.jsonl');expected=plan['budget'].get('final_forwards',plan['budget'].get('final_forward_limit',402))
    check(len(observations)==expected,'final observation denominator')
    keys=set();numeric=0;numeric_frames=0;counts=collections.defaultdict(lambda:{'known_positive':0,'hits':0,'known_negative':0,'false_positive':0,'unknown':0})
    for obs in observations:
        sid=obs['source_id'];offset=obs.get('offset_ms',0);check(sid in roster and (sid,offset) not in keys,'observation identity');keys.add((sid,offset));r=roster[sid]
        artifact=obs['numeric_artifact'];path=root/artifact['path'];check(digest(path)==artifact['sha256'] and path.stat().st_size==artifact['bytes'],'numeric binding')
        saved=torch.load(path,map_location='cpu',weights_only=True);logits=saved['logits'];feature=saved['feature']
        check(saved['source_id']==sid and logits.dtype==torch.float32 and feature.dtype==torch.float32,'numeric identity')
        check(logits.ndim==3 and list(logits.shape[1:])==[1,2601] and logits.shape[0]==feature.shape[0],'shape')
        check(bool(torch.isfinite(logits).all()) and bool(torch.isfinite(feature).all()),'finite numerics')
        check(contracts.tensor_sha(feature)==saved['feature_sha256'] and contracts.tensor_sha(logits)==saved['logits_sha256'],'tensor digest')
        ids=collapse(logits[:,0].argmax(-1).tolist());check(ids==obs['greedy_token_ids'],'saved greedy differs')
        numeric+=1;numeric_frames+=len(logits)
        for k,text in enumerate(('你好小窝','小窝小窝')):
            target=[vocab['token_to_id'][c] for c in text];present=has_sequence(ids,target);reported=obs['keywords'][k]
            check(reported['complete_sequence_present']==present and reported['known']==r['keyword_mask'][k] and reported['reference']==r['keyword_targets'][k],'keyword projection')
            bucket=f'{r["split"]}:ms{offset}:K{k+1}';x=counts[bucket]
            if not r['keyword_mask'][k]:x['unknown']+=1
            elif r['keyword_targets'][k]==1:x['known_positive']+=1;x['hits']+=int(present)
            else:x['known_negative']+=1;x['false_positive']+=int(present)
    check({sid for sid,offset in keys}==set(roster),'missing source observations')
    result={'schema':'kws-v3-saved-training-independent-readback-v1','status':'verified','experiment_id':summary['experiment_id'],
        'plan_sha256':digest(plan_file),'manifest_sha256':digest(root/'MANIFEST.json'),'checkpoint_sha256':digest(root/'final.pt'),
        'optimizer_steps_verified':len(updates),'training_forwards_verified':len(draws),'actual_changed_tensors':len(changed),
        'final_numeric_conditions_verified':numeric,'final_numeric_frames_verified':numeric_frames,'closed_files_verified':len(manifest),'bytes_verified':total,
        'counts':dict(counts),'new_model_constructions':0,'new_model_forwards':0,'new_optimizer_steps':0,
        'human_gold':False,'independent_acoustic_test':False,'natural_far_available':False,
        'scope':'separate saved-byte/ledger/argmax decoder reconstruction; not a rerun of training or independent acoustic truth',
        'original_auditor_sha256':'db060209b56a3478d2a0fae36ee6f7a8bed42b0961e29ed5e3701d50a2183aa4','input_root_override':True,
        'relocated_input_sha256':{name:digest(input_root/name) for name in ('request.json','vocabulary.json')},
        'audit_source_sha256':digest(__file__),'wall_seconds':time.monotonic()-start,'finished_at':datetime.now(timezone.utc).isoformat()}
    with pathlib.Path(output).open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(result,sort_keys=True))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--plan',required=True);p.add_argument('--output',required=True);p.add_argument('--input-root',required=True);a=p.parse_args();run(a.run,a.plan,a.output,a.input_root)
