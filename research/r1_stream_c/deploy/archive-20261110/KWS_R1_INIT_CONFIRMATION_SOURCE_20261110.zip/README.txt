KWS R1 初始化确认源码 — 2026-11-10

本归档记录原 R1-DEV-FSMN-20261107 之外的两个预注册初始化种子。
source/ 中 run_fsmn_seed.py、seeded_fsmn.py、supervise.py 为实际执行版本。
test_seed_initializer.py 为已执行的五项零真实模型回归。
prepare_confirmation.py 是随后验证过的异地输入准备工具，默认只准备，不启动模型。
summarize_confirmation.py 从完成的保存证据生成聚合结果，不构造或执行模型。
public/ 中报告和 JSON 为聚合结果，不含权重、PCM 或逐条转写。

科学范围：只改变新增两个分类输出行（沃、灯）的随机初始化，保持 donor、
其余初始化、前端、96条训练顺序、优化器和2000步预算。只支持有限初始化确认。
原模型继续保留，不选择最佳新种子，不声称独立自然准确率或真实SSC305性能。

所需所有者输入仍为原 KWS_R1_DEV_FSMN_20261107.zip、checkpoint capsule 和规范
CPython 3.12.16 / Torch 2.13.0+cpu 环境。它们的模型、数据及许可边界保持不变。
对已完成结果的恢复应首先使用所有者证据包，只读审计不需要重新训练。

准备一个真正新目录的可复现实验（仅在确需独立重现并有明确预算时使用）：
  <canonical-python> source/prepare_confirmation.py \
    --package <unpacked-original-R1-package> --capsule <original-capsule.zip> \
    --work <fresh-work-dir> --lock <shared-heavy-slot-lock>

该命令不会构造模型或调用前向。原始训练计划和已完成输出不得覆盖。
如明确执行一次新的复现，使用准备目录中的 source/supervise.py；它串行运行两组，
每组最多1260秒、2000更新、8000训练前向、134最终前向，不自动重试。
训练需要规范环境、完整模型/音频输入和当前可用计算锁，不能将本源码归档视为
自动安排任务、恢复未知远端任务或重复消耗旧实验的授权。

原始训练worker父版本SHA256：
2078e0c06ac67bc1ea821a808d405952cc2fcd07cb5156dced71758d97313094
原始初始化器父版本SHA256：
ce1eb7c16ffe49eb184e9a8705bc35ae5c636c064ef65158f480944dfd6f3582
执行worker SHA256：
b888fb8bc6035d53fdbf9e0ed35674cd2291cd95aea4188cffa49ac7d8b2a1e1
执行初始化器SHA256：
fcdddb7e5755ad34113f028788d49b6a3db8e19640b14b1b8bf343cf4339211d

所有成员的大小和SHA256见MANIFEST.json；归档本身的SHA256在外部交付索引中。
源码来源为 jiying2007/kws-pipeline；保留原Apache-2.0源码许可证和原研究用途说明。
