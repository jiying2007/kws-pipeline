import ctypes as C
import os
from pathlib import Path
import unittest
import numpy as np
import torch
from model import Model,ctc_objective,tensor_order
from c_api import Runtime,payload_from_model,P

class GraphTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1);torch.manual_seed(193)
        cls.model=Model(np.zeros(400,np.float32),np.ones(400,np.float32)).eval()
        cls.x=torch.randn(1,79,400)
        with torch.no_grad():cls.ref=cls.model(cls.x)[0].numpy()
        cls.library=Path(os.environ['KWS_GRAPH2_LIBRARY'])
    def runtime(self):return Runtime(self.library,payload_from_model(self.model))
    def test_tensor_layout(self):
        self.assertEqual(set(self.model.state_dict()),set(dict(tensor_order())))
        self.assertEqual(sum(p.numel() for p in self.model.parameters()),48394)
        self.assertEqual(len(payload_from_model(self.model)),49194)
    def test_c_full_graph(self):
        got=self.runtime().process(self.x[0].numpy())
        np.testing.assert_allclose(got,self.ref,atol=1e-5,rtol=1e-5)
    def test_prefix_causality(self):
        with torch.no_grad():
            for end in (1,2,17,63,78):
                np.testing.assert_allclose(self.model(self.x[:,:end])[0].numpy(),self.ref[:end],atol=1e-5,rtol=1e-5)
    def test_future_perturbation(self):
        x=self.x.clone();x[:,31:]+=200
        with torch.no_grad():a=self.model(x)[0].numpy()
        np.testing.assert_array_equal(a[:31],self.ref[:31])
    def test_chunk_and_reset(self):
        rt=self.runtime();x=self.x[0].numpy();full=rt.process(x);rt.reset()
        got=np.concatenate([rt.process(x[:1]),rt.process(x[1:8]),rt.process(x[8:32]),rt.process(x[32:])])
        np.testing.assert_array_equal(full,got);rt.reset();np.testing.assert_array_equal(full,rt.process(x))
    def test_invalid_no_partial_state(self):
        rt=self.runtime();rt.process(self.x[0,:3].numpy());before=bytes(rt.state)
        for value in (np.nan,np.inf,-np.inf):
            a=np.zeros(400,np.float32);a[7]=value
            with self.assertRaises(ValueError):rt.frame(a)
            self.assertEqual(before,bytes(rt.state))
    def test_wrong_weights_rejected(self):
        p=payload_from_model(self.model)
        for q in (p[:-1],p.copy()):
            if len(q)==len(p):q[400]=0
            with self.assertRaises(ValueError):Runtime(self.library,q)
    def test_unknown_policy(self):
        with self.assertRaises(ValueError):ctc_objective(torch.zeros(2,8,2,5),torch.tensor([8,8]),torch.tensor([[1,0],[0,1]]),'bad')
    def test_default_mean_control_equivalence(self):
        torch.manual_seed(37);logits=torch.randn(2,8,2,5,requires_grad=True)
        lengths=torch.tensor([8,8]);labels=torch.tensor([[1,0],[0,1]])
        control=ctc_objective(logits,lengths,labels,'target_length')
        a=torch.nn.functional.ctc_loss(logits[:,:,0].log_softmax(-1).transpose(0,1),torch.tensor([1,2,3,4]),lengths,torch.tensor([4,0]))
        b=torch.nn.functional.ctc_loss(logits[:,:,1].log_softmax(-1).transpose(0,1),torch.tensor([3,4,3,4]),lengths,torch.tensor([0,4]))
        torch.testing.assert_close(control,(a+b)/2)
        treatment=ctc_objective(logits,lengths,labels,'input_length');treatment.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())

if __name__=='__main__':unittest.main()
