"""Whole-graph C comparison against frozen actual final Torch outputs.

No Torch model is instantiated; no new Torch forward/optimizer/TTS/ASR occurs.
The frontend is NOT run here: input is the source-bound retained feature cache.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import struct
import time
import numpy as np
from c_api import Runtime
from data import load_records, sha
from run_experiment import save_json


def verify_run(run, rows, library, output):
    meta=json.loads((run/'COMPLETE.json').read_text())
    wm=json.loads((run/'weights.json').read_text())
    if sha(run/'weights.f32le')!=wm['sha256'] or (run/'weights.f32le').stat().st_size!=wm['bytes']:
        raise ValueError('weight identity')
    weights=np.fromfile(run/'weights.f32le',dtype='<f4')
    rt=Runtime(library,weights)
    records=[];total=0;maxdiff=0.;sq=0.;badtotal=0;start=time.monotonic()
    for row in rows:
        i=row['index'];x=row['features']
        with np.load(run/'numeric'/f'{i:03d}.npz',allow_pickle=False) as z:
            reference=z['logits'];clocks=z['clocks']
        if reference.shape!=(len(x),2,5) or not np.isfinite(reference).all():raise ValueError('oracle geometry')
        if not np.array_equal(clocks,row['clocks']):raise ValueError('saved source clock identity')
        rt.reset();got=rt.process(x)
        if struct.unpack('<Q',bytes(rt.state)[:8])[0]!=len(x):raise ValueError('C frame counter')
        diff=np.abs(got.astype(np.float64)-reference.astype(np.float64))
        bad=int(np.count_nonzero(diff>1e-5+1e-5*np.abs(reference.astype(np.float64))))
        equal=bool(np.array_equal(got.argmax(-1),reference.argmax(-1)))
        maxdiff=max(maxdiff,float(diff.max(initial=0)));sq+=float((diff*diff).sum());total+=diff.size;badtotal+=bad
        # Two different partitions of the same feature stream; no reset between chunks.
        partition_hashes=[]
        for sizes in ((1,7,31,3,16),(19,2,5,11)):
            rt.reset();out=[];pos=0;part=0
            while pos<len(x):
                n=sizes[part%len(sizes)];out.append(rt.process(x[pos:pos+n]));pos+=n;part+=1
            chunk=np.concatenate(out)
            if not np.array_equal(got,chunk):raise ValueError('C partition result changed')
            partition_hashes.append(hashlib.sha256(chunk.tobytes()).hexdigest())
        r=dict(index=i,source_id=row['source_id'],frames=len(x),elements=diff.size,
               violations=bad,max_abs=float(diff.max(initial=0)),argmax_equal=equal,
               c_logits_sha256=hashlib.sha256(got.tobytes()).hexdigest(),
               reference_logits_sha256=hashlib.sha256(reference.tobytes()).hexdigest(),
               feature_partition_sha256=partition_hashes,source_clock_identity=True)
        records.append(r)
        np.savez_compressed(output/f'{i:03d}.npz',logits=got,clocks=clocks)
    result=dict(seed=meta['seed'],policy=meta['policy'],model_id=meta['model_id'],
        plan_sha256=meta['plan_sha256'],weights_sha256=wm['sha256'],library_sha256=sha(library),
        records=records,elements=total,violations=badtotal,max_abs=maxdiff,rmse=(sq/total)**.5,
        argmax_all_equal=all(r['argmax_equal'] for r in records),
        all_partitions_bitwise_equal=True,strict_numeric_pass=badtotal==0,
        c_model_streams=len(rows)*3,c_model_frames=sum(len(r['features']) for r in rows)*3,
        torch_model_forwards=0,optimizer_updates=0,elapsed_seconds=time.monotonic()-start,
        clock_scope='retained feature-producer clocks matched; no PCM frontend execution',
        physical_SSC305=False,independent_acoustics=False)
    save_json(output/'REPORT.json',result)
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--experiment',required=True,type=Path)
    p.add_argument('--cache',required=True,type=Path);p.add_argument('--labels',required=True,type=Path)
    p.add_argument('--library',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();a.output.mkdir(exist_ok=False)
    completion=json.loads((a.experiment/'COMPLETE.json').read_text())
    rows=load_records(a.cache,a.labels);results=[]
    source={p.name:sha(p) for p in Path(__file__).parent.iterdir() if p.suffix in ('.py','.c','.h')}
    save_json(a.output/'SOURCE_IDENTITY.json',source)
    for r in completion['runs']:
        name=f"{r['policy']}-seed{r['seed']}";out=a.output/name;out.mkdir()
        result=verify_run(a.experiment/name,rows,a.library,out)
        results.append({k:v for k,v in result.items() if k!='records'})
        print(json.dumps(results[-1]),flush=True)
    save_json(a.output/'SUMMARY.json',dict(runs=results,total_elements=sum(r['elements'] for r in results),
      total_violations=sum(r['violations'] for r in results),all_numeric_pass=all(r['strict_numeric_pass'] for r in results),
      all_argmax_equal=all(r['argmax_all_equal'] for r in results),torch_model_forwards=0,
      training_updates=0,frontend_pcm_execution=False,source_sha256=sha(a.output/'SOURCE_IDENTITY.json')))
    if any(r['violations'] or not r['argmax_all_equal'] for r in results):raise SystemExit(2)

if __name__=='__main__':main()
