"""One frozen, paired, bounded experiment. No resume/retry and no dev selection."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import sys
import time
import numpy as np
import torch
from model import Model, MODEL_ID, ctc_objective, tensor_order
from data import load_records, train_normalization, evaluate_saved, sha


def save_json(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def load_freeze(path):
    p = Path(path); plan = json.loads(p.read_text())
    here = Path(__file__).resolve().parent
    for name, pin in plan['source_hashes'].items():
        if sha(here/name) != pin:
            raise ValueError('executed source changed: ' + name)
    runtime = {'python': platform.python_version(), 'torch': str(torch.__version__),
               'numpy': str(np.__version__)}
    if runtime != plan['runtime'] or plan['model_id'] != MODEL_ID:
        raise ValueError('runtime/model identity mismatch')
    return plan, sha(p)


def pack(rows):
    lengths = torch.tensor([len(r['features']) for r in rows], dtype=torch.long)
    x = torch.zeros((len(rows), int(lengths.max()), 400), dtype=torch.float32)
    for i, r in enumerate(rows):
        x[i, :len(r['features'])] = torch.from_numpy(r['features'])
    return x, lengths, torch.tensor([r['refs'] for r in rows], dtype=torch.long)


def export_weights(model, dest):
    state = model.state_dict(); raw = bytearray(); tensors = []
    expected = dict(tensor_order())
    if set(state) != set(expected): raise ValueError('tensor set')
    for name, shape in tensor_order():
        t = state[name].detach().cpu().contiguous()
        if tuple(t.shape) != shape or t.dtype != torch.float32 or not torch.isfinite(t).all():
            raise ValueError('tensor contract')
        b = t.numpy().astype('<f4', copy=False).tobytes()
        tensors.append(dict(name=name, shape=list(shape), offset=len(raw), bytes=len(b),
                            sha256=hashlib.sha256(b).hexdigest()))
        raw.extend(b)
    with (dest/'weights.f32le').open('xb') as f: f.write(raw)
    check = (dest/'weights.f32le').read_bytes()
    for t in tensors:
        if hashlib.sha256(check[t['offset']:t['offset']+t['bytes']]).hexdigest() != t['sha256']:
            raise ValueError('export readback mismatch')
    save_json(dest/'weights.json', dict(model_id=MODEL_ID, tensors=tensors, bytes=len(raw),
                                       sha256=sha(dest/'weights.f32le'), dtype='float32-le'))


def fit(rows, mean, std, seed, policy, plan, plan_hash, out):
    out.mkdir(exist_ok=False)
    save_json(out/'STARTED.json', dict(seed=seed, policy=policy, plan_sha256=plan_hash,
                                     pid=os.getpid(), unix_time=time.time(), retry_allowed=False))
    start=time.monotonic()
    torch.manual_seed(seed); np.random.seed(seed); random.seed(seed)
    torch.use_deterministic_algorithms(True)
    model=Model(mean, std)
    # Preserve initialization identity to prove paired runs start identically.
    ih=hashlib.sha256()
    for t in model.state_dict().values(): ih.update(t.detach().numpy().tobytes())
    init_hash=ih.hexdigest()
    optimizer=torch.optim.AdamW(model.parameters(), lr=plan['training']['lr'],
                               weight_decay=plan['training']['weight_decay'], foreach=False)
    train=[r for r in rows if r['split']=='train']
    schedule=torch.Generator().manual_seed(seed + 17)
    exposures=Counter(); steps=0; forward_rows=0; epoch_losses=[]
    ledger=(out/'optimizer.jsonl').open('x')
    model.train()
    try:
        for epoch in range(plan['training']['epochs']):
            order=torch.randperm(len(train), generator=schedule).tolist(); total=0.
            for k in range(0,len(order),8):
                if time.monotonic()-start>plan['training']['per_run_hard_seconds']:
                    raise TimeoutError('frozen run deadline; do not retry')
                batch=[train[i] for i in order[k:k+8]]
                x,lengths,labels=pack(batch)
                optimizer.zero_grad(set_to_none=True)
                y=model(x); forward_rows+=len(batch)
                loss=ctc_objective(y,lengths,labels,policy)
                if not torch.isfinite(loss): raise ValueError('nonfinite loss')
                loss.backward()
                norm=torch.nn.utils.clip_grad_norm_(model.parameters(),plan['training']['gradient_clip'],
                                                    error_if_nonfinite=True)
                optimizer.step();steps+=1
                ids=[r['source_id'] for r in batch]; exposures.update(ids)
                ledger.write(json.dumps(dict(step=steps,epoch=epoch,source_ids=ids,
                              loss=float(loss),gradient_norm=float(norm)))+'\n');ledger.flush()
                total+=float(loss)
            epoch_losses.append(total/12)
            print(json.dumps(dict(seed=seed,policy=policy,epoch=epoch+1,steps=steps,
                                  loss=epoch_losses[-1],seconds=time.monotonic()-start)),flush=True)
        if steps!=720 or set(exposures)!=set(r['source_id'] for r in train) or set(exposures.values())!={60}:
            raise ValueError('optimizer exposure mismatch')
        torch.save(dict(model_id=MODEL_ID,seed=seed,policy=policy,plan_sha256=plan_hash,
                        state_dict=model.state_dict(),steps=steps),out/'checkpoint.pt')
        export_weights(model,out)
        model.eval();logits={};prefix_cases=[];numeric=out/'numeric';numeric.mkdir()
        with torch.no_grad():
            for r in rows:
                x=torch.from_numpy(r['features'])[None]
                a=model(x)[0].numpy();forward_rows+=1
                if not np.isfinite(a).all():raise ValueError('nonfinite final output')
                logits[r['index']]=a
                np.savez_compressed(numeric/f"{r['index']:03d}.npz",logits=a,clocks=r['clocks'])
                if r['split']=='development':
                    for end in sorted({1,len(a)//2,len(a)-1}):
                        p=model(x[:,:end])[0].numpy();forward_rows+=1
                        diff=np.abs(p-a[:end]);bad=np.count_nonzero(diff>1e-5+1e-5*np.abs(a[:end]))
                        prefix_cases.append(dict(index=r['index'],end=end,violations=int(bad),
                                                 max_abs=float(diff.max(initial=0))))
                        if bad:raise ValueError('noncausal/prefix numeric mismatch')
        result=dict(model_id=MODEL_ID,seed=seed,policy=policy,plan_sha256=plan_hash,
                    initialization_sha256=init_hash,checkpoint_sha256=sha(out/'checkpoint.pt'),
                    parameter_count=sum(p.numel() for p in model.parameters()),
                    training_steps=steps,training_forward_rows=5760,
                    total_forward_rows=forward_rows,epoch_losses=epoch_losses,
                    train=evaluate_saved(rows,logits,'train'),
                    development=evaluate_saved(rows,logits,'development'),
                    prefix_checks=prefix_cases,elapsed_seconds=time.monotonic()-start,
                    unknown_optimizer_exposure=0,unknown_scored_rows=0,model_selected=False,
                    independent_acoustics=False,physical_SSC305=False)
        save_json(out/'COMPLETE.json',result)
        return result
    except BaseException as e:
        save_json(out/'FAILED.json',dict(exception=type(e).__name__,message=str(e),steps=steps,
                                       forward_rows=forward_rows,elapsed_seconds=time.monotonic()-start))
        raise
    finally:
        ledger.close()


def main():
    p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True)
    p.add_argument('--cache',type=Path,required=True);p.add_argument('--labels',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    plan,pin=load_freeze(a.plan)
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    rows=load_records(a.cache,a.labels);mean,std=train_normalization(rows)
    a.output.mkdir(exist_ok=False)
    save_json(a.output/'STARTED.json',dict(plan_sha256=pin,unix_time=time.time(),model_id=MODEL_ID))
    np.savez(a.output/'normalization.npz',mean=mean,std=std)
    results=[];start=time.monotonic()
    for seed in plan['training']['seeds']:
        for policy in plan['policies']:
            if time.monotonic()-start>plan['training']['campaign_hard_seconds']:
                raise TimeoutError('campaign admission deadline')
            result=fit(rows,mean,std,seed,policy,plan,pin,a.output/f'{policy}-seed{seed}')
            results.append({k:result[k] for k in ('seed','policy','initialization_sha256','training_steps',
                            'parameter_count','checkpoint_sha256','elapsed_seconds')})
    save_json(a.output/'COMPLETE.json',dict(model_id=MODEL_ID,plan_sha256=pin,runs=results,
        total_optimizer_updates=sum(r['training_steps'] for r in results),
        elapsed_seconds=time.monotonic()-start,model_selected=False,no_dev_checkpoint_selection=True))

if __name__=='__main__':main()
