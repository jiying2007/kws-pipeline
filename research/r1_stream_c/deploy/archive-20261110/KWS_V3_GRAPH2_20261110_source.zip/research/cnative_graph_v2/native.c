/* SPDX-License-Identifier: Apache-2.0 */
#include "native.h"
#include <float.h>
#include <math.h>
#include <string.h>
#define MAGIC UINT32_C(0x43474732)
_Static_assert(sizeof(float)==4 && FLT_RADIX==2 && FLT_MANT_DIG==24,"IEEE binary32 required");
static const unsigned ds[5]={1,2,4,8,16};
static const unsigned offsets[5]={0,3,8,17,34};
static int finite_array(const float *p,size_t n) {
    if(!p) return 0;
    for(size_t i=0;i<n;i++) if(!isfinite(p[i])) return 0;
    return 1;
}
static int store(double v,float *y) {
    if(!isfinite(v)||fabs(v)>FLT_MAX) return 2;
    *y=(float)v; return 0;
}
static int affine(const float *x,unsigned ni,const float *w,const float *bias,
                  unsigned no,float *out) {
    for(unsigned o=0;o<no;o++) {
        double z=bias?(double)bias[o]:0.0;
        for(unsigned i=0;i<ni;i++) z+=(double)x[i]*(double)w[o*ni+i];
        if(store(z,&out[o])) return 2;
    }
    return 0;
}
static int norm(const float *x,const float *g,const float *b,float *y) {
    double mean=0.0,var=0.0;
    for(unsigned c=0;c<64;c++) mean+=(double)x[c];
    mean/=64.0;
    for(unsigned c=0;c<64;c++) {double v=(double)x[c]-mean;var+=v*v;}
    var/=64.0;
    double inv=1.0/sqrt(var+(double)(float)1e-5f);
    for(unsigned c=0;c<64;c++) {
        double v=(((double)x[c]-mean)*inv)*(double)g[c]+(double)b[c];
        if(store(v,&y[c])) return 2;
    }
    return 0;
}
size_t cg_state_bytes(void) { return sizeof(cg_state); }
int cg_validate_weights(const float *w,size_t n) {
    if(n!=CG_FLOATS||!finite_array(w,n)) return 1;
    for(unsigned i=400;i<800;i++) if(!(w[i]>0.0f)) return 1;
    return 0;
}
int cg_init(cg_state *s) {
    if(!s) return 1;
    memset(s,0,sizeof(*s));s->magic=MAGIC;return 0;
}
int cg_frame(cg_state *s,const float *w,const float *x,float *out) {
    float input[400],a[64],b[64],c[64],layer_input[5][64],y[10];
    if(!s||!w||!out||s->magic!=MAGIC||s->reserved||s->frames==UINT64_MAX||
       !finite_array(x,400)) return 1;
    for(unsigned i=0;i<400;i++) {
        if(!isfinite(w[i])||!isfinite(w[400+i])||!(w[400+i]>0.0f)) return 1;
        input[i]=(x[i]-w[i])/w[400+i];
        if(!isfinite(input[i])) return 2;
    }
    if(affine(input,400,w+800,w+26400,64,a)) return 2;
    for(unsigned i=0;i<64;i++) a[i]=fmaxf(a[i],0.0f);
    for(unsigned block=0;block<5;block++) {
        unsigned d=ds[block],ring=2*d+1,base=offsets[block];
        const float *p=w+26464+block*4416;
        memcpy(layer_input[block],a,sizeof(a));
        for(unsigned ch=0;ch<64;ch++) {
            double v0=0.0,v1=0.0;
            if(s->frames>=2*d) v0=(double)s->history[base+(s->frames-2*d)%ring][ch]*(double)p[ch*3];
            if(s->frames>=d) v1=(double)s->history[base+(s->frames-d)%ring][ch]*(double)p[ch*3+1];
            if(store((v0+v1)+(double)a[ch]*(double)p[ch*3+2],&b[ch])) return 2;
        }
        if(norm(b,p+192+4096,p+192+4096+64,c)) return 2;
        for(unsigned ch=0;ch<64;ch++) c[ch]=fmaxf(c[ch],0.0f);
        if(affine(c,64,p+192,NULL,64,b)) return 2;
        for(unsigned ch=0;ch<64;ch++) {
            float v=a[ch]+b[ch]; if(!isfinite(v)) return 2;
            a[ch]=fmaxf(v,0.0f);
        }
    }
    if(affine(a,64,w+48544,w+49184,10,y)) return 2;
    /* Commit only after all five blocks and both heads complete successfully. */
    for(unsigned block=0;block<5;block++) {
        unsigned ring=2*ds[block]+1;
        memcpy(s->history[offsets[block]+s->frames%ring],layer_input[block],64*sizeof(float));
    }
    s->frames++;memcpy(out,y,sizeof(y));return 0;
}
