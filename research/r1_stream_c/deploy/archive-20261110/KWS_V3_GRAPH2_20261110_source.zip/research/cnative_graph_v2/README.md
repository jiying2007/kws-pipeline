# C-native graph 2: complete reproducible graph; quality screen rejected

## Actual status (2026-11-10 UTC)

Six NEW fits completed: two frozen CTC reduction policies x three seeds,
720 optimizer updates each / 4,320 total. This is not a reconstruction or rerun
of the earlier missing-source DS-TCN implementation. No old weights were used.
All new training sources, plans, source/label/feature identities, optimizer
exposure ledgers, checkpoints and final logits are retained.

The complete Python graph and C11 streaming graph match bit-for-bit on all
134 input records for all six checkpoints, in both GCC and Clang builds:
1,504,080 compared logit elements, 0 violations. The frozen rule remains
abs(actual-reference) <= 1e-5 + 1e-5*abs(reference). This match applies only to
this explicitly declared binary32-storage / binary64-reduction graph. It does
NOT overturn the original R1-versus-Torch/MKL numerical FAIL.

**Both objective policies failed the prospective development quality screen.**
No candidate is selected for deployment; do not optimize these rejected weights
for INT8 or replace the current runtime with them.

| Objective | K1 complete hits over 10 positives, by seed | K2 complete hits |
|---|---|---|
| NLL / max(target length,1) | 2, 0, 0 | 0, 0, 2 |
| NLL / input frames | 0, 0, 0 | 1, 0, 1 |

Both have 0 complete-keyword false-positive rows over 24 weak negatives per
keyword per seed. This is poor-recall behavior, not low-FAR qualification.
The control fits all 27 K1 and 28 K2 training positives in all three seeds;
therefore training fit alone is not the missing acceptance condition.

Read-only revalidation of the older pretrained R1, with its original complete
2601-token outputs, gives 10/10 and 10/10 development hits and 0/24 false positives
per keyword. All 260 known keyword/source bindings and eight unknown bindings
were reconciled, and 55 model-package payloads were checked. This is still the
same 34 exposed weak synthetic rows, NOT an independent benchmark. It is a
system comparison, not a controlled architecture-only ablation. The stronger
pretrained R1 is the continuation priority; its old C/MKL numerical failure and
missing physical measurements remain separate.

## Graph and data

`model.py` closes the entire executable graph. See `PREREGISTRATION.txt` and
`PLAN.json`: width64, five causal kernel3 depthwise blocks, dilation1/2/4/8/16,
channel-only LayerNorm, ReLU/residual ordering, two 5-class CTC heads, 63-frame
receptive field. The inherited frontend has fixed 20ms lookahead. No PCM frontend
or calibrated wake event decoder is added by this module.

Use only the original exact C feature cache (134 rows / 12,534 frames) and saved
binary weak references: 96 train, 34 development, four unknown. Unknown rows are
excluded from optimization and scored evaluation, but remain in numerical replay.
The full-transcript labels are NOT reconstructed from model predictions.

Paired initial weights and every source-id batch schedule are identical between
policies. No extra epochs, checkpoint choice or threshold sweep followed the
results. The six final checkpoints are research-negative results and remain saved.

## Native host replay (no training)

Restore the original pinned CPython3.12.16/Torch2.13.0+cpu/NumPy2.3.2 archive using
the file ID and SHA256 in the execution handoff. Do not silently substitute the
system Torch. `CACHE` is an extracted cache directory with the original archive
at `${CACHE}.zip`; `LABELS` contains the exact original `data-manifest.json`.
`RUNS` is the delivered `experiment-graph2-v1` directory. All output directories
below must be new; never overwrite earlier receipts.

```sh
export KWS_PINNED_RUNTIME=/absolute/path/to/v3-core-transfer/runtime
cc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -ffp-contract=off \
  -fno-fast-math -fPIC -shared native.c -o /new/path/libgraph2.so -lm
KWS_GRAPH2_LIBRARY=/new/path/libgraph2.so \
  sh ../cnative_landing_v1/run_pinned_python.sh -m unittest -v test_graph
sh ../cnative_landing_v1/run_pinned_python.sh verify_saved.py \
  --experiment "$RUNS" --cache "$CACHE" --labels "$LABELS" \
  --library /new/path/libgraph2.so --output /new/path/verification

# Standalone C feature-file inference; inputs are NOT PCM WAVs.
cc -std=c11 -O2 -ffp-contract=off -fno-fast-math \
  native.c feature_cli.c -o /new/path/graph2_cli -lm
/new/path/graph2_cli "$RUNS/target_length-seed2026111001/weights.f32le" \
  "$CACHE/c_features/000.bin" /new/path/output.f32le
```

Training was performed by `run_experiment.py` under the frozen `PLAN.json`.
It is not run by default in replay. A deliberate independent reproduction is a
separate recorded execution, not a way to recover already retained checkpoints.
No failed or unknown external call is retried by these tools.

## Scope and integration

C network state is 17,168 bytes; parameter-plus-normalization payload is 196,776
bytes. These are reference layout sizes, not process RSS, full frontend memory,
stack bounds, measured CPU use or SSC305 evidence. C has no allocation, lock,
thread, file access or global mutable data in `cg_frame`; the separate host CLI
uses files. Float64 reductions are explicit and not advertised as an optimized
ARM implementation. Caller validates immutable weights once before inference.

Nine distinct fixture tests passed in six complete compiler/optimization runs
(54 test invocations); the earlier interrupted fixture test log is retained.
Eighteen actual trained-weight/feature cases passed ASan+UBSan and were
byte-identical to the normal C build. Whole-model chunk tests use feature frames,
not arbitrary PCM bytes or final-AFE callbacks. No human acoustic, continuous FAR,
INT8, ARM runtime or physical SSC305 result is claimed.

The source-only patch adds this module and its predecessor `cnative_landing_v1`.
It has NOT been submitted, reviewed, merged or run through full repository CI.
Remote GitHub exposed no write actions in this session; no CLI credentials were
present, and container public GitHub clone failed at DNS resolution. Do not use
an administrative bypass or change historic retention pins to merge it.
Required official CI wiring and source-retention registration remain open.
Authorship/review in this session is assistant-generated, not independent human
review. No model weights, private feature matrices or per-row labels belong in
the public source-only patch. No Scheduled task, paid API or Codex/Work job was
created. Existing completed TTS/ASR assets and checkpoints remain unchanged.
