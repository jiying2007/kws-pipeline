/* SPDX-License-Identifier: Apache-2.0
 * Host CLI for pinned R1FEAT1 feature records. NOT a PCM frontend or wake event API.
 */
#include "native.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static float weights[CG_FLOATS];
static cg_state state;
int main(int argc,char **argv) {
    const unsigned short endian=1;
    if(argc!=4||*(const unsigned char *)&endian!=1) return 2;
    FILE *wf=fopen(argv[1],"rb");if(!wf)return 3;
    size_t got=fread(weights,sizeof(float),CG_FLOATS,wf);
    int extra=fgetc(wf),bad=ferror(wf);fclose(wf);
    if(got!=CG_FLOATS||extra!=EOF||bad||cg_validate_weights(weights,CG_FLOATS))return 4;
    FILE *in=fopen(argv[2],"rb");if(!in)return 5;
    char header[8];
    if(fread(header,1,8,in)!=8||memcmp(header,"R1FEAT1\0",8)){fclose(in);return 6;}
    FILE *out=fopen(argv[3],"wbx");if(!out){fclose(in);return 7;}
    uint64_t n=0,last_delivery=0;int rc=0;cg_init(&state);
    for(;;) {
        uint64_t clocks[3];float input[400],output[10];
        size_t first=fread(clocks,1,sizeof(clocks),in);
        if(first==0&&feof(in))break;
        if(first!=sizeof(clocks)||n>=10000||fread(input,sizeof(float),400,in)!=400){rc=8;break;}
        if(clocks[0]!=n||clocks[1]!=720+480*n||clocks[2]<clocks[1]||clocks[2]<last_delivery){rc=9;break;}
        if(cg_frame(&state,weights,input,output)){rc=10;break;}
        if(fwrite(output,sizeof(float),10,out)!=10){rc=11;break;}
        last_delivery=clocks[2];n++;
    }
    if(ferror(in)||ferror(out)||!n)rc=12;
    fclose(in);if(fclose(out))rc=13;
    if(!rc)fprintf(stderr,"{\"feature_frames\":%llu,\"state_bytes\":%zu,\"weights_bytes\":%zu,\"pcm_frontend_executed\":false}\n",
        (unsigned long long)n,sizeof(state),sizeof(weights));
    return rc;
}
