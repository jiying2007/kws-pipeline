"""Read-only primary-metric audit of R1's retained 2601-token outputs."""
import argparse
import hashlib
import json
from pathlib import Path

TARGETS = ([1027,1401,1462,2093],[1462,2093,1462,2093])
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def audit(research, package, labels):
    card=json.loads((package/'MODEL.json').read_text());verified=0
    for name,r in card['files'].items():
        p=package/name
        if p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('model package pin '+name)
        verified+=1
    p=research/'experiments/fsmn-selected-dev/run/observations.jsonl'
    rows=[json.loads(line) for line in p.read_text().splitlines()]
    roles={r['source_id']:r for r in json.loads((labels/'data-manifest.json').read_text())['source_roles']}
    if len(rows)!=134 or len({r['source_id'] for r in rows})!=134 or set(roles)!={r['source_id'] for r in rows}:
        raise ValueError('closed roster')
    counts={s:[dict(tp=0,fn=0,fp=0,tn=0),dict(tp=0,fn=0,fp=0,tn=0)] for s in ('train','development')}
    unknown=0;bindings=0
    for r in rows:
        role=roles[r['source_id']]
        if r['pcm_sha256']!=role['pcm_sha256'] or r['label_binding_sha256']!=role['label_binding_sha256']:
            raise ValueError('original source/label mismatch')
        if r['source_family_id']!=role['family']:raise ValueError('family mismatch')
        if r['split']!=role['split'] and not (r['split']=='train' and role['split']=='unknown'):
            raise ValueError('split mismatch')
        ids=r['greedy_token_ids']
        if any(type(x) is not int or not 1<=x<2601 for x in ids):raise ValueError('invalid collapsed ids')
        for h,target in enumerate(TARGETS):
            k=r['keywords'][h]
            if k['token_ids']!=target or k['keyword_id']!=h+1:raise ValueError('keyword identity')
            if role['split']=='unknown':
                if k['known'] or k['reference'] is not None:raise ValueError('unknown relabel')
                unknown+=1;continue
            if k['known'] is not True or k['reference']!=role['keyword_refs'][h]:raise ValueError('weak reference mismatch')
            hit=any(ids[i:i+len(target)]==target for i in range(len(ids)-len(target)+1))
            if hit != k['complete_sequence_present']:raise ValueError('saved full-keyword flag mismatch')
            truth=bool(k['reference']);c=counts[role['split']][h]
            c['tp' if truth and hit else 'fn' if truth else 'fp' if hit else 'tn']+=1;bindings+=1
    return dict(schema='r1-saved-complete-keyword-readback-v1',checkpoint_sha256=card['checkpoint_sha256'],
        observations_sha256=sha(p),model_payload_files_verified=verified,rows=134,known_keyword_bindings=bindings,
        unknown_keyword_bindings=unknown,counts=counts,new_model_forwards=0,new_optimizer_updates=0,
        criterion='contiguous entire 4-token target in original collapsed 2601-token sequence',
        scope='same exposed weak synthetic development, not independent test; not a same-frontend architecture ablation',
        original_r1_c_torch_gate='FAIL_UNCHANGED',physical_SSC305=False)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--research',type=Path,required=True)
    p.add_argument('--package',type=Path,required=True);p.add_argument('--labels',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    r=audit(a.research,a.package,a.labels)
    with a.output.open('x') as f:json.dump(r,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps(r,indent=2))
