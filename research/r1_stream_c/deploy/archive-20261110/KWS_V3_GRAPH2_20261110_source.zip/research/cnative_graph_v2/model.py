"""New, explicit causal graph; NOT a reconstruction of the 2026-11-09 graph.

Binary32 parameters/storage, binary64 reduction reference. The casts are part
of the graph. There is no time-axis normalization, dropout or hidden clamp.
"""
from __future__ import annotations
import math
import torch
from torch import nn
from torch.nn import functional as F

MODEL_ID = 'CNATIVE-GRAPH2-RF63-CTC-20261110'
WIDTH = 64
DILATIONS = (1, 2, 4, 8, 16)
EPS = float(torch.tensor(1e-5, dtype=torch.float32))
TARGETS = ((1, 2, 3, 4), (3, 4, 3, 4))


def affine(x, w, b=None):
    return F.linear(x.double(), w.double(), None if b is None else b.double()).float()


class Block(nn.Module):
    def __init__(self, dilation):
        super().__init__()
        self.dilation = dilation
        self.dw = nn.Parameter(torch.empty(WIDTH, 3))
        self.pw = nn.Parameter(torch.empty(WIDTH, WIDTH))
        self.gamma = nn.Parameter(torch.ones(WIDTH))
        self.beta = nn.Parameter(torch.zeros(WIDTH))
        nn.init.uniform_(self.dw, -1 / math.sqrt(3), 1 / math.sqrt(3))
        nn.init.kaiming_uniform_(self.pw, a=math.sqrt(5))

    def forward(self, x):
        # x is [batch,time,channels]. Left padding is exact zero only.
        d = self.dilation
        p = F.pad(x, (0, 0, 2 * d, 0)).double()
        n = x.shape[1]
        w = self.dw.double()
        z = ((p[:, :n] * w[:, 0] + p[:, d:d+n] * w[:, 1])
             + p[:, 2*d:2*d+n] * w[:, 2]).float()
        v = z.double()
        mu = v.mean(-1, keepdim=True)
        var = ((v - mu) ** 2).mean(-1, keepdim=True)
        z = (((v-mu) * torch.rsqrt(var + EPS)) * self.gamma.double()
             + self.beta.double()).float()
        z = torch.relu(z)
        z = affine(z, self.pw)
        return torch.relu(x + z)


class Model(nn.Module):
    def __init__(self, mean, std):
        super().__init__()
        self.register_buffer('mean', torch.as_tensor(mean, dtype=torch.float32).clone())
        self.register_buffer('std', torch.as_tensor(std, dtype=torch.float32).clone())
        self.proj_w = nn.Parameter(torch.empty(WIDTH, 400))
        self.proj_b = nn.Parameter(torch.zeros(WIDTH))
        nn.init.kaiming_uniform_(self.proj_w, a=math.sqrt(5))
        self.blocks = nn.ModuleList(Block(d) for d in DILATIONS)
        self.head_w = nn.Parameter(torch.empty(10, WIDTH))
        self.head_b = nn.Parameter(torch.zeros(10))
        nn.init.kaiming_uniform_(self.head_w, a=math.sqrt(5))

    def forward(self, x):
        if x.ndim != 3 or x.shape[-1] != 400 or x.dtype != torch.float32:
            raise ValueError('expected binary32 [batch,time,400]')
        z = torch.relu(affine((x - self.mean) / self.std, self.proj_w, self.proj_b))
        for block in self.blocks:
            z = block(z)
        return affine(z, self.head_w, self.head_b).reshape(*z.shape[:-1], 2, 5)


def tensor_order():
    out = [('mean', (400,)), ('std', (400,)),
           ('proj_w', (WIDTH, 400)), ('proj_b', (WIDTH,))]
    for i in range(len(DILATIONS)):
        out += [(f'blocks.{i}.dw', (WIDTH, 3)), (f'blocks.{i}.pw', (WIDTH, WIDTH)),
                (f'blocks.{i}.gamma', (WIDTH,)), (f'blocks.{i}.beta', (WIDTH,))]
    return out + [('head_w', (10, WIDTH)), ('head_b', (10,))]


def ctc_objective(logits, lengths, labels, policy):
    """Only the reduction denominator differs between the paired policies."""
    if policy not in ('target_length', 'input_length'):
        raise ValueError('unknown objective policy')
    losses = []
    for h, target in enumerate(TARGETS):
        target_lengths = labels[:, h].long() * len(target)
        targets = torch.tensor([v for present in labels[:, h].tolist() if present
                                for v in target], dtype=torch.long)
        lp = logits[:, :, h].log_softmax(-1).transpose(0, 1).contiguous()
        nll = F.ctc_loss(lp, targets, lengths, target_lengths, blank=0,
                         reduction='none', zero_infinity=False)
        denominator = (target_lengths.clamp_min(1) if policy == 'target_length'
                       else lengths).to(nll.dtype)
        losses.append((nll / denominator).mean())
    return torch.stack(losses).mean()
