"""ctypes binding for the new fixed graph, with weight setup validation."""
from __future__ import annotations
import ctypes as C
import numpy as np
from model import tensor_order

P=C.POINTER(C.c_float)
class Runtime:
    def __init__(self, library, payload):
        self.lib=C.CDLL(str(library))
        self.lib.cg_state_bytes.restype=C.c_size_t
        self.lib.cg_validate_weights.argtypes=[P,C.c_size_t]
        self.lib.cg_init.argtypes=[C.c_void_p]
        self.lib.cg_frame.argtypes=[C.c_void_p,P,P,P]
        self.weights=np.asarray(payload,dtype=np.float32).reshape(-1).copy()
        if self.lib.cg_validate_weights(self.weights.ctypes.data_as(P),len(self.weights)):
            raise ValueError('invalid weights')
        self.state=C.create_string_buffer(self.lib.cg_state_bytes())
        self.reset()
    def reset(self):
        if self.lib.cg_init(self.state):raise ValueError('state initialization')
    def frame(self, x):
        a=np.ascontiguousarray(x,dtype=np.float32)
        if a.shape!=(400,):raise ValueError('expected feature frame')
        y=np.full(10,np.nan,dtype=np.float32)
        rc=self.lib.cg_frame(self.state,self.weights.ctypes.data_as(P),a.ctypes.data_as(P),y.ctypes.data_as(P))
        if rc:raise ValueError(f'C frame error {rc}')
        return y.reshape(2,5)
    def process(self,x):
        x=np.asarray(x)
        if x.ndim!=2 or x.shape[1]!=400:raise ValueError('feature matrix shape')
        return np.stack([self.frame(row) for row in x]) if len(x) else np.empty((0,2,5),dtype=np.float32)


def payload_from_model(model):
    state=model.state_dict()
    return np.concatenate([state[n].detach().numpy().reshape(-1) for n,_ in tensor_order()])
