"""Read only the existing exact C cache and its saved weak keyword references."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'cnative_landing_v1'))
from export_verified import feature_records, CACHE_HASH, DATA_HASH
from metrics import collapse_ctc, score_rows


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def load_records(cache_dir, labels_dir):
    rows = []
    for record, role, features, clocks in feature_records(cache_dir, labels_dir):
        known = role['split'] != 'unknown'
        refs = role['keyword_refs']
        if known and (type(refs) is not list or len(refs) != 2 or
                      any(type(x) is not int or x not in (0, 1) for x in refs)):
            raise ValueError('explicit binary weak-reference pair required')
        if not known and refs is not None:
            raise ValueError('unknown must remain unknown')
        rows.append(dict(index=record['index'], source_id=record['source_id'],
                         split=role['split'], family=role['family'], refs=refs,
                         features=features, clocks=clocks, pcm_sha256=role['pcm_sha256'],
                         label_binding_sha256=role['label_binding_sha256']))
    if {k: sum(r['split'] == k for r in rows) for k in ('train', 'development', 'unknown')} != {
            'train': 96, 'development': 34, 'unknown': 4}:
        raise ValueError('closed split counts')
    if sum(len(r['features']) for r in rows) != 12534:
        raise ValueError('closed frame count')
    train = {r['family'] for r in rows if r['split'] == 'train'}
    dev = {r['family'] for r in rows if r['split'] == 'development'}
    if train & dev:
        raise ValueError('train/development family leakage')
    return rows


def train_normalization(rows):
    a = np.concatenate([r['features'] for r in rows if r['split'] == 'train'])
    mean = a.mean(axis=0, dtype=np.float64).astype(np.float32)
    var = np.mean((a.astype(np.float64) - mean.astype(np.float64)) ** 2, axis=0)
    std = np.maximum(np.sqrt(var), 1e-4).astype(np.float32)
    if not np.isfinite(mean).all() or not np.isfinite(std).all():
        raise ValueError('normalization is not finite')
    return mean, std


def evaluate_saved(rows, logits, split):
    scored = [r for r in rows if r['split'] == split]
    if split not in ('train', 'development'):
        raise ValueError('unknown rows cannot be scored')
    out = []
    for h, kw in enumerate(('K1', 'K2')):
        values = []
        for r in scored:
            a = logits[r['index']]
            values.append(dict(source_id=r['source_id'], known=True,
                               gold_present=bool(r['refs'][h]),
                               greedy_local_ids=list(collapse_ctc(a[:, h].argmax(-1).tolist()))))
        out.append(dict(**score_rows(values, kw), predictions=values))
    return out
