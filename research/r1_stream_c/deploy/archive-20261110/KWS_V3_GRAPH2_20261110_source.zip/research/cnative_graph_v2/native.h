/* SPDX-License-Identifier: Apache-2.0 */
#ifndef CNATIVE_GRAPH2_H
#define CNATIVE_GRAPH2_H
#include <stddef.h>
#include <stdint.h>
#define CG_FLOATS 49194u
#define CG_CHANNELS 64u
#define CG_BLOCKS 5u
#define CG_HISTORY 67u
/* Validated weights are immutable, non-overlapping arrays. No allocation or I/O.
 * This is an explicit binary64-reduction reference, not an optimized ARM kernel.
 */
typedef struct {
    uint64_t frames;
    uint32_t magic;
    uint32_t reserved;
    float history[CG_HISTORY][CG_CHANNELS];
} cg_state;
size_t cg_state_bytes(void);
int cg_validate_weights(const float *weights, size_t count);
int cg_init(cg_state *state);
/* An error leaves both state and output unchanged. No EOF padding or flush. */
int cg_frame(cg_state *state, const float *weights, const float *input400,
             float *output10);
#endif
