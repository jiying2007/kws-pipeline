# C-native KWS: metric correction, tensor export and C layer verification

**Status: local implementation and bounded verification complete for the scope
below. No new model is selected or deployed. Whole-network C parity is NOT_RUN.**

## Critical correction

The archived 2026-11-09 reports named a nonempty-output classifier `exact_recall`.
All nine archived experiments / 18 keyword-head summaries reproduce that defect:
`predicted_present == bool(greedy_local_ids)`, including incomplete phrases.
The 34 development records and their original weak labels were not changed.

For the corrected causal LayerNorm candidate, seeds 20261109/10/11:

| Definition | K1 | K2 |
|---|---|---|
| Complete target is a contiguous subsequence | 0/10, 1/10, 0/10 | 0/10, 0/10, 1/10 |
| Collapsed whole sequence equals target exactly | 0/10, 0/10, 0/10 | 0/10, 0/10, 1/10 |
| Complete-target false-positive rows | 0/24, 0/24, 0/24 | 0/24, 0/24, 0/24 |

These are the same 34 exposed weak synthetic rows reused across seeds, not 102
independent recordings. No continuous event FAR or independent human accuracy is
implied. Zero false positives with poor recall is not a useful model selection.
GroupNorm candidates remain noncausal and cannot be selected for streaming.

`metrics.py` distinguishes whole-sequence equality, complete-keyword containment
and a nonempty diagnostic. It also enforces correct CTC repetition/blank order,
unknown masks, exact head identity, complete sequences and separate denominators.
`audit_all_saved.py` cross-checks all 612 saved row/head/seed weak references
against their archived data manifests and recomputes all nine experiments without
model calls. Prior source/result bytes are never overwritten.

## What is implemented

* `export_verified.py`: exact-hash, weights-only checkpoint recovery; closed
  tensor names/shapes/dtypes; normalization and source/feature/clock checks;
  per-tensor lossless little-endian float32 export. Three payloads, 277,416 bytes
  each: 68,554 learned parameters plus 800 normalization scalars. **This is a
  tensor export, not a runnable whole-model export.**
* `cnative_ops.c/.h`: bounded C11 normalization, affine, channel-only LayerNorm,
  causal depthwise temporal convolution, state reset and rejection without
  state/output modification. No heap, I/O, locks or global mutable state.
  Affine, LayerNorm and convolution use explicit binary64 accumulation with
  binary32 storage; these are numerical-reference operators, not an optimized
  or measured ARM implementation. Array aliasing is unsupported.
* `validate_real_projection.py`: compare actual retained 134-record features and
  all three checkpoints' normalization/input-affine layer against pinned Torch.
  The fixed element rule is `abs(C-ref) <= 1e-5 + 1e-5*abs(ref)`.
* Local tests cover metrics, exports, operator math, invalid input, overflow,
  reset, arbitrary **feature-frame** partitions and prefix consistency.
  They do not prove arbitrary PCM-byte partitioning of a whole detector.

## Original execution-source gap (do not guess)

The causal archive contains checkpoints, normalization, a high-level plan and
saved results, but no executed Python forward source or full logit reference.
Activation functions/order, exact residual placement, LayerNorm epsilon and any
input clamping are not closed by the retained state dictionary. This package
therefore deliberately does not manufacture an original network graph or call
operator agreement an original-model equivalence result. Tensor manifests state
`graph_verified=false`, `whole_model_inference_allowed=false`, and
`deployment_allowed=false`. Restore the original source or establish a separately
identified new implementation/experiment before whole-network execution.

## Reproduction

Use the retained CPython 3.12.16 / Torch 2.13.0+cpu / NumPy 2.3.2 runtime. Do not
install unpinned packages to claim the original environment. The delivered
handoff gives Library file IDs and archive hashes; the runtime and feature cache
are intentionally not republished in this source-only folder.

```sh
# ARCHIVES contains the two original C-NATIVE-*.zip archives.
python3 audit_all_saved.py --archive-dir "$ARCHIVES" --output audit-new.json

# MODEL is the extracted cnative-kws-causal-ln-v1 folder.
# CACHE is the extracted KWS_R1_C_FEATURE_CACHE_20261108 folder, with its
# exact original KWS_R1_C_FEATURE_CACHE_20261108.zip alongside the folder.
export KWS_PINNED_RUNTIME=/path/to/v3-core-transfer/runtime
./run_pinned_python.sh export_verified.py \
  --model-dir "$MODEL" --cache-dir "$CACHE" --output new-export-directory

make smoke
mkdir -p libraries
cc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -ffp-contract=off \
  -fno-fast-math -fPIC -shared cnative_ops.c -o libraries/libcnative_gcc.so -lm
clang -std=c11 -O2 -Wall -Wextra -Werror -pedantic -ffp-contract=off \
  -fno-fast-math -fPIC -shared cnative_ops.c -o libraries/libcnative_clang.so -lm
export KWS_CHECKPOINT_DIR="$MODEL"
export KWS_FEATURE_CACHE="$CACHE"
export KWS_EXPORT_DIR=/path/to/new-export-directory
./run_pinned_python.sh run_checks.py --libraries "$PWD/libraries" \
  --output new-test-evidence-directory
./run_pinned_python.sh validate_real_projection.py \
  --model-dir "$MODEL" --cache-dir "$CACHE" \
  --library libraries/libcnative_gcc.so --output new-projection-report.json
```

Output directories/receipts use exclusive creation. Use a new named verification
receipt instead of overwriting an existing experiment. None of the commands
trains, invokes ASR/TTS, modifies remote repositories or starts a scheduled task.

## Repository integration boundary

The source-only patch adds `research/cnative_landing_v1/`; it does not change the
default runtime, weights registry, old experiment files or workflow permissions.
Observed main is `7b157c227101999d7a21462a1c17bc7f5248723e`.
No remote write/PR/merge operation is available in the current session's GitHub
actions. Full repository CI, retained-source registration and protected PR review
have NOT been run for this addition. Before merging, wire the local tests into
the existing official CI and register genuinely new source identities through
its normal process; never alter historical pins merely to make a check pass.
No new hourly/Scheduled task is needed.

Independent FAR/FRR, event calibration, INT8, ARM inference and physical SSC305
measurements are NOT_RUN. Those missing measurements are not replaced by passing
operator tests. The existing old ASR artifact was observed still listed; no
artifact deletion was performed by this package.
