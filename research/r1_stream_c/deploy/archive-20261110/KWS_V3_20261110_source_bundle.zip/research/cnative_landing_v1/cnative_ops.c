/* SPDX-License-Identifier: Apache-2.0 */
#include "cnative_ops.h"
#include <float.h>
#include <math.h>
#include <string.h>

_Static_assert(sizeof(float)==4 && FLT_RADIX==2 && FLT_MANT_DIG==24, "requires IEEE binary32");
static int finite_array(const float *p,size_t n) {
    if(!p) return 0;
    for(size_t i=0;i<n;i++) if(!isfinite(p[i])) return 0;
    return 1;
}
size_t ck_dw_state_bytes(void) { return sizeof(ck_dw_state); }
int ck_normalize400(const float *x,const float *mean,const float *std,float *y) {
    float out[CK_INPUTS];
    if(!y || !finite_array(x,CK_INPUTS) || !finite_array(mean,CK_INPUTS) || !finite_array(std,CK_INPUTS)) return CK_INVALID;
    for(size_t i=0;i<CK_INPUTS;i++) {
        if(!(std[i]>0.0f)) return CK_INVALID;
        out[i]=(x[i]-mean[i])/std[i];
        if(!isfinite(out[i])) return CK_NONFINITE;
    }
    memcpy(y,out,sizeof(out)); return CK_OK;
}
int ck_affine(const float *x,size_t ni,const float *w,const float *b,size_t no,float *y) {
    float out[CK_CHANNELS];
    if(!ni || ni>CK_INPUTS || !no || no>CK_CHANNELS || !y ||
       !finite_array(x,ni) || !finite_array(w,ni*no) || (b && !finite_array(b,no))) return CK_INVALID;
    /* Explicit binary64 accumulation; a portable numerical reference, not an
       asserted fast ARM kernel. Inputs, parameters and outputs are binary32. */
    for(size_t o=0;o<no;o++) {
        double v=b?(double)b[o]:0.0;
        for(size_t i=0;i<ni;i++) v+=(double)x[i]*(double)w[o*ni+i];
        if(!isfinite(v) || fabs(v)>FLT_MAX) return CK_NONFINITE;
        out[o]=(float)v;
    }
    memcpy(y,out,no*sizeof(float)); return CK_OK;
}
int ck_layernorm96(const float *x,const float *g,const float *b,float eps,float *y) {
    float out[CK_CHANNELS]; double mean=0.0,var=0.0;
    if(!y || !isfinite(eps) || !(eps>0.0f) || !finite_array(x,CK_CHANNELS) ||
       !finite_array(g,CK_CHANNELS) || !finite_array(b,CK_CHANNELS)) return CK_INVALID;
    for(size_t i=0;i<CK_CHANNELS;i++) mean+=(double)x[i];
    mean/=CK_CHANNELS;
    for(size_t i=0;i<CK_CHANNELS;i++) { double d=(double)x[i]-mean;var+=d*d; }
    var/=CK_CHANNELS; /* biased variance, channels only; no time reduction */
    double inv=1.0/sqrt(var+(double)eps);
    for(size_t i=0;i<CK_CHANNELS;i++) {
        double v=(((double)x[i]-mean)*inv)*(double)g[i]+(double)b[i];
        if(!isfinite(v) || fabs(v)>FLT_MAX) return CK_NONFINITE;
        out[i]=(float)v;
    }
    memcpy(y,out,sizeof(out));return CK_OK;
}
int ck_dw_init(ck_dw_state *s,unsigned d) {
    if(!s || (d!=1u && d!=2u && d!=4u)) return CK_INVALID;
    memset(s,0,sizeof(*s));s->dilation=d;return CK_OK;
}
int ck_dw_frame(ck_dw_state *s,const float *x,const float *k,float *y) {
    float out[CK_CHANNELS];
    if(!s || !y || (s->dilation!=1u && s->dilation!=2u && s->dilation!=4u) ||
       s->position>=CK_HISTORY || s->frames==UINT64_MAX ||
       !finite_array(x,CK_CHANNELS) || !finite_array(k,3u*CK_CHANNELS)) return CK_INVALID;
    const unsigned d=s->dilation;
    for(size_t c=0;c<CK_CHANNELS;c++) {
        double v=(double)x[c]*(double)k[3u*c+2u];
        if(s->frames>=d) v+=(double)s->history[(s->position+CK_HISTORY-d)%CK_HISTORY][c]*(double)k[3u*c+1u];
        if(s->frames>=2u*d) v+=(double)s->history[(s->position+CK_HISTORY-2u*d)%CK_HISTORY][c]*(double)k[3u*c];
        if(!isfinite(v) || fabs(v)>FLT_MAX) return CK_NONFINITE;
        out[c]=(float)v;
    }
    /* Commit only after every channel is valid; invalid input leaves state and
       output unchanged. There is no end-of-stream padding or flushing. */
    memcpy(s->history[s->position],x,CK_CHANNELS*sizeof(float));
    s->position=(s->position+1u)%CK_HISTORY;s->frames++;
    memcpy(y,out,sizeof(out));return CK_OK;
}
