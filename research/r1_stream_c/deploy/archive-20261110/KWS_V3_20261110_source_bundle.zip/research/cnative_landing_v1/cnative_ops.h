/* SPDX-License-Identifier: Apache-2.0
 * Layer operators only. Does not assert a missing original network graph.
 * No heap, files, locks, threads, or global mutable state in the data plane.
 * Arrays must not overlap; immutable parameter validation belongs to setup.
 */
#ifndef CNATIVE_OPS_H
#define CNATIVE_OPS_H
#include <stddef.h>
#include <stdint.h>
#define CK_CHANNELS 96u
#define CK_INPUTS 400u
#define CK_HISTORY 9u
enum { CK_OK=0, CK_INVALID=1, CK_NONFINITE=2 };
typedef struct {
    uint64_t frames;
    unsigned position;
    unsigned dilation;
    float history[CK_HISTORY][CK_CHANNELS];
} ck_dw_state;
size_t ck_dw_state_bytes(void);
int ck_normalize400(const float *x,const float *mean,const float *std,float *y);
int ck_affine(const float *x,size_t ni,const float *weight,const float *bias,size_t no,float *y);
int ck_layernorm96(const float *x,const float *gamma,const float *beta,float epsilon,float *y);
int ck_dw_init(ck_dw_state *s,unsigned dilation);
int ck_dw_frame(ck_dw_state *s,const float *x,const float *kernel,float *y);
#endif
