"""Lossless tensor export, not a verified whole-network graph export."""
import argparse
import hashlib
import json
import struct
import zipfile
from pathlib import Path

import numpy as np
import torch

MODEL_ID = 'C-NATIVE-KWS-CAUSAL-LN-CTC-20261109'
PINS = {20261109: '84f37d6108245dd651bd2b73a80caca83a07cec4fa347ffbe380211dafd48dcd',
        20261110: '76106c1add5d656e6d9c654192f397842a3aa1b0a0b4d806b09dc58b80627d50',
        20261111: '68cd4d925f7104e33d3051f89ecb276c7026fe7ec7db51d5abf8ce1776b2da88'}
PLAN_HASH = '9a2e0557c4e92a5904077e85a2a3cdee8a2172da5f93f48c79ccc424be9af7e0'
DATA_HASH = '26115bc93574ba02b803362eee3d3f69b27c4eb11e7a5451d830bc6ce7652c80'
CACHE_HASH = '5a3abf4bc262f5dc2d0c5e2d1e805fc96adbb20ded8d334e75ec90c5962486c0'


def require(ok, why):
    if not ok: raise ValueError(why)


def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()


def shapes():
    items = [('proj.weight',(96,400,1)),('proj.bias',(96,))]
    for b in range(3):
        items += [(f'blocks.{b}.dw.weight',(96,1,3)),
                  (f'blocks.{b}.pw.weight',(96,96,1)),
                  (f'blocks.{b}.norm.weight',(96,)),(f'blocks.{b}.norm.bias',(96,))]
    for h in range(2):
        items += [(f'heads.{h}.weight',(5,96,1)),(f'heads.{h}.bias',(5,))]
    return items


def load_verified(directory, seed):
    d = Path(directory)
    require(seed in PINS, 'unsupported checkpoint seed')
    require(sha(d/'plan.json') == PLAN_HASH, 'plan hash mismatch')
    require(sha(d/'data-manifest.json') == DATA_HASH, 'data hash mismatch')
    p = d/f'causal-ds-tcn-layernorm-ctc-seed{seed}.pt'
    require(sha(p) == PINS[seed], 'checkpoint hash mismatch')
    unsafe = torch.serialization.get_unsafe_globals_in_checkpoint(p)
    require(set(unsafe) <= {'torch.torch_version.TorchVersion'}, 'unexpected pickle globals')
    with torch.serialization.safe_globals([torch.torch_version.TorchVersion]):
        ck = torch.load(p, map_location='cpu', weights_only=True)
    require(ck['model_id'] == MODEL_ID and ck['seed'] == seed, 'checkpoint identity mismatch')
    require(ck['architecture'] == 'causal-ds-tcn-layernorm-ctc', 'noncausal/unknown architecture')
    require(ck['plan_sha256']==PLAN_HASH and ck['data_manifest_sha256']==DATA_HASH and
            ck['feature_cache_sha256']==CACHE_HASH, 'checkpoint provenance mismatch')
    require(ck['task_map']==json.loads((d/'plan.json').read_text())['tasks'], 'task map mismatch')
    expected = dict(shapes())
    require(set(ck['state_dict']) == set(expected), 'tensor key mismatch')
    for name, shape in shapes():
        t = ck['state_dict'][name]
        require(isinstance(t,torch.Tensor) and t.dtype==torch.float32 and tuple(t.shape)==shape,
                'shape/dtype mismatch: '+name)
        require(bool(torch.isfinite(t).all()), 'nonfinite tensor: '+name)
    with np.load(d/'normalization.npz', allow_pickle=False) as n:
        for name, key in [('normalization_mean','mean'),('normalization_std','std')]:
            a=ck[name].detach().cpu().numpy()
            require(a.dtype==np.float32 and a.shape==(400,) and np.isfinite(a).all(), 'invalid normalization')
            require(a.tobytes()==n[key].tobytes(), 'normalization bytes differ')
        require(bool((n['std']>0).all()), 'normalization std must be positive')
    return ck


def feature_records(cache_dir, model_dir):
    root = Path(cache_dir)
    archive = root.with_suffix('.zip')
    require(sha(archive)==CACHE_HASH, 'original cache archive hash mismatch')
    with zipfile.ZipFile(archive) as z:
        require(z.read('C_FEATURE_CACHE.json')==(root/'C_FEATURE_CACHE.json').read_bytes(),
                'cache manifest differs from pinned archive')
    require(sha(Path(model_dir)/'data-manifest.json')==DATA_HASH, 'data manifest hash mismatch')
    cache = json.loads((root/'C_FEATURE_CACHE.json').read_text())
    data = json.loads((Path(model_dir)/'data-manifest.json').read_text())
    roles={r['source_id']:r for r in data['source_roles']}
    require({k:sum(r['split']==k for r in roles.values()) for k in ('train','development','unknown')}
            == {'train':96,'development':34,'unknown':4}, 'source/loss role counts')
    require(len(roles)==134, '134 unique source roles required')
    records=cache['records']; require(len(records)==134,'134 cache records required')
    dtype=np.dtype([('clock','<u8',(3,)),('features','<f4',(400,))])
    require({r['source_id'] for r in records}==set(roles), 'closed source-id coverage')
    require(len({r['source_id'] for r in records})==len(records), 'duplicate source id')
    seen=set()
    for r in records:
        i=r['index']; require(type(i) is int and 0<=i<134 and i not in seen,'invalid cache index')
        seen.add(i)
        p=root/'c_features'/f'{i:03d}.bin'
        require(p.stat().st_size==r['bytes'] and sha(p)==r['sha256'], 'cache payload identity')
        role=roles[r['source_id']]
        # Cache split is source role; unknown is the later loss-mask role.
        split_match = (role['split'] == r['split'] or
                       (r['split'] == 'train' and role['split'] == 'unknown' and
                        role['keyword_refs'] is None))
        require(role['pcm_sha256']==r['pcm_sha256'] and split_match and
                role['feature_sha256']==r['sha256'], 'source/feature binding')
        raw=p.read_bytes();require(raw[:8]==b'R1FEAT1\0','feature header')
        require((len(raw)-8)%dtype.itemsize==0,'feature record alignment')
        a=np.frombuffer(raw,offset=8,dtype=dtype)
        require(len(a)==r['frames'] and np.isfinite(a['features']).all(),'feature geometry/finite')
        ids=np.arange(len(a),dtype=np.uint64)
        require(np.array_equal(a['clock'][:,0],ids),'noncontiguous feature clock')
        require(np.array_equal(a['clock'][:,1],720+480*ids),'source clock geometry')
        require(np.all(a['clock'][:,2]>=a['clock'][:,1]),'delivery precedes source availability')
        require(np.all(np.diff(a['clock'][:,2].astype(np.int64))>=0),'nonmonotonic delivery')
        yield r,role,np.ascontiguousarray(a['features']),np.ascontiguousarray(a['clock'])


def export(directory, cache_dir, out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    records=list(feature_records(cache_dir,directory))
    require(sum(len(x[2]) for x in records)==12534,'frame count mismatch')
    data=json.loads((Path(directory)/'data-manifest.json').read_text())
    train={r['family'] for r in data['source_roles'] if r['split']=='train'}
    dev={r['family'] for r in data['source_roles'] if r['split']=='development'}
    require(not train & dev,'family split overlap')
    manifests=[]
    for seed in PINS:
        ck=load_verified(directory,seed)
        tensor_order=shapes()+[('normalization_mean',(400,)),('normalization_std',(400,))]
        payload=bytearray();entries=[]
        for name,shape in tensor_order:
            t=ck[name] if name.startswith('normalization_') else ck['state_dict'][name]
            a=t.detach().cpu().contiguous().numpy().astype('<f4',copy=False)
            raw=a.tobytes(order='C')
            entries.append({'name':name,'shape':list(shape),'dtype':'float32-le','offset':len(payload),
                            'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
            payload.extend(raw)
        require(len(payload)==277416,'fixed tensor byte count')
        fn=f'seed{seed}.f32le';(out/fn).write_bytes(payload)
        # Independently re-read each emitted byte range and compare to its tensor.
        reread=(out/fn).read_bytes()
        for e in entries:
            raw=reread[e['offset']:e['offset']+e['bytes']]
            require(hashlib.sha256(raw).hexdigest()==e['sha256'],'export roundtrip')
        m={'schema':'cnative-verified-tensor-export-v1','seed':seed,'model_id':MODEL_ID,
           'checkpoint_sha256':PINS[seed],'plan_sha256':PLAN_HASH,'data_manifest_sha256':DATA_HASH,
           'feature_cache_sha256':CACHE_HASH,'payload':fn,'bytes':len(payload),'sha256':sha(out/fn),
           'tensors':entries,'parameter_count':68554,'normalization_scalars':800,
           'graph_verified':False,'whole_model_inference_allowed':False,'deployment_allowed':False,
           'blockers':['original executed forward source missing',
                       'activation order / LN epsilon / input clamp not bound by archive',
                       'original exact_recall metric was nonempty detection, not complete keyword'],
           'new_training_updates':0,'new_model_forwards':0}
        (out/f'seed{seed}.json').write_text(json.dumps(m,indent=2)+'\n')
        manifests.append(m)
    report={'schema':'cnative-export-receipt-v1','record_count':len(records),'frames':12534,
            'tensor_exports':len(manifests),'tensor_payloads_roundtrip_verified':60,
            'train_dev_families_disjoint':True,'normalization_checkpoint_npz_bytes_equal':True,
            'full_model_graph_verified':False,'training_updates':0,'model_forwards':0,
            'optimizer_exposure_of_unknown_rows':0,'original_model_files_modified':False,
            'exported_payloads':[{k:m[k] for k in ('seed','payload','bytes','sha256')} for m in manifests]}
    (out/'EXPORT_RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-dir',required=True,type=Path)
    p.add_argument('--cache-dir',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();print(json.dumps(export(a.model_dir,a.cache_dir,a.output),indent=2))


if __name__=='__main__':main()
