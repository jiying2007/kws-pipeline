"""Recompute all nine saved experiments without loading models or modifying inputs."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path
from metrics import score_rows, require

ARCHIVES={
 'C-NATIVE-KWS-SCREEN-20261109.zip':'7e9211336fb9796d4306b154ceefa77f8605cc3bed64dbd24d6a4d77524c80a3',
 'C-NATIVE-KWS-CAUSAL-LN-20261109.zip':'e7a187423f87ff46e093585e548bdb62b989bb42273129f68c9f15c5c5be2501'}


def audit(directory):
    results=[]
    for name,pin in ARCHIVES.items():
        path=Path(directory)/name
        require(hashlib.sha256(path.read_bytes()).hexdigest()==pin,'archive hash mismatch')
        with zipfile.ZipFile(path) as z:
            manifests=[n for n in z.namelist() if n.endswith('/data-manifest.json')]
            require(len(manifests)==1,'unique data manifest required')
            data=json.loads(z.read(manifests[0]))
            dev={r['source_id']:r for r in data['source_roles'] if r['split']=='development'}
            require(len(dev)==34,'development row count')
            for n in sorted(z.namelist()):
                if '/result-' not in n or not n.endswith('.json'):continue
                raw=z.read(n);old=json.loads(raw);heads=[]
                require([h['keyword'] for h in old['dev']]==['K1','K2'],'head identity/order')
                for hi,h in enumerate(old['dev']):
                    require(len(h['rows'])==34 and {r['source_id'] for r in h['rows']}==set(dev),'closed development coverage')
                    for r in h['rows']:
                        source=dev[r['source_id']]
                        require(source['keyword_refs'][hi] in (0,1),'known weak reference required')
                        require(type(r['gold_present']) is bool and r['gold_present']==bool(source['keyword_refs'][hi]), 'weak reference disagreement')
                        require(r['family']==source['family'],'source-family disagreement')
                        require(type(r['predicted_present']) is bool,'legacy decision type')
                    x=score_rows(h['rows'],h['keyword'])
                    x['legacy_exact_recall']=h['exact_recall']
                    x['legacy_row_fpr']=h['false_positive_rate']
                    x['legacy_counts_match_nonempty']=all(h[k]==x['nonempty_diagnostic_only'][k] for k in ('tp','fn','fp','tn'))
                    x['legacy_recall_matches_nonempty']=h['exact_recall']==x['nonempty_diagnostic_only']['recall']
                    x['legacy_decisions_match_nonempty']=all(r['predicted_present']==bool(r['greedy_local_ids']) for r in h['rows'])
                    heads.append(x)
                results.append({'archive':name,'archive_sha256':pin,'result_member':n,
                                'result_sha256':hashlib.sha256(raw).hexdigest(),
                                'architecture':old['architecture'],'seed':old['seed'], 'heads':heads,
                                'noncausal_excluded':old['architecture']=='causal-ds-tcn-ctc'})
    require(len(results)==9,'closed nine-result coverage')
    return {'schema':'kws-nine-experiment-metric-correction-v1','original_files_modified':False,
            'weak_reference_manifest_crosschecks':9*34*2,'model_forwards':0,'training_updates':0,
            'asr_calls':0,'tts_calls':0,'model_promoted':False,
            'scope':'saved weak-label exposed development only; no calibrated wake events or FAR',
            'results':results}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--archive-dir',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    with a.output.open('x') as f:json.dump(audit(a.archive_dir),f,indent=2,allow_nan=False);f.write('\n')


if __name__=='__main__':main()
