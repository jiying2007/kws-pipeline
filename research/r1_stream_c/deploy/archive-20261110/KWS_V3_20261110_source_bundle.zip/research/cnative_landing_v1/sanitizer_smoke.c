#include "cnative_ops.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#define CHECK(x) do { if(!(x)){fprintf(stderr,"failed line %d\n",__LINE__);return 1;} } while(0)
int main(void) {
    float x[400],m[400],std[400],y[400],w[96*400],bias[96],k[96*3];
    for(unsigned i=0;i<400;i++){x[i]=(float)(i%7)/7.0f;m[i]=0.5f;std[i]=2.0f;y[i]=99.0f;}
    for(unsigned i=0;i<96*400;i++)w[i]=0.001f;
    for(unsigned i=0;i<96;i++)bias[i]=0.1f;
    for(unsigned i=0;i<96*3;i++)k[i]=0.1f;
    CHECK(ck_normalize400(x,m,std,y)==0);
    CHECK(ck_affine(x,400,w,bias,96,y)==0);
    CHECK(ck_layernorm96(x,bias,bias,1e-5f,y)==0);
    for(unsigned d=1;d<=4;d*=2) {
        ck_dw_state s,old;CHECK(ck_dw_init(&s,d)==0);
        for(unsigned f=0;f<100;f++)CHECK(ck_dw_frame(&s,x,k,y)==0);
        CHECK(s.frames==100);old=s;x[3]=NAN;
        float before[400];memcpy(before,y,sizeof(y));
        CHECK(ck_dw_frame(&s,x,k,y)!=0);CHECK(memcmp(&old,&s,sizeof(s))==0);
        CHECK(memcmp(before,y,sizeof(y))==0);x[3]=0.0f;
    }
    CHECK(ck_dw_init(NULL,1)!=0);CHECK(ck_affine(NULL,400,w,bias,96,y)!=0);
    CHECK(ck_affine(x,401,w,bias,96,y)!=0);CHECK(ck_layernorm96(x,bias,bias,0,y)!=0);
    std[3]=0;CHECK(ck_normalize400(x,m,std,y)!=0);
    puts("C layer smoke PASS; whole-model graph NOT_RUN");return 0;
}
