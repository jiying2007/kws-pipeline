import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
import numpy as np
from export_verified import PINS, load_verified, feature_records, shapes


class ExportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=Path(os.environ['KWS_CHECKPOINT_DIR'])
        cls.out=Path(os.environ['KWS_EXPORT_DIR'])
        cls.cache=Path(os.environ['KWS_FEATURE_CACHE'])
        cls.loaded={s:load_verified(cls.root,s) for s in PINS}
    def test_three_expected_seeds(self):self.assertEqual(set(self.loaded),set(PINS))
    def test_parameter_counts(self):
        for ck in self.loaded.values():self.assertEqual(sum(t.numel() for t in ck['state_dict'].values()),68554)
    def test_normalization_common(self):
        a=self.loaded[20261109]
        for ck in self.loaded.values():
            for k in ('normalization_mean','normalization_std'):
                self.assertEqual(ck[k].numpy().tobytes(),a[k].numpy().tobytes())
    def test_export_payload_roundtrip(self):
        for seed,ck in self.loaded.items():
            m=json.loads((self.out/f'seed{seed}.json').read_text());raw=(self.out/m['payload']).read_bytes()
            self.assertEqual(hashlib.sha256(raw).hexdigest(),m['sha256']);self.assertEqual(len(raw),277416)
            offset=0
            for x in m['tensors']:
                self.assertEqual(x['offset'],offset);offset+=x['bytes']
                t=ck[x['name']] if x['name'].startswith('normalization_') else ck['state_dict'][x['name']]
                self.assertEqual(raw[x['offset']:offset],t.numpy().astype('<f4').tobytes())
            self.assertEqual(offset,len(raw))
    def test_missing_graph_does_not_allow_deployment(self):
        for seed in PINS:
            m=json.loads((self.out/f'seed{seed}.json').read_text())
            self.assertFalse(m['graph_verified']);self.assertFalse(m['whole_model_inference_allowed']);self.assertFalse(m['deployment_allowed'])
    def test_134_cache_records_and_clocks(self):
        r=list(feature_records(self.cache,self.root));self.assertEqual(len(r),134)
        self.assertEqual(sum(len(x[2]) for x in r),12534)
        self.assertEqual(sum(x[1]['split']=='unknown' for x in r),4)
    def test_unknown_mask_is_not_negative(self):
        d=json.loads((self.root/'data-manifest.json').read_text())
        unknown=[r for r in d['source_roles'] if r['split']=='unknown']
        self.assertEqual(len(unknown),4);self.assertTrue(all(r['keyword_refs'] is None for r in unknown))
        self.assertEqual(d['unknown_optimizer_exposure'],0) # retained declaration, not a new training run
    def test_unsupported_seed_rejected(self):
        with self.assertRaises(ValueError):load_verified(self.root,1)
    def test_changed_plan_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'plan.json').write_text('{}')
            with self.assertRaises(ValueError):load_verified(p,20261109)
    def test_changed_checkpoint_rejected_before_pickle(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for name in ('plan.json','data-manifest.json'):shutil.copyfile(self.root/name,p/name)
            (p/'causal-ds-tcn-layernorm-ctc-seed20261109.pt').write_bytes(b'not a checkpoint')
            with self.assertRaises(ValueError):load_verified(p,20261109)


if __name__=='__main__':unittest.main()
