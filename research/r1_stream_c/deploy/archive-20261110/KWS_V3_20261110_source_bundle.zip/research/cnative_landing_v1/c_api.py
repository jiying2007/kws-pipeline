"""Test/host ctypes adapter; not part of the embedded C data plane."""
import ctypes as C
from pathlib import Path
import numpy as np

P=C.POINTER(C.c_float)


class DWState(C.Structure):
    _fields_=[('frames',C.c_uint64),('position',C.c_uint),('dilation',C.c_uint),
              ('history',(C.c_float*96)*9)]


def ptr(a):
    if a is None:return None
    if a.dtype != np.float32 or not a.flags.c_contiguous:raise ValueError('float32 contiguous array required')
    return a.ctypes.data_as(P)


class Ops:
    def __init__(self,path):
        self.lib=C.CDLL(str(Path(path).resolve()))
        self.lib.ck_dw_state_bytes.restype=C.c_size_t
        self.lib.ck_normalize400.argtypes=[P,P,P,P]
        self.lib.ck_affine.argtypes=[P,C.c_size_t,P,P,C.c_size_t,P]
        self.lib.ck_layernorm96.argtypes=[P,P,P,C.c_float,P]
        self.lib.ck_dw_init.argtypes=[C.POINTER(DWState),C.c_uint]
        self.lib.ck_dw_frame.argtypes=[C.POINTER(DWState),P,P,P]
        if self.lib.ck_dw_state_bytes()!=C.sizeof(DWState):raise ValueError('C ABI size mismatch')

    def affine(self,x,w,b=None):
        x=np.ascontiguousarray(x,dtype=np.float32);w=np.ascontiguousarray(w,dtype=np.float32)
        if w.ndim!=2 or w.shape[1]!=len(x):raise ValueError('affine geometry')
        b=None if b is None else np.ascontiguousarray(b,dtype=np.float32)
        y=np.empty(w.shape[0],np.float32)
        rc=self.lib.ck_affine(ptr(x),len(x),ptr(w),ptr(b),len(y),ptr(y))
        if rc:raise ValueError('ck_affine rejected input: '+str(rc))
        return y

    def normalize(self,x,m,s):
        if any(a.shape!=(400,) for a in (x,m,s)):raise ValueError('normalization geometry')
        y=np.empty(400,np.float32)
        rc=self.lib.ck_normalize400(ptr(x),ptr(m),ptr(s),ptr(y))
        if rc:raise ValueError('ck_normalize400 rejected input: '+str(rc))
        return y

    def layernorm(self,x,g,b,eps):
        if any(a.shape!=(96,) for a in (x,g,b)):raise ValueError('layernorm geometry')
        y=np.empty(96,np.float32)
        rc=self.lib.ck_layernorm96(ptr(x),ptr(g),ptr(b),eps,ptr(y))
        if rc:raise ValueError('ck_layernorm96 rejected input: '+str(rc))
        return y

    def dw_init(self,d):
        s=DWState()
        if self.lib.ck_dw_init(C.byref(s),d):raise ValueError('unsupported dilation')
        return s

    def dw_frame(self,s,x,k):
        if x.shape!=(96,) or k.size!=288:raise ValueError('depthwise geometry')
        y=np.empty(96,np.float32)
        rc=self.lib.ck_dw_frame(C.byref(s),ptr(x),ptr(k),ptr(y))
        if rc:raise ValueError('ck_dw_frame rejected input: '+str(rc))
        return y
