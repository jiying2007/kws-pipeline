"""Known affine operator test on retained features; NOT full-model inference."""
import argparse
import hashlib
import json
import platform
import time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from c_api import Ops
from export_verified import PINS, load_verified, feature_records


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-dir',type=Path,required=True)
    p.add_argument('--cache-dir',type=Path,required=True)
    p.add_argument('--library',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1)
    ops=Ops(a.library);start=time.monotonic()
    records=list(feature_records(a.cache_dir,a.model_dir));out=[]
    for seed in PINS:
        ck=load_verified(a.model_dir,seed)
        m=ck['normalization_mean'].numpy();sd=ck['normalization_std'].numpy()
        w=ck['state_dict']['proj.weight'].squeeze(-1).numpy();b=ck['state_dict']['proj.bias'].numpy()
        bad=elements=norm_bad=0;max_abs=0.0;sum_sq=0.0;rows=[]
        for record,role,x,clocks in records:
            xn=np.stack([ops.normalize(v,m,sd) for v in x])
            reference_x=((torch.from_numpy(x)-torch.from_numpy(m))/torch.from_numpy(sd)).numpy()
            norm_bad+=int(np.count_nonzero(xn!=reference_x))
            actual=np.stack([ops.affine(v,w,b) for v in xn])
            with torch.inference_mode():
                ref=F.linear(torch.from_numpy(reference_x),torch.from_numpy(w),torch.from_numpy(b)).numpy()
            delta=np.abs(actual.astype('float64')-ref.astype('float64'))
            nbad=int(np.count_nonzero(delta>1e-5+1e-5*np.abs(ref.astype('float64'))))
            bad+=nbad;elements+=delta.size;max_abs=max(max_abs,float(delta.max()));sum_sq+=float(np.square(delta).sum())
            rows.append({'index':record['index'],'source_role':record['split'],'loss_role':role['split'],
                         'frames':len(x),'feature_file_sha256':record['sha256'],
                         'projection_sha256':hashlib.sha256(actual.astype('<f4').tobytes()).hexdigest(),
                         'reference_sha256':hashlib.sha256(ref.astype('<f4').tobytes()).hexdigest(),
                         'clock_sha256':hashlib.sha256(clocks.astype('<u8').tobytes()).hexdigest(),
                         'bad_elements':nbad,'max_abs':float(delta.max())})
        out.append({'seed':seed,'records':len(rows),'frames':sum(x['frames'] for x in rows),
                    'elements':elements,'bad_elements':bad,'max_abs':max_abs,
                    'rmse':(sum_sq/elements)**0.5,'normalization_nonidentical_elements':norm_bad,
                    'strict_operator_gate':'PASS' if bad==0 and norm_bad==0 else 'FAIL','rows':rows})
    summary={'schema':'cnative-actual-projection-test-v1','results':out,
             'scope':'normalization and input affine operator only; no activation/block/head/complete network forward',
             'numeric_rule':{'atol':1e-5,'rtol':1e-5,'posthoc_tolerance_change':False},
             'actual_runtime':{'python':platform.python_version(),'torch':str(torch.__version__),'numpy':np.__version__},
             'library_sha256':hashlib.sha256(a.library.read_bytes()).hexdigest(),
             'elapsed_seconds':time.monotonic()-start,'whole_model_forwards':0,
             'training_updates':0,'asr_calls':0,'tts_calls':0,'model_promoted':False}
    with a.output.open('x') as f:json.dump(summary,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({**{k:v for k,v in summary.items() if k!='results'},
          'results':[{k:v for k,v in r.items() if k!='rows'} for r in out]},indent=2))


if __name__=='__main__':main()
