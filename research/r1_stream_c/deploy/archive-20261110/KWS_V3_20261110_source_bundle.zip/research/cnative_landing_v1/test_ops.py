import ctypes as C
import os
from pathlib import Path
import unittest
import numpy as np
import torch
import torch.nn.functional as F
from c_api import Ops, DWState, ptr

torch.set_num_threads(1)


class OperatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ops=Ops(os.environ['KWS_OPS_LIBRARY'])
        cls.rng=np.random.default_rng(20261110)
    def rand(self,*s):return self.rng.normal(size=s).astype(np.float32)
    def close(self,a,b):
        self.assertTrue(np.all(np.abs(a.astype('float64')-b.astype('float64')) <= 1e-5+1e-5*np.abs(b.astype('float64'))))
    def test_abi(self):self.assertEqual(C.sizeof(DWState),self.ops.lib.ck_dw_state_bytes())
    def test_normalization(self):
        x,m=self.rand(400),self.rand(400);s=np.abs(self.rand(400))+np.float32(0.1)
        self.assertTrue(np.array_equal(self.ops.normalize(x,m,s),(x-m)/s))
    def test_normalization_zero_std(self):
        with self.assertRaises(ValueError): self.ops.normalize(self.rand(400),self.rand(400),np.zeros(400,np.float32))
    def test_normalization_nan(self):
        x=self.rand(400);x[17]=np.nan
        with self.assertRaises(ValueError): self.ops.normalize(x,self.rand(400),np.ones(400,np.float32))
    def test_affine_projection(self):
        x,w,b=self.rand(400),self.rand(96,400)*0.03,self.rand(96)
        self.close(self.ops.affine(x,w,b),F.linear(torch.from_numpy(x),torch.from_numpy(w),torch.from_numpy(b)).numpy())
    def test_affine_pointwise(self):
        x,w=self.rand(96),self.rand(96,96)*0.1
        self.close(self.ops.affine(x,w),F.linear(torch.from_numpy(x),torch.from_numpy(w)).numpy())
    def test_affine_head(self):
        x,w,b=self.rand(96),self.rand(5,96)*0.1,self.rand(5)
        self.close(self.ops.affine(x,w,b),F.linear(torch.from_numpy(x),torch.from_numpy(w),torch.from_numpy(b)).numpy())
    def test_affine_shape_limit(self):
        x,w=self.rand(401),self.rand(96,401)
        with self.assertRaises(ValueError):self.ops.affine(x,w)
    def test_affine_overflow_output_unchanged(self):
        x=np.full(96,3e38,np.float32);w=np.full((5,96),3e38,np.float32);y=np.full(5,123,np.float32)
        rc=self.ops.lib.ck_affine(ptr(x),96,ptr(w),None,5,ptr(y))
        self.assertNotEqual(rc,0);self.assertTrue(np.all(y==123))
    def test_layernorm(self):
        x,g,b=self.rand(96),self.rand(96),self.rand(96)
        self.close(self.ops.layernorm(x,g,b,1e-5),F.layer_norm(torch.from_numpy(x),(96,),torch.from_numpy(g),torch.from_numpy(b),1e-5).numpy())
    def test_layernorm_constant(self):
        x=np.ones(96,np.float32);g,b=self.rand(96),self.rand(96)
        self.assertTrue(np.array_equal(self.ops.layernorm(x,g,b,1e-5),b))
    def test_layernorm_invalid_epsilon(self):
        for e in [0,-1,float('nan'),float('inf')]:
            with self.assertRaises(ValueError):self.ops.layernorm(self.rand(96),self.rand(96),self.rand(96),e)
    def test_dw_three_dilations(self):
        for d in [1,2,4]:
            x,k=self.rand(37,96),self.rand(96,3)*0.1;s=self.ops.dw_init(d)
            out=np.stack([self.ops.dw_frame(s,v,k) for v in x])
            ref=F.conv1d(F.pad(torch.from_numpy(x.T.copy())[None],(2*d,0)),torch.from_numpy(k[:,None,:]),groups=96,dilation=d)[0].T.numpy()
            self.close(out,ref);self.assertEqual(s.frames,37)
    def test_dw_chunk_partition(self):
        x,k=self.rand(39,96),self.rand(96,3)*0.1
        def run(chunks):
            s=self.ops.dw_init(4);out=[];pos=0
            for n in chunks:
                out.extend(self.ops.dw_frame(s,v,k) for v in x[pos:pos+n]);pos+=n
            return np.stack(out),bytes(s)
        a,sa=run([39]);b,sb=run([0,1,2,0,8,3,25,0])
        self.assertTrue(np.array_equal(a,b));self.assertEqual(sa,sb)
    def test_dw_reset(self):
        x,k=self.rand(96),self.rand(96,3);s=self.ops.dw_init(1)
        first=self.ops.dw_frame(s,x,k)
        self.ops.dw_frame(s,x,k);self.ops.lib.ck_dw_init(C.byref(s),1)
        self.assertTrue(np.array_equal(first,self.ops.dw_frame(s,x,k)))
    def test_dw_prefix_independent(self):
        x,k=self.rand(20,96),self.rand(96,3);s=self.ops.dw_init(2)
        a=np.stack([self.ops.dw_frame(s,v,k) for v in x]);s=self.ops.dw_init(2)
        b=np.stack([self.ops.dw_frame(s,v,k) for v in x[:7]])
        self.assertTrue(np.array_equal(a[:7],b))
    def test_dw_invalid_dilation(self):
        with self.assertRaises(ValueError):self.ops.dw_init(3)
    def test_dw_invalid_input_transaction(self):
        s=self.ops.dw_init(4);old=bytes(s);x,k=self.rand(96),self.rand(96,3);x[8]=np.inf
        y=np.full(96,7,np.float32)
        self.assertNotEqual(self.ops.lib.ck_dw_frame(C.byref(s),ptr(x),ptr(k),ptr(y)),0)
        self.assertEqual(old,bytes(s));self.assertTrue(np.all(y==7))
    def test_dw_count_overflow(self):
        s=self.ops.dw_init(1);s.frames=2**64-1;old=bytes(s)
        with self.assertRaises(ValueError):self.ops.dw_frame(s,self.rand(96),self.rand(96,3))
        self.assertEqual(bytes(s),old)
    def test_null_state(self):self.assertNotEqual(self.ops.lib.ck_dw_init(None,1),0)


if __name__=='__main__':unittest.main()
