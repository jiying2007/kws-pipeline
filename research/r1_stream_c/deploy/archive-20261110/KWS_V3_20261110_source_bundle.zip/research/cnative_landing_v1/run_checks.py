"""Run local suites; use the restored pinned Python, not a downloaded runtime."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--libraries',type=Path,required=True);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False);here=Path(__file__).resolve().parent
    src={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in here.iterdir() if q.suffix in ('.py','.c','.h')}
    (a.output/'SOURCE_BEFORE_TESTS.json').write_text(json.dumps(src,indent=2)+'\n')
    results=[]
    for mode in ([],['-O'],['-OO']):
        for suite in ('test_metrics','test_exports','test_ops'):
            compilers=('gcc','clang') if suite=='test_ops' else (None,)
            for cc in compilers:
                env=os.environ.copy()
                if cc:env['KWS_OPS_LIBRARY']=str(a.libraries/f'libcnative_{cc}.so')
                cmd=[sys.executable,*mode,'-m','unittest','-v',suite]
                start=time.monotonic();r=subprocess.run(cmd,cwd=here,env=env,capture_output=True,text=True,timeout=120)
                name=f'{suite}-{cc or "python"}-{mode[0] if mode else "normal"}.log'
                (a.output/name).write_text(r.stdout+r.stderr)
                count=re.search(r'Ran (\d+) tests?',r.stderr)
                results.append({'suite':suite,'compiler':cc,'mode':mode,'returncode':r.returncode,
                                'cases':int(count[1]) if count else None,'log':name,
                                'seconds':time.monotonic()-start})
                if r.returncode:raise RuntimeError(name+' FAILED')
    for name,pin in src.items():
        if hashlib.sha256((here/name).read_bytes()).hexdigest()!=pin:raise RuntimeError('source changed during tests')
    summary={'schema':'kws-local-test-receipt-v1','runtime_python':platform.python_version(),
             'test_case_invocations':sum(r['cases'] for r in results),'all_success':True,'runs':results,
             'full_repository_ci_run':False,'model_forwards':0,'training_updates':0,
             'source_manifest_sha256':hashlib.sha256((a.output/'SOURCE_BEFORE_TESTS.json').read_bytes()).hexdigest()}
    (a.output/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
